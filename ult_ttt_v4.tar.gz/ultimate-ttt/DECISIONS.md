# Decisions

Every choice that had a real alternative gets an entry: what we chose, what we did not, and why. Newest at the bottom.

---

## D-001: Game rules follow standard Ultimate Tic-Tac-Toe

**Source:** Product owner, 2026-09-28 ("use the general rules of ultimate tic-tac-toe").

1. X always moves first. The first move may go in any cell of any small board.
2. The cell you play in sends your opponent to the small board in the same position (cell 2 sends them to board 2).
3. Three in a row on a small board wins that board.
4. If you are sent to a board that is won or full, you may play in any open board.
5. A won board is closed. No further moves may be made in it, even if it has empty cells.
6. A small board that fills with no winner belongs to nobody and counts toward neither player's three-in-a-row.
7. Three small boards in a row on the big board wins the game.
8. If no legal move remains and nobody has won, the game is a draw. There is no tiebreak by counting boards.

**Alternatives not taken:**
- Rule 5: letting play continue inside a won board. Rejected because it is the less common variant and the product owner asked for general rules.
- Rule 6: counting a drawn small board for both players. Rejected for the same reason.
- Rule 8: breaking a draw by counting small boards won. Not part of the standard rules.

## D-002: Two players share one screen

**Source:** Product owner, 2026-09-28.

**Alternatives not taken:** play across two devices (needs live updates and player identity), play against the computer (needs an AI opponent). Both are out of scope.

## D-003: Games save automatically on every move; there is no Save button

**Source:** Product owner, 2026-09-28 (confirmed autosave is acceptable).

Every move is a `POST /api/v1/games/{id}/moves` that is written to the database immediately, so a game can always be resumed from the saved-games list.

**Alternative not taken:** an explicit Save button. It would add a way to lose progress and gives the player nothing autosave does not.

## D-004: Game state is derived from the move list, not stored

Whose turn it is, which board the next move must go in, who owns each small board, the game status, and "last played" are all computed from the ordered list of moves. Only the moves themselves are stored.

**Alternative not taken:** storing a board snapshot or status column on `games`. The constitution forbids storing derived values, and a snapshot could drift out of sync with the moves.

## D-005: The rules engine is a pure function in `app/services/`

`app/services/rules.py` takes a sequence of moves and returns the game state, and validates a proposed move against that state. It knows nothing about HTTP or SQL, so every rule can be tested with plain data.

**Alternative not taken:** validating moves inside the router or repository. That would break the layer boundaries the constitution requires.

## D-006: Rules page shows on first open only, with a link to it afterward

**Source:** Product owner, 2026-09-28.

**Open implementation question:** "first open" must be remembered somewhere. With no accounts, the likely answer is a per-browser flag in `localStorage`. This will be confirmed with the team when the frontend is built.

## D-007: Saved games are never deleted automatically

**Source:** Product owner, 2026-09-28 ("do not automatically delete saved games").

There is no cleanup job and no expiry.

**Open question for the product owner:** can a player delete (archive) a game by hand? The answer rules out automatic deletion but does not say whether manual deletion is wanted. Nothing is built for it until this is answered.

## D-008: Player names can be changed at any point in a game

**Source:** Product owner, 2026-09-28.

Renaming is `PATCH /api/v1/games/{id}`, allowed whether the game is new, in progress, or finished. It is a field edit, not a state transition, so `PATCH` is correct under the resource-naming convention.

**Alternative not taken:** locking names after the first move.

## D-009: Players can delete a saved game themselves (soft delete)

**Source:** Product owner, 2026-09-28 ("players delete the games themselves"). This answers the open question in D-007.

Deleting is `POST /api/v1/games/{id}/archive`, which sets `is_archived` and returns `204`. An archived game is treated as gone: it is left out of the games list, and reading, renaming, playing in or archiving it again returns `404 game_not_found`. The row stays in the database.

**Alternatives not taken:**
- A hard `DELETE /api/v1/games/{id}`. The constitution prefers soft deletes unless a requirement says otherwise.
- A way to restore or view archived games. Nobody asked for one, so none is built.

## D-010: Settings are loaded with `pydantic-settings`

**Source:** Team approval, 2026-09-28. `pydantic-settings` was not on the stack list, so it was added only after asking.

`app/core/config.py` reads `DATABASE_URL` from the environment or a `.env` file.

**Alternative not taken:** a hand-written loader using `os.environ`. It would repeat what `pydantic-settings` already does, including type checking the values.

## D-011: The games list has no status filter

The design proposal listed a `status` filter (in progress, won, drawn). Status is derived from the moves (D-004), so the database cannot filter on it. Filtering would need either replaying every saved game on each request or storing a status snapshot, which the constitution forbids without a product-owner requirement. The product owner did not ask for the filter, so it is left out. The list still shows each game's status.

## D-012: `last_played_at` falls back to `created_at`

`last_played_at` is the time of a game's most recent move. For a game with no moves yet, it is the time the game was created, so new games sort sensibly in the list. It is computed in the query, not stored. Renaming players does not count as playing.

**Alternative not taken:** returning `null` for games with no moves. That makes sorting awkward and gives the list nothing useful to show.

## D-013: Making a move returns the updated game, with `Location` pointing at the game

`POST /api/v1/games/{id}/moves` returns `201`. The body is the full updated game, because the board screen needs the new state straight away. The `Location` header is `/api/v1/games/{id}`.

**Alternative not taken:** a `GET /api/v1/games/{id}/moves/{sequence}` endpoint so that `Location` could point at the move itself. Nothing needs to read a single move, so building it would widen scope.

## D-014: Two moves submitted at once: the second is refused

If two move requests reach the server at the same moment (for example, a double-click), both could pass validation against the same state. The database's unique constraint on `(game_id, sequence)` stops the second one from being saved, and it gets `409 stale_game` ("reload and try again").

**Alternative not taken:** row locking with `SELECT ... FOR UPDATE`. SQLite does not support it, and the unique constraint gives the same guarantee on both databases.

## D-015: Player names are 1 to 25 characters after trimming spaces

Names default to "Player X" and "Player O". Both players may have the same name. A blank name is refused with `422`.

**Alternative not taken:** no length limit. A limit keeps the board screen's layout predictable. If the product owner wants a different limit, it is one constant to change.

**Changed 2026-09-28:** the limit was 50 and is now 25, at the team's request. The second migration shortens any name already saved that is longer than 25 characters (to its first 25), because PostgreSQL will not narrow a column that holds longer values. The limit lives in `PLAYER_NAME_MAX_LENGTH` in `backend/app/models/game.py` and is mirrored in `frontend/src/lib/playerNames.ts`.

## D-016: PostgreSQL driver added with the Compose file (step 4)

The code uses nothing specific to SQLite outside `app/core/database.py`. The `psycopg` driver will be added in step 4, when the Compose file gets its commented-out `db` service, so it is not installed before anything uses it.

**Done in step 4:** `psycopg[binary]` is now a backend dependency, and `docker-compose.yml` has the commented-out `db` service and the matching `DATABASE_URL`. The app has not yet been run against PostgreSQL; the tests use SQLite.

## D-017: "First open" is remembered per browser in `localStorage`

Answers the open question in D-006. There are no accounts, so the app remembers in the browser. Opening `/` for the first time sends the player to the rules page and sets a flag; after that, `/` goes to saved games. The Rules link in the header is always available.

If the browser blocks storage (for example in some private-browsing modes), the app cannot remember, and shows the rules every time rather than never.

**Alternative not taken:** a server-side flag. It would be shared by everyone using the same backend, so a second computer would never see the rules.

## D-018: Supporting packages added alongside the named frontend tools

These are not new tools; each is the standard companion that the stack's named tools need to work. They are listed here so the team can object to any of them:

- `@vitejs/plugin-react`: lets Vite compile React.
- `@types/react`, `@types/react-dom`, `@types/node`: TypeScript types for React and for `vite.config.ts`.
- `@testing-library/dom`, `@testing-library/user-event`, `@testing-library/jest-dom`: required by React Testing Library, the `userEvent` named in the testing standard, and matchers such as `toHaveAccessibleDescription`.
- `@eslint/js`, `typescript-eslint`, `eslint-plugin-react-hooks`, `globals`, `eslint-config-prettier`: the ESLint 9 flat config for TypeScript and React, with Prettier owning formatting.

## D-019: Stayed on the constitution's locked major versions where newer ones exist

At the time of writing, TypeScript 7, ESLint 10 and Vitest 5 have been released. The constitution locks TypeScript 5.x, ESLint 9 and Vitest 4, so those are installed (5.9, 9.39, 4.1). **npm marks ESLint 9 as no longer supported**; moving to ESLint 10 is the instructor's decision.

React Router's current major is 8 (the constitution says "current major"). Its data-router API matches v7; the one change that affects this app is that `RouterProvider` is imported from `react-router/dom`.

## D-020: A new game starts with default names; names are edited on the board screen

"New game" creates the game straight away as "Player X" vs "Player O" and opens it. The names form is on the board screen, since names can be changed at any time (D-008).

**Alternative not taken:** asking for names in a form before the game starts. It adds a step that the board screen already covers.

## D-021: Deleting a game asks for confirmation first

Because a deleted game cannot be restored (D-009), the Delete button shows "Delete this game? This cannot be undone." with Delete game / Cancel buttons, in the page rather than a browser pop-up.

## D-022: The board switches off cells that cannot be played, but the server still decides

The frontend disables cells that the rules clearly rule out (a finished board, the wrong board, a taken cell, a finished game) so players are not offered moves that will fail. It does not re-implement the rules: the server's answer is final, and a refused move shows the server's message.

## D-023: Page name is "Saved Games"; name boxes use the players' colors

**Source:** Team request, 2026-09-28.

"Saved Games" is capitalised wherever it names the page: the header link, the page heading, and the "Back to Saved Games" and "Go to Saved Games" links. Where the words are an ordinary phrase in a sentence ("No saved games yet", "Loading saved games…"), they stay lower case.

The Player X and Player O name boxes are tinted in a faded version of that player's color, with the label in the full color, matching the X and O letters on the board. A box with an error keeps its tint and gets a thicker red border, with the message written underneath and tied to the box.

## D-024: Players can change their colors, saved per browser

**Source:** Team request, 2026-09-28. Where colors are saved, how they are picked, whether they may match, and when they can change were each answered by the team.

- **Saved in this browser only** (`localStorage`), for every game on this device. Nothing is stored on the server, so colors do not follow a game to another computer. If the browser blocks storage, a choice still applies until the page is closed.
- **Chosen from a fixed palette of eight:** blue, red, green, purple, orange, teal, pink, gray. Each was checked to have at least 4.5:1 contrast (WCAG AA) on white and on its own faded tint, so X and O stay readable whatever is picked.
- **The two players cannot have the same color.** The other player's color is shown crossed out and cannot be selected. A saved setting that breaks this rule is ignored and the defaults (X blue, O red) are used.
- **Can be changed at any time**, like names (D-008).

Colors are applied by overriding the Tailwind theme variables (`--color-player-x` and so on) on a wrapper element, so the board letters, won boards and name boxes all follow the choice without each needing to know about it. The setting is shared through React context: it is local UI state, not server state, so no state library is involved.

**Alternatives not taken:**
- Saving colors with each game on the server. The team chose per-browser.
- A free color picker. Some choices would make the letters unreadable, which breaks the accessibility floor.

## D-025: Color options are hidden until a player asks for them

**Source:** Team request, 2026-09-28 ("hide the color options").

The color swatches from D-024 now sit behind a "Change colors" button on the board screen. They are hidden each time a game opens; the button shows them and becomes "Hide colors". Hiding them does not undo a choice, and chosen colors still apply everywhere. The button reports its open or closed state to screen readers (`aria-expanded`).

**Alternative not taken:** removing the color feature entirely. "Hide" was read as tucking the options away, not taking them out; removing them is a small change if that was meant.

## D-026: Container healthchecks use the games list, not a separate health endpoint

The backend's healthcheck asks for one game (`GET /api/v1/games?page_size=1`), which proves the API is running and can read the database. The frontend's healthcheck loads the app from nginx and makes the same API call through nginx's proxy, which proves the whole path works.

**Alternative not taken:** a dedicated `GET /api/v1/health` endpoint. It would add an endpoint, tests and generated types while checking less than the list call does.

## D-027: The backend container applies migrations when it starts

The backend image runs `alembic upgrade head` and then starts uvicorn, so `docker compose up` works on an empty volume with no extra step.

**Alternative not taken:** a separate one-off migration service or a manual step. With a single backend container, that adds a step to forget without making anything safer. If the app ever runs several backend containers at once, this should become a separate step so they do not race.

## D-028: How the images are built

- **Backend:** `python:3.14-slim`, with dependencies installed by the same uv version the lock file was made with (0.12.19). Development tools are left out (`--no-dev`). It runs as a non-root user `app`, and the SQLite file lives in `/data`, a named volume.
- **Frontend:** built with `node:24-alpine` and pnpm through Corepack, then served by `nginxinc/nginx-unprivileged`, which runs nginx as a non-root user on port 8080. `nginx.conf` sends `/api/` to the backend and every other path to `index.html`, so React Router can handle it.
- **Each app keeps its own build context and `.dockerignore`**, as the constitution asks. The frontend image also needs `infra/docker/nginx.conf`, which sits outside `frontend/`, so Compose passes `infra/docker` in as a second, named build context (`additional_contexts`).
- **Only the frontend is published** (port 8080). The backend is reachable only through nginx, on the Compose network.

## D-029: CI runs four jobs, and the end-to-end test runs against the real images

1. **Backend:** Ruff lint and format, mypy strict, pytest with the 80% floor.
2. **Frontend:** ESLint, Prettier, TypeScript, Vitest with the 80% floor, production build.
3. **API types:** regenerates `frontend/src/api` from the backend and fails if anything changed, so nobody can forget `pnpm gen:api`.
4. **End-to-end:** after jobs 1 and 2 pass, builds both images with `docker compose up --build --wait`, runs the Playwright happy path against `http://localhost:8080`, prints the container logs and uploads the Playwright report if it fails, and always shuts down.

The Playwright test makes up unique player names on each run, so it also works against a database that already has games in it. It has no retries: a flaky happy path is a bug to fix, not to hide.

Action versions are the current majors at the time of writing (`actions/checkout@v7`, `actions/setup-node@v7`, `astral-sh/setup-uv@v10`, `pnpm/action-setup@v6`, `actions/upload-artifact@v7`). Their inputs were checked against each action's `action.yml`, and the workflow passes `actionlint`.

## D-030: What step 4 could not verify before its first CI run

The development workspace could not download base images from Docker Hub, so **the Docker images have not yet been built**. What was checked instead:

- `docker compose config` accepts the Compose file.
- The backend image's steps were run by hand on the same files the `.dockerignore` lets through: `uv sync --locked --no-dev`, then the container's start command. Migrations ran, the API started, and the Compose healthcheck command passed.
- The Playwright test passed twice against the backend started that way and the production frontend build, served with the same `/api` proxying as nginx.

Still unverified until the first CI run: that the base images and tags exist as written (`python:3.14-slim`, `ghcr.io/astral-sh/uv:0.12.19`, `node:24-alpine`, `nginxinc/nginx-unprivileged:1.29-alpine`), `nginx.conf` itself (no nginx was available to run `nginx -t`), and the healthchecks inside the containers. If the first CI run fails in the e2e job, look there first.

## D-031: Player names save automatically; the Save button is gone

**Source:** Team request, 2026-09-28 ("it needs to keep the names of the players for each saved game").

Names were already stored with each game, but only after "Save names" was clicked. Players who typed names and went straight to the board lost them, and the game came back as "Player X vs Player O". Names now save the same way moves do (D-003): when a player leaves a name box (Tab, clicking the board, clicking a link) or presses Enter in it. A note under the boxes says "Names are saved automatically." and shows "Saving names…" while a save is in flight. Only the name that changed is sent. A blank or overlong name is not saved and shows its message as before.

**Alternative not taken:** asking for both names in a form before a game starts (the alternative in D-020). It would fix new games but not renaming mid-game, which D-008 allows.

## D-032: The opening page is a home menu

**Source:** Team request, 2026-09-28.

`/` shows three choices: **New game** (creates a game and opens it), **Saved Games**, and **Rules**. The title in the header links back to it from every page.

This changes D-006 as little as possible: the very first time the app is opened in a browser it still shows the rules, and their return button leads to the home menu. Every later visit opens on the home menu instead of Saved Games.

**Alternative not taken:** dropping the first-visit rules page. The product owner asked for it (D-006), and nothing in this request withdrew it.

## D-033: The Rules page has a return button

**Source:** Team request, 2026-09-28 ("there needs to be a return button if you click on the rules tab").

Every link to the rules passes the page it came from, and the button returns there, named for where it goes: "Back to game", "Back to Saved Games" (keeping any search), or "Back to home". Opened with no page to return to (the first-visit redirect, a bookmark, a typed address), it goes to the home menu. It appears at the top of the page and again at the bottom, after the rules. The old "Start playing" button at the bottom is replaced by it.

**Alternative not taken:** the browser's own history (`navigate(-1)`). On a first visit or a bookmark, that could take the player out of the app entirely.

## D-034: Each save updates only the part of the game it changed

Found while making names save automatically. Typing a name and then clicking the board sends a name save and a move at the same moment. Both replies carry the whole game, each as it was when that reply was made, and they can arrive in either order. Before this fix, whichever arrived last replaced the game on screen, so a late name reply could erase the move just made, and a late move reply could bring back the old name, until the next reload.

Now a move's reply updates the board and keeps the names already shown, and a rename's reply updates only the names it sent. The server was always right; this only affected what was on screen. Two tests reproduce each order with a deliberately slow reply, and both fail on the old code.

## D-035: A finished game offers a rematch with the letters swapped

**Source:** Team request, 2026-09-28 ("when a game ends, offer a rematch in which the players letters switch").

When a game is won or drawn, the board screen shows a Rematch panel saying who will play which letter ("Grace plays X and goes first, Ada plays O."). The button starts a new game with the two names swapped and opens it. X always moves first (D-001), so the player who went second before now goes first. The finished game stays in Saved Games alongside the rematch. It is offered after draws too, since a draw also ends the game.

This is the existing `POST /api/v1/games` with the two names swapped, so no backend change was needed.

**Superseded in part by D-037:** rematches are now started with `POST /api/v1/games/{id}/rematch`, because the tally needs to know which games belong together.

**Alternatives not taken:**
- A `POST /api/v1/games/{id}/rematch` endpoint that links the two games. Nothing needs to know which game was a rematch of which, so it would add an endpoint, tests and types for no visible difference.
- Reusing the finished game by clearing its moves. That would lose the finished game from Saved Games.

**Open question for the product owner:** player colors belong to the letters (D-024), not the people. After a rematch, each player's letter changes, so each player's color changes with it. If players should keep their colors, that needs colors to follow names, which is a larger change.

## D-036: The rematch offer is a card over the finished board

**Source:** Team request, 2026-09-28 ("move it to where it overlays the board").

When a game ends, the board is dimmed and a card sits on top of it. The card has the result as its heading ("Ada (X) wins!" or "It's a draw!"), who will play which letter in the rematch, a **Rematch** button, and a **View board** button. View board hides the card so the final position can be studied; a **Show rematch** button above the board brings it back. The card is hidden or shown per visit and starts shown each time a finished game is opened.

**Alternative not taken:** a card with no way to hide it. It would cover the final position, which players may want to look at before deciding.

**Superseded in part by D-039:** "View board" and "Show rematch" were replaced by **Review moves**, whose last step is the final position.

## D-037: Rematches form a series, and two tallies of wins and draws are shown

**Source:** Team request, 2026-09-28 ("if players choose to rematch, keep track of how many games they have won or drew"). The team answered the open points: count **both** this rematch series and every game between the same two names; show the tallies **above the board, on the rematch card and in Saved Games**; and **leave deleted games out**.

**Series.** A new column, `games.series_id`, links a rematch to the first game of its series. It is empty on that first game (and on games that were never rematched), whose own id is then the series id. Existing games needed no backfill. A new game from "New game" starts a new series.

**Rematch endpoint.** `POST /api/v1/games/{id}/rematch` creates the next game in the series with the names swapped and returns it (`201`, `Location` to the new game). It is refused with `409 game_not_over` while the game is still being played, and `404` for a missing or deleted game. This replaces the plain "create a game" call that D-035 used, since the server now has to link the games.

**Tallies are computed, not stored** (D-004). Every game in the API carries a `record`:

- `series`: finished games in this game's series.
- `head_to_head`: finished games between these two names in any series, with the names in either order and ignoring case ("Ada" and "ada" are the same player).
- `games_in_series`: games in the series so far, including unfinished ones.

Each tally is `player_x_wins`, `player_o_wins`, `draws` and `games_played`, seen from that game's players. Because letters swap in a rematch, wins are matched **by name**: `player_x_wins` counts every win by whoever is X in *this* game, whatever letter they had when they won. Unfinished and deleted games are not counted.

**Known limits, all following from matching by name:**
- If a player is renamed partway through a series, their earlier wins stay under the old name.
- If both players have the same name, a win counts for both.

**Where it shows.** Above the board, on the rematch card, and on each game in Saved Games, as "This series (2 games): Ada 2 wins · Grace 0 wins · 0 draws" and "All games between them: …". Nothing is shown until a game has finished or a rematch has started.

**Alternatives not taken:**
- Storing a winner or a running score on each game. It would be a stored copy of something the moves already decide, which D-004 rules out.
- Matching players by seat (the first game's X is "player A") instead of by name. It would survive renames, but "every game between these names" has to match by name anyway, and using one rule for both tallies keeps them consistent.


## D-038: Saved Games offers Resume for unfinished games and Review for finished ones

**Source:** Team request, 2026-09-28 ("add a resume button for unfinished games and a review button for finished games").

Each game in Saved Games now has one of two buttons beside Delete:

- **Resume** (unfinished games) opens the board, ready to carry on.
- **Review** (won or drawn games) opens the finished board with the rematch card (D-036) already hidden, so the final position is in view. "Show rematch" still brings the card back.

The game's title stays a link as well. Screen readers hear each button with its game, for example "Resume Ada vs Grace".

**Assumption to confirm with the product owner:** "Review" was read as "look at the finished board". A move-by-move replay (stepping forwards and backwards through the game) would be a separate, larger feature; the moves are all saved, so it is possible if wanted.

**Answered by D-039:** the team asked for move-by-move review, and Review now opens that.

## D-039: Finished games can be reviewed move by move

**Source:** Team request, 2026-09-28 ("keep track of moves so that when you review the games, you can go move by move").

Every move was already saved in order (D-004), so nothing new is stored.

**Server.** `GET /api/v1/games/{id}?at_move=n` returns the game as it stood after its first `n` moves (0 is the empty board). The server replays those moves through the rules engine, so the board, won boards, whose turn it was and where they had to play are all worked out the same way as in a live game. The frontend still does not re-implement the rules (D-022). A move number past the end is `404 move_not_found`; a negative one is `422`. The tallies (D-037) are the game's current ones at every step.

**Screen.** Review mode is part of the address (`/games/12?move=5`), so reloading or sharing the link keeps the place. The controls are First, Previous, "Move 5 of 17", Next, Last, and Done reviewing. A sentence says what happened, for example "Move 5 of 17: Ada (X) played the middle right square of the top left board, winning that board.", and the last step adds the result. That sentence is the page's status line, so screen readers read each step out. Nothing can be played while reviewing. A move number past the end of the game (an old link or a typo) shows the last move.

**Ways in.** **Review** in Saved Games opens the review at the last move. The rematch card's **Review moves** button does the same, and **Done reviewing** brings the card back. Review also works on an unfinished game if its address has `?move=`, and "Done reviewing" then returns to playing.

**Alternatives not taken:**
- Having the frontend rebuild each position from the move list. Placing the letters is easy, but knowing which boards were won and where the next player had to play means re-implementing the rules (D-022).
- One request returning every position at once. It would make stepping instant, but it would be a list endpoint, and every list endpoint must support search, sort and pages, which make no sense for the positions of one game. One small request per step is fast enough, and each position is cached once loaded.


## D-040: Migrations switch off SQLite foreign keys while rebuilding tables, and clear up failed attempts

**Found by the team, 2026-09-28:** after upgrading to the version with rematch tallies, the backend container never became healthy ("dependency failed to start: container ultimate-ttt-backend-1 is unhealthy").

**Cause.** SQLite cannot add a column with a foreign key to an existing table, so Alembic's batch mode rebuilds `games`: it copies it into `_alembic_tmp_games`, drops the original and renames the copy. The app switches SQLite foreign keys on for every connection (`app/core/database.py`), and saved moves point at `games`, so the drop was refused ("FOREIGN KEY constraint failed"). The first attempt also left `_alembic_tmp_games` behind, so every restart failed with "table already exists". The migration tests had only ever run on empty databases, so they missed it. The 25-character-names migration (D-015) rebuilds `games` the same way, so it had the same flaw.

**Fix, in `alembic/env.py` so it covers every migration:**
- On SQLite, before migrating, remove any `_alembic_tmp_<table>` copy whose original table still exists. The original still holds every row, so nothing is lost; a copy whose original is gone is left alone.
- Switch foreign keys off for the migration, since the rebuild copies rows unchanged. Afterwards, check every key with `PRAGMA foreign_key_check`, and stop with an error if any row points at nothing. The app's own connections still switch keys on as before.

No data was lost: the failed attempt stopped before dropping anything, and the fix finishes the upgrade on the existing database.

**Tests added:** every migration run on a database that already has a game with a move; the app still enforces foreign keys after migrating; and recovery from a leftover `_alembic_tmp_games`. The first and last fail on the old setup with the same errors the team saw.

**Alternative not taken:** telling players to delete the Docker volume. It would have "fixed" it by throwing away every saved game.
