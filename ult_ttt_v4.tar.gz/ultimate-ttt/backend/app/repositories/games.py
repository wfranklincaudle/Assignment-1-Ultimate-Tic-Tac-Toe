"""Data access for games and their moves. No business rules live here."""

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from sqlalchemy import ColumnElement, Select, and_, func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.core.errors import StaleWriteError
from app.models import Game, GameMove


class GameSort(StrEnum):
    """Whitelisted sort keys for the games list. A leading ``-`` means newest first."""

    CREATED_AT = "created_at"
    CREATED_AT_DESC = "-created_at"
    LAST_PLAYED_AT = "last_played_at"
    LAST_PLAYED_AT_DESC = "-last_played_at"


@dataclass(frozen=True, slots=True)
class GameRow:
    game: Game
    last_played_at: datetime


@dataclass(frozen=True, slots=True)
class GamePage:
    rows: list[GameRow]
    total: int


def _last_played_at() -> ColumnElement[datetime]:
    """Time of the game's latest move, or its creation time if it has none (D-012)."""
    latest_move = (
        select(func.max(GameMove.created_at))
        .where(GameMove.game_id == Game.id)
        .correlate(Game)
        .scalar_subquery()
    )
    return func.coalesce(latest_move, Game.created_at).label("last_played_at")


class GameRepository:
    def __init__(self, session: Session) -> None:
        self._session = session

    def _select(self, *, include_archived: bool) -> Select[Game, datetime]:
        stmt = select(Game, _last_played_at()).options(selectinload(Game.moves))
        if not include_archived:
            stmt = stmt.where(Game.is_archived.is_(False))
        return stmt

    def get(self, game_id: int, *, include_archived: bool = False) -> GameRow | None:
        row = self._session.execute(
            self._select(include_archived=include_archived).where(Game.id == game_id)
        ).one_or_none()
        if row is None:
            return None
        game, last_played_at = row
        return GameRow(game=game, last_played_at=last_played_at)

    def list_page(
        self,
        *,
        q: str | None,
        sort: GameSort,
        page: int,
        page_size: int,
        include_archived: bool = False,
    ) -> GamePage:
        stmt = self._select(include_archived=include_archived)
        if q:
            pattern = f"%{q}%"
            stmt = stmt.where(
                or_(Game.player_x_name.ilike(pattern), Game.player_o_name.ilike(pattern))
            )

        total = self._session.scalar(
            select(func.count()).select_from(stmt.with_only_columns(Game.id).subquery())
        )

        sort_column: ColumnElement[datetime]
        if sort in (GameSort.CREATED_AT, GameSort.CREATED_AT_DESC):
            sort_column = Game.created_at.expression
        else:
            sort_column = _last_played_at()
        if sort.value.startswith("-"):
            # Game id breaks ties, so paging through equal timestamps is stable.
            stmt = stmt.order_by(sort_column.desc(), Game.id.desc())
        else:
            stmt = stmt.order_by(sort_column.asc(), Game.id.asc())

        stmt = stmt.limit(page_size).offset((page - 1) * page_size)
        rows = [
            GameRow(game=game, last_played_at=last_played_at)
            for game, last_played_at in self._session.execute(stmt)
        ]
        return GamePage(rows=rows, total=total or 0)

    def find_for_records(
        self, *, series_keys: set[int], name_pairs: set[tuple[str, str]]
    ) -> list[Game]:
        """Games (not archived) that could count towards a tally (D-037).

        That is every game in one of ``series_keys``, plus every game between
        one of ``name_pairs``: the two names in either order, ignoring case.
        Pairs must be given in lower case. Moves are loaded, so results can be
        worked out.
        """
        conditions: list[ColumnElement[bool]] = []
        if series_keys:
            conditions.append(func.coalesce(Game.series_id, Game.id).in_(series_keys))
        x_name, o_name = func.lower(Game.player_x_name), func.lower(Game.player_o_name)
        for first, second in name_pairs:
            conditions.append(
                or_(
                    and_(x_name == first, o_name == second),
                    and_(x_name == second, o_name == first),
                )
            )
        if not conditions:
            return []
        stmt = (
            select(Game)
            .options(selectinload(Game.moves))
            .where(Game.is_archived.is_(False), or_(*conditions))
        )
        return list(self._session.scalars(stmt))

    def add(self, game: Game) -> None:
        self._session.add(game)
        self._session.commit()

    def save(self) -> None:
        """Commit changes made to games already loaded from this repository."""
        self._session.commit()

    def add_move(self, game: Game, *, sequence: int, board_index: int, cell_index: int) -> None:
        """Save a move. Raises StaleWriteError if another write got there first."""
        game.moves.append(
            GameMove(sequence=sequence, board_index=board_index, cell_index=cell_index)
        )
        try:
            self._session.commit()
        except IntegrityError as error:
            self._session.rollback()
            raise StaleWriteError from error
