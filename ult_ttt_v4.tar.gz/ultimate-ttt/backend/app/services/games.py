"""Use cases for saved games: create, list, resume, rename, delete, and play.

Rules of play live in ``rules.py``. This module loads a game, replays its moves
through those rules, and saves the result. It knows nothing about HTTP.
"""

from dataclasses import dataclass, replace
from datetime import datetime

from app.core.errors import DomainError, NotFoundError, StaleWriteError
from app.models import Game, GameMove
from app.repositories.games import GameRepository, GameRow, GameSort
from app.services import rules

DEFAULT_PLAYER_X_NAME = "Player X"
DEFAULT_PLAYER_O_NAME = "Player O"


@dataclass(frozen=True, slots=True)
class Tally:
    """Results of finished games, seen from one game's two players (D-037).

    Wins are matched by name, ignoring case, because letters swap in a rematch:
    ``player_x_wins`` counts games won by whoever is X in *this* game, whatever
    letter they had in the game they won.
    """

    player_x_wins: int
    player_o_wins: int
    draws: int
    games_played: int


@dataclass(frozen=True, slots=True)
class GameRecord:
    # Finished games in this game's rematch series.
    series: Tally
    # Finished games between these two names, in any series.
    head_to_head: Tally
    # Games in the series so far, including unfinished ones.
    games_in_series: int


@dataclass(frozen=True, slots=True)
class GameView:
    """A stored game together with everything derived from it."""

    game: Game
    state: rules.GameState
    last_played_at: datetime
    record: GameRecord
    # How many of the game's moves ``state`` includes. Normally all of them;
    # fewer when looking back at an earlier position (D-039).
    moves_shown: int

    @property
    def shown_moves(self) -> list[GameMove]:
        return self.game.moves[: self.moves_shown]


@dataclass(frozen=True, slots=True)
class GameListResult:
    items: list[GameView]
    total: int
    page: int
    page_size: int


def _replay(game: Game) -> rules.GameState:
    return rules.replay(rules.Move(m.board_index, m.cell_index) for m in game.moves)


def _pair(game: Game) -> tuple[str, str]:
    """The two player names, in lower case and a fixed order, so a rematch matches."""
    first, second = sorted((game.player_x_name.lower(), game.player_o_name.lower()))
    return first, second


def _tally(game: Game, results: list[tuple[Game, rules.GameStatus]]) -> Tally:
    x_name, o_name = game.player_x_name.lower(), game.player_o_name.lower()
    x_wins = o_wins = draws = played = 0
    for other, status in results:
        if status is rules.GameStatus.IN_PROGRESS:
            continue
        played += 1
        if status is rules.GameStatus.DRAW:
            draws += 1
            continue
        winner = other.player_x_name if status is rules.GameStatus.X_WON else other.player_o_name
        # If both players have the same name, a win counts for both.
        x_wins += winner.lower() == x_name
        o_wins += winner.lower() == o_name
    return Tally(player_x_wins=x_wins, player_o_wins=o_wins, draws=draws, games_played=played)


class GameService:
    def __init__(self, repository: GameRepository) -> None:
        self._repository = repository

    def _load(self, game_id: int) -> GameRow:
        # Archived games are deleted as far as players are concerned (D-009).
        row = self._repository.get(game_id)
        if row is None:
            raise NotFoundError("game_not_found", f"Game {game_id} does not exist.")
        return row

    def _views(self, rows: list[GameRow]) -> list[GameView]:
        """Build views for several games at once, with one query for all their tallies."""
        if not rows:
            return []
        candidates = self._repository.find_for_records(
            series_keys={row.game.series_key for row in rows},
            name_pairs={_pair(row.game) for row in rows},
        )
        results = [(game, _replay(game).status) for game in candidates]

        views = []
        for row in rows:
            game = row.game
            in_series = [(g, st) for g, st in results if g.series_key == game.series_key]
            between = [(g, st) for g, st in results if _pair(g) == _pair(game)]
            record = GameRecord(
                series=_tally(game, in_series),
                head_to_head=_tally(game, between),
                games_in_series=len(in_series),
            )
            views.append(
                GameView(
                    game=game,
                    state=_replay(game),
                    last_played_at=row.last_played_at,
                    record=record,
                    moves_shown=len(game.moves),
                )
            )
        return views

    def _view(self, row: GameRow) -> GameView:
        return self._views([row])[0]

    def create_game(self, *, player_x_name: str, player_o_name: str) -> GameView:
        game = Game(player_x_name=player_x_name, player_o_name=player_o_name)
        self._repository.add(game)
        return self.get_game(game.id)

    def get_game(self, game_id: int) -> GameView:
        return self._view(self._load(game_id))

    def get_game_at_move(self, game_id: int, move_number: int) -> GameView:
        """The game as it stood after its first ``move_number`` moves (D-039).

        0 is the empty board before X's first move. Everything shown for that
        position (cells, won boards, whose turn, where to play) comes from
        replaying those moves through the rules, the same as for a live game.
        The tallies are the game's current ones.
        """
        view = self.get_game(game_id)
        total = len(view.game.moves)
        if move_number > total:
            raise NotFoundError(
                "move_not_found",
                f"This game has {total} moves, so there is no move {move_number}.",
            )
        moves = view.game.moves[:move_number]
        state = rules.replay(rules.Move(m.board_index, m.cell_index) for m in moves)
        return replace(view, state=state, moves_shown=move_number)

    def list_games(
        self, *, q: str | None, sort: GameSort, page: int, page_size: int
    ) -> GameListResult:
        result = self._repository.list_page(q=q, sort=sort, page=page, page_size=page_size)
        return GameListResult(
            items=self._views(result.rows),
            total=result.total,
            page=page,
            page_size=page_size,
        )

    def rename_players(
        self, game_id: int, *, player_x_name: str | None, player_o_name: str | None
    ) -> GameView:
        # Allowed at any point, including after the game is over (D-008).
        row = self._load(game_id)
        if player_x_name is not None:
            row.game.player_x_name = player_x_name
        if player_o_name is not None:
            row.game.player_o_name = player_o_name
        self._repository.save()
        return self._view(row)

    def archive_game(self, game_id: int) -> None:
        row = self._load(game_id)
        row.game.is_archived = True
        self._repository.save()

    def make_move(self, game_id: int, *, board_index: int, cell_index: int) -> GameView:
        game = self._load(game_id).game
        state = _replay(game)
        # Raises MoveRejectedError (409) if the rules refuse the move.
        rules.validate_move(state, rules.Move(board_index, cell_index))
        try:
            self._repository.add_move(
                game,
                sequence=state.move_count,
                board_index=board_index,
                cell_index=cell_index,
            )
        except StaleWriteError as error:
            raise DomainError(
                "stale_game",
                "This game was changed by another request. Reload it and try again.",
            ) from error
        return self.get_game(game_id)

    def rematch(self, game_id: int) -> GameView:
        """Start the next game in this game's series, with the letters swapped (D-035, D-037).

        Whoever was O is X in the rematch, so the player who went second now
        goes first. Refused while the game is still being played.
        """
        game = self._load(game_id).game
        if _replay(game).status is rules.GameStatus.IN_PROGRESS:
            raise DomainError("game_not_over", "A rematch can only start once this game has ended.")
        rematch = Game(
            player_x_name=game.player_o_name,
            player_o_name=game.player_x_name,
            series_id=game.series_key,
        )
        self._repository.add(rematch)
        return self.get_game(rematch.id)
