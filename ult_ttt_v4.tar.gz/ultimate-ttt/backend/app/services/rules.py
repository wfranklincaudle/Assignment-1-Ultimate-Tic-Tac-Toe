"""The rules of Ultimate Tic-Tac-Toe, as pure functions.

Nothing here touches HTTP or the database. A game is fully described by its
ordered list of moves; every other fact about it (whose turn it is, where the
next move must go, who owns each small board, whether the game is over) is
computed by replaying those moves. See DECISIONS.md D-001, D-004 and D-005.

Board and cell positions are numbered 0-8 in reading order:

    0 | 1 | 2
    3 | 4 | 5
    6 | 7 | 8

The same numbering is used for the nine small boards on the big board and for
the nine cells inside each small board. That is what makes the "send" rule work:
playing cell 2 of any board sends the opponent to board 2.
"""

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from enum import StrEnum

from app.core.errors import DomainError

BOARD_SIZE = 9

# Every way to get three in a row on a 3x3 grid.
LINES: tuple[tuple[int, int, int], ...] = (
    (0, 1, 2),
    (3, 4, 5),
    (6, 7, 8),
    (0, 3, 6),
    (1, 4, 7),
    (2, 5, 8),
    (0, 4, 8),
    (2, 4, 6),
)


class Player(StrEnum):
    X = "x"
    O = "o"  # noqa: E741  (the letter O is the name of the player)


class BoardStatus(StrEnum):
    """The state of one small board."""

    OPEN = "open"
    X_WON = "x_won"
    O_WON = "o_won"
    DRAW = "draw"


class GameStatus(StrEnum):
    """The state of the whole game."""

    IN_PROGRESS = "in_progress"
    X_WON = "x_won"
    O_WON = "o_won"
    DRAW = "draw"


class MoveRejection(StrEnum):
    """Why a move was refused. These are the ``code`` values the API returns."""

    GAME_OVER = "game_over"
    WRONG_BOARD = "wrong_board"
    BOARD_CLOSED = "board_closed"
    CELL_OCCUPIED = "cell_occupied"


class MoveRejectedError(DomainError):
    def __init__(self, reason: MoveRejection, detail: str) -> None:
        super().__init__(code=reason.value, detail=detail)
        self.reason = reason


@dataclass(frozen=True, slots=True)
class Move:
    board_index: int
    cell_index: int

    def __post_init__(self) -> None:
        # Out-of-range positions are a schema problem (422), caught by the API
        # schema before a Move is ever built. Reaching this is a programming error.
        for name, value in (("board_index", self.board_index), ("cell_index", self.cell_index)):
            if not 0 <= value < BOARD_SIZE:
                raise ValueError(f"{name} must be between 0 and 8, got {value}")


Cells = tuple[Player | None, ...]


@dataclass(frozen=True, slots=True)
class GameState:
    # cells[b][c] is who played cell c of small board b, or None if empty.
    cells: tuple[Cells, ...]
    board_statuses: tuple[BoardStatus, ...]
    status: GameStatus
    # None once the game is over.
    next_player: Player | None
    # The small board the next move must be played in. None means the next
    # player may choose any open board (or the game is over).
    required_board: int | None
    move_count: int


def player_for_sequence(sequence: int) -> Player:
    """Who made the move with this number. X moves first, so even numbers are X."""
    return Player.X if sequence % 2 == 0 else Player.O


def initial_state() -> GameState:
    """A new game: every board open, X to move anywhere."""
    empty_board: Cells = (None,) * BOARD_SIZE
    return GameState(
        cells=(empty_board,) * BOARD_SIZE,
        board_statuses=(BoardStatus.OPEN,) * BOARD_SIZE,
        status=GameStatus.IN_PROGRESS,
        next_player=Player.X,
        required_board=None,
        move_count=0,
    )


def _winner_of(owners: Sequence[Player | None]) -> Player | None:
    """The player holding a full line in this 3x3 grid, if any."""
    for a, b, c in LINES:
        if owners[a] is not None and owners[a] == owners[b] == owners[c]:
            return owners[a]
    return None


def _small_board_status(cells: Cells) -> BoardStatus:
    winner = _winner_of(cells)
    if winner is Player.X:
        return BoardStatus.X_WON
    if winner is Player.O:
        return BoardStatus.O_WON
    if all(cell is not None for cell in cells):
        return BoardStatus.DRAW
    return BoardStatus.OPEN


def _board_owner(status: BoardStatus) -> Player | None:
    # A drawn board belongs to nobody (D-001 rule 6).
    if status is BoardStatus.X_WON:
        return Player.X
    if status is BoardStatus.O_WON:
        return Player.O
    return None


def _game_status(board_statuses: tuple[BoardStatus, ...]) -> GameStatus:
    winner = _winner_of([_board_owner(s) for s in board_statuses])
    if winner is Player.X:
        return GameStatus.X_WON
    if winner is Player.O:
        return GameStatus.O_WON
    # No winner and nowhere left to play (D-001 rule 8).
    if all(s is not BoardStatus.OPEN for s in board_statuses):
        return GameStatus.DRAW
    return GameStatus.IN_PROGRESS


def validate_move(state: GameState, move: Move) -> None:
    """Raise MoveRejectedError if ``move`` is not legal in ``state``."""
    if state.status is not GameStatus.IN_PROGRESS:
        raise MoveRejectedError(MoveRejection.GAME_OVER, "This game is already over.")

    if state.required_board is not None and move.board_index != state.required_board:
        raise MoveRejectedError(
            MoveRejection.WRONG_BOARD,
            f"This move must be played in board {state.required_board}.",
        )

    if state.board_statuses[move.board_index] is not BoardStatus.OPEN:
        raise MoveRejectedError(
            MoveRejection.BOARD_CLOSED,
            f"Board {move.board_index} is already finished. Choose an open board.",
        )

    if state.cells[move.board_index][move.cell_index] is not None:
        raise MoveRejectedError(
            MoveRejection.CELL_OCCUPIED,
            f"Cell {move.cell_index} of board {move.board_index} is already taken.",
        )


def apply_move(state: GameState, move: Move) -> GameState:
    """Return the state after ``move``. Raises MoveRejectedError if it is illegal."""
    validate_move(state, move)
    # validate_move guarantees the game is in progress, so there is a next player.
    assert state.next_player is not None
    player = state.next_player

    board = list(state.cells[move.board_index])
    board[move.cell_index] = player
    new_board: Cells = tuple(board)
    all_boards = list(state.cells)
    all_boards[move.board_index] = new_board
    cells = tuple(all_boards)

    statuses = list(state.board_statuses)
    statuses[move.board_index] = _small_board_status(new_board)
    board_statuses = tuple(statuses)

    status = _game_status(board_statuses)

    if status is not GameStatus.IN_PROGRESS:
        next_player: Player | None = None
        required_board: int | None = None
    else:
        next_player = Player.O if player is Player.X else Player.X
        # The cell just played names the opponent's board, unless that board is
        # finished, in which case they may play in any open board (rule 4).
        target = move.cell_index
        required_board = target if board_statuses[target] is BoardStatus.OPEN else None

    return GameState(
        cells=cells,
        board_statuses=board_statuses,
        status=status,
        next_player=next_player,
        required_board=required_board,
        move_count=state.move_count + 1,
    )


def replay(moves: Iterable[Move]) -> GameState:
    """Compute the current state of a game from its moves, in play order.

    Raises MoveRejectedError if the sequence contains an illegal move, which for
    moves read back from the database would mean the stored game is corrupt.
    """
    state = initial_state()
    for move in moves:
        state = apply_move(state, move)
    return state
