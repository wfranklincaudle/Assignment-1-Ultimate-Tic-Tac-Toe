"""Turn every error into the standard ``{"code", "detail"}`` envelope."""

from http import HTTPStatus

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException

from app.core.errors import DomainError, NotFoundError
from app.schemas.common import ErrorResponse


def _envelope(status_code: int, code: str, detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(code=code, detail=detail).model_dump(),
    )


def _describe_validation_errors(error: RequestValidationError) -> str:
    parts = []
    for item in error.errors():
        # loc looks like ("body", "board_index"); drop the "body"/"query" prefix.
        location = ".".join(str(part) for part in item["loc"][1:]) or str(item["loc"][0])
        parts.append(f"{location}: {item['msg']}")
    return "; ".join(parts)


async def _domain_error(_request: Request, error: Exception) -> JSONResponse:
    assert isinstance(error, DomainError)
    return _envelope(status.HTTP_409_CONFLICT, error.code, error.detail)


async def _not_found(_request: Request, error: Exception) -> JSONResponse:
    assert isinstance(error, NotFoundError)
    return _envelope(status.HTTP_404_NOT_FOUND, error.code, error.detail)


async def _validation_error(_request: Request, error: Exception) -> JSONResponse:
    assert isinstance(error, RequestValidationError)
    return _envelope(
        status.HTTP_422_UNPROCESSABLE_CONTENT,
        "validation_error",
        _describe_validation_errors(error),
    )


async def _http_error(_request: Request, error: Exception) -> JSONResponse:
    # Errors raised by the framework itself, such as an unknown URL (404) or a
    # wrong method (405). Their code is the standard reason phrase in snake_case.
    assert isinstance(error, HTTPException)
    code = HTTPStatus(error.status_code).phrase.lower().replace(" ", "_").replace("-", "_")
    return _envelope(error.status_code, code, str(error.detail))


def register_error_handlers(app: FastAPI) -> None:
    app.add_exception_handler(DomainError, _domain_error)
    app.add_exception_handler(NotFoundError, _not_found)
    app.add_exception_handler(RequestValidationError, _validation_error)
    app.add_exception_handler(HTTPException, _http_error)
