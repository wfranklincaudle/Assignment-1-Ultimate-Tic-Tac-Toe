"""HTTP routes for games. Each handler translates HTTP to a service call and back.

No handler here decides anything about the game; the service and rules do.
"""

from typing import Annotated, Any

from fastapi import APIRouter, Query, Response, status

from app.api.v1.dependencies import GameServiceDep
from app.repositories.games import GameSort
from app.schemas.common import ErrorResponse, Page
from app.schemas.games import GameCreate, GameDetail, GameSummary, GameUpdate, MoveCreate

router = APIRouter(prefix="/games", tags=["games"])

ResponseDocs = dict[int | str, dict[str, Any]]

NOT_FOUND: ResponseDocs = {status.HTTP_404_NOT_FOUND: {"model": ErrorResponse}}
CONFLICT: ResponseDocs = {status.HTTP_409_CONFLICT: {"model": ErrorResponse}}
INVALID: ResponseDocs = {status.HTTP_422_UNPROCESSABLE_CONTENT: {"model": ErrorResponse}}


def _game_url(game_id: int) -> str:
    return f"/api/v1/games/{game_id}"


@router.get("", response_model=Page[GameSummary], responses=INVALID)
def list_games(
    service: GameServiceDep,
    q: Annotated[str | None, Query(max_length=50, description="Search player names")] = None,
    sort: GameSort = GameSort.LAST_PLAYED_AT_DESC,
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=100)] = 25,
) -> Page[GameSummary]:
    result = service.list_games(q=q, sort=sort, page=page, page_size=page_size)
    return Page[GameSummary](
        items=[GameSummary.from_view(view) for view in result.items],
        total=result.total,
        page=result.page,
        page_size=result.page_size,
    )


@router.post(
    "",
    response_model=GameDetail,
    status_code=status.HTTP_201_CREATED,
    responses=INVALID,
)
def create_game(service: GameServiceDep, body: GameCreate, response: Response) -> GameDetail:
    view = service.create_game(player_x_name=body.player_x_name, player_o_name=body.player_o_name)
    response.headers["Location"] = _game_url(view.game.id)
    return GameDetail.from_view(view)


@router.get("/{game_id}", response_model=GameDetail, responses=NOT_FOUND | INVALID)
def get_game(
    service: GameServiceDep,
    game_id: int,
    at_move: Annotated[
        int | None,
        Query(
            ge=0,
            description=(
                "Show the game as it stood after this many moves (0 is the empty board). "
                "Leave out for the game as it is now."
            ),
        ),
    ] = None,
) -> GameDetail:
    if at_move is None:
        return GameDetail.from_view(service.get_game(game_id))
    return GameDetail.from_view(service.get_game_at_move(game_id, at_move))


@router.patch("/{game_id}", response_model=GameDetail, responses=NOT_FOUND | INVALID)
def rename_players(service: GameServiceDep, game_id: int, body: GameUpdate) -> GameDetail:
    view = service.rename_players(
        game_id, player_x_name=body.player_x_name, player_o_name=body.player_o_name
    )
    return GameDetail.from_view(view)


@router.post(
    "/{game_id}/archive",
    status_code=status.HTTP_204_NO_CONTENT,
    responses=NOT_FOUND | INVALID,
)
def archive_game(service: GameServiceDep, game_id: int) -> None:
    service.archive_game(game_id)


@router.post(
    "/{game_id}/moves",
    response_model=GameDetail,
    status_code=status.HTTP_201_CREATED,
    responses=NOT_FOUND | CONFLICT | INVALID,
)
def make_move(
    service: GameServiceDep, game_id: int, body: MoveCreate, response: Response
) -> GameDetail:
    view = service.make_move(game_id, board_index=body.board_index, cell_index=body.cell_index)
    # D-013: Location points at the game, whose state the move just changed.
    response.headers["Location"] = _game_url(game_id)
    return GameDetail.from_view(view)


@router.post(
    "/{game_id}/rematch",
    response_model=GameDetail,
    status_code=status.HTTP_201_CREATED,
    responses=NOT_FOUND | CONFLICT | INVALID,
)
def rematch(service: GameServiceDep, game_id: int, response: Response) -> GameDetail:
    """Start the next game in the series with the letters swapped (D-035, D-037)."""
    view = service.rematch(game_id)
    response.headers["Location"] = _game_url(view.game.id)
    return GameDetail.from_view(view)
