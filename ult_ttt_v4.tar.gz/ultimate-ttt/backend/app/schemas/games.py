"""Request and response bodies for the games API."""

from datetime import datetime
from typing import Annotated, Self

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

from app.models.game import PLAYER_NAME_MAX_LENGTH
from app.services.games import (
    DEFAULT_PLAYER_O_NAME,
    DEFAULT_PLAYER_X_NAME,
    GameView,
    Tally,
)
from app.services.rules import BOARD_SIZE, BoardStatus, GameStatus, Player, player_for_sequence

# D-015: 1 to 25 characters once surrounding spaces are removed.
PlayerName = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=PLAYER_NAME_MAX_LENGTH),
]
Position = Annotated[int, Field(ge=0, le=BOARD_SIZE - 1)]


class GameCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    player_x_name: PlayerName = DEFAULT_PLAYER_X_NAME
    player_o_name: PlayerName = DEFAULT_PLAYER_O_NAME


class GameUpdate(BaseModel):
    """Rename one or both players. Leave a field out to keep that name."""

    model_config = ConfigDict(extra="forbid")

    player_x_name: PlayerName | None = None
    player_o_name: PlayerName | None = None

    @model_validator(mode="after")
    def names_cannot_be_null(self) -> Self:
        # Leaving a field out means "keep it"; sending null would mean "no name".
        for field in ("player_x_name", "player_o_name"):
            if field in self.model_fields_set and getattr(self, field) is None:
                raise ValueError(f"{field} cannot be null. Leave it out to keep the current name.")
        return self


class MoveCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    board_index: Position
    cell_index: Position


class MoveRead(BaseModel):
    sequence: int
    player: Player
    board_index: int
    cell_index: int
    created_at: datetime


class TallyRead(BaseModel):
    """Results of finished games (deleted games left out), from this game's point
    of view: ``player_x_wins`` are wins by whoever is X in this game, matched by
    name, whatever letter they had when they won (D-037)."""

    player_x_wins: int
    player_o_wins: int
    draws: int
    games_played: int

    @classmethod
    def from_tally(cls, tally: Tally) -> Self:
        return cls(
            player_x_wins=tally.player_x_wins,
            player_o_wins=tally.player_o_wins,
            draws=tally.draws,
            games_played=tally.games_played,
        )


class RecordRead(BaseModel):
    # This rematch series only.
    series: TallyRead
    # Every game between these two names.
    head_to_head: TallyRead
    # Games in the series so far, including unfinished ones.
    games_in_series: int


class GameSummary(BaseModel):
    """One row in the saved-games list."""

    id: int
    player_x_name: str
    player_o_name: str
    status: GameStatus
    next_player: Player | None
    move_count: int
    created_at: datetime
    last_played_at: datetime
    record: RecordRead

    @classmethod
    def from_view(cls, view: GameView) -> Self:
        return cls(
            id=view.game.id,
            player_x_name=view.game.player_x_name,
            player_o_name=view.game.player_o_name,
            status=view.state.status,
            next_player=view.state.next_player,
            move_count=view.state.move_count,
            created_at=view.game.created_at,
            last_played_at=view.last_played_at,
            record=RecordRead(
                series=TallyRead.from_tally(view.record.series),
                head_to_head=TallyRead.from_tally(view.record.head_to_head),
                games_in_series=view.record.games_in_series,
            ),
        )


class GameDetail(GameSummary):
    """A whole game: enough to draw the board and carry on playing."""

    # None means the next player may choose any open board (or the game is over).
    required_board: int | None
    # board_statuses[b] is the state of small board b.
    board_statuses: list[BoardStatus]
    # cells[b][c] is who holds cell c of small board b, or null if it is empty.
    cells: list[list[Player | None]]
    moves: list[MoveRead]

    @classmethod
    def from_view(cls, view: GameView) -> Self:
        summary = GameSummary.from_view(view)
        return cls(
            **summary.model_dump(),
            required_board=view.state.required_board,
            board_statuses=list(view.state.board_statuses),
            cells=[list(board) for board in view.state.cells],
            moves=[
                MoveRead(
                    sequence=m.sequence,
                    player=player_for_sequence(m.sequence),
                    board_index=m.board_index,
                    cell_index=m.cell_index,
                    created_at=m.created_at,
                )
                for m in view.shown_moves
            ],
        )
