from pydantic import BaseModel


class ErrorResponse(BaseModel):
    """The one error shape every endpoint returns."""

    code: str
    detail: str


class Page[T](BaseModel):
    """The one list shape every list endpoint returns."""

    items: list[T]
    total: int
    page: int
    page_size: int
