from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.v1 import api_router
from app.api.v1.errors import register_error_handlers
from app.core.database import engine


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    # The schema is created by Alembic (`alembic upgrade head`), not at startup.
    yield
    engine.dispose()


def create_app() -> FastAPI:
    app = FastAPI(title="Ultimate Tic-Tac-Toe API", version="0.1.0", lifespan=lifespan)
    app.include_router(api_router)
    register_error_handlers(app)
    return app


app = create_app()
