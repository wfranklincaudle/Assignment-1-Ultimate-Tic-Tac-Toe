from datetime import datetime

from sqlalchemy import CheckConstraint, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base, UTCDateTime, utc_now

PLAYER_NAME_MAX_LENGTH = 25


class Game(Base):
    """A saved game. Only names and moves are stored; everything else is derived (D-004)."""

    __tablename__ = "games"

    id: Mapped[int] = mapped_column(primary_key=True)
    player_x_name: Mapped[str] = mapped_column(String(PLAYER_NAME_MAX_LENGTH))
    player_o_name: Mapped[str] = mapped_column(String(PLAYER_NAME_MAX_LENGTH))
    is_archived: Mapped[bool] = mapped_column(default=False)
    # Games linked by rematches form a series (D-037). This is the id of the
    # series' first game. It is NULL on that first game itself (and on any game
    # that was never rematched), whose own id is then the series id; see
    # ``series_key``.
    series_id: Mapped[int | None] = mapped_column(ForeignKey("games.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utc_now)

    @property
    def series_key(self) -> int:
        """The id that identifies this game's series."""
        return self.series_id if self.series_id is not None else self.id

    moves: Mapped[list["GameMove"]] = relationship(
        back_populates="game",
        order_by="GameMove.sequence",
        cascade="all, delete-orphan",
    )


class GameMove(Base):
    """One move. Which player made it is derived from ``sequence`` (even = X)."""

    __tablename__ = "moves"
    __table_args__ = (
        # The database refuses a second move with the same number (D-014)...
        UniqueConstraint("game_id", "sequence"),
        # ...and a second move into the same cell.
        UniqueConstraint("game_id", "board_index", "cell_index"),
        CheckConstraint("sequence >= 0", name="sequence_not_negative"),
        CheckConstraint("board_index BETWEEN 0 AND 8", name="board_index_range"),
        CheckConstraint("cell_index BETWEEN 0 AND 8", name="cell_index_range"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id"), index=True)
    sequence: Mapped[int]
    board_index: Mapped[int]
    cell_index: Mapped[int]
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utc_now)

    game: Mapped[Game] = relationship(back_populates="moves")
