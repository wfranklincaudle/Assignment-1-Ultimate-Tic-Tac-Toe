"""Error types shared across layers.

Services raise these. They carry a machine-readable ``code`` and a human ``detail``
so the API layer can turn them into the standard error envelope without knowing
anything about the rule that failed.
"""


class DomainError(Exception):
    """A business rule refused a request. The API layer maps this to 409."""

    def __init__(self, code: str, detail: str) -> None:
        super().__init__(detail)
        self.code = code
        self.detail = detail


class NotFoundError(Exception):
    """The requested resource does not exist. The API layer maps this to 404."""

    def __init__(self, code: str, detail: str) -> None:
        super().__init__(detail)
        self.code = code
        self.detail = detail


class StaleWriteError(Exception):
    """A write lost a race with another write to the same data (D-014).

    Raised by repositories; services decide what it means for the caller.
    """
