"""Application settings, read from the environment or a .env file (D-010)."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # SQLite by default. For PostgreSQL use postgresql+psycopg://user:pass@host/db
    database_url: str = "sqlite:///./ultimate_ttt.db"


@lru_cache
def get_settings() -> Settings:
    return Settings()
