"""HTTP contract for /api/v1/games: status codes, headers, and body shapes."""

from typing import Any

import httpx
import pytest

from tests.game_fixtures import X_WINS_TOP_ROW

pytestmark = pytest.mark.anyio

SUMMARY_KEYS = {
    "id",
    "player_x_name",
    "player_o_name",
    "status",
    "next_player",
    "move_count",
    "created_at",
    "last_played_at",
    "record",
}
DETAIL_KEYS = SUMMARY_KEYS | {"required_board", "board_statuses", "cells", "moves"}


async def create(client: httpx.AsyncClient, **names: str) -> dict[str, Any]:
    response = await client.post("/api/v1/games", json=names)
    assert response.status_code == 201
    body: dict[str, Any] = response.json()
    return body


async def move(client: httpx.AsyncClient, game_id: int, board: int, cell: int) -> httpx.Response:
    return await client.post(
        f"/api/v1/games/{game_id}/moves", json={"board_index": board, "cell_index": cell}
    )


def assert_error(response: httpx.Response, status: int, code: str) -> None:
    assert response.status_code == status
    body = response.json()
    assert set(body) == {"code", "detail"}
    assert body["code"] == code
    assert body["detail"]


# --- POST /games -------------------------------------------------------------


async def test_create_game_returns_201_location_and_an_empty_board(
    client: httpx.AsyncClient,
) -> None:
    response = await client.post("/api/v1/games", json={})

    assert response.status_code == 201
    body = response.json()
    assert response.headers["Location"] == f"/api/v1/games/{body['id']}"
    assert set(body) == DETAIL_KEYS
    assert body["player_x_name"] == "Player X"
    assert body["player_o_name"] == "Player O"
    assert body["status"] == "in_progress"
    assert body["next_player"] == "x"
    assert body["required_board"] is None
    assert body["board_statuses"] == ["open"] * 9
    assert body["cells"] == [[None] * 9] * 9
    assert body["moves"] == []
    assert body["created_at"].endswith(("Z", "+00:00"))


async def test_create_game_trims_player_names(client: httpx.AsyncClient) -> None:
    body = await create(client, player_x_name="  Ada ", player_o_name="Grace")

    assert (body["player_x_name"], body["player_o_name"]) == ("Ada", "Grace")


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({"player_x_name": "   "}, id="blank name"),
        pytest.param({"player_o_name": "x" * 26}, id="name too long"),
        pytest.param({"player_x_name": None}, id="null name"),
        pytest.param({"colour": "blue"}, id="unknown field"),
    ],
)
async def test_create_game_with_invalid_body_is_422(
    client: httpx.AsyncClient, payload: dict[str, Any]
) -> None:
    response = await client.post("/api/v1/games", json=payload)

    assert_error(response, 422, "validation_error")


# --- GET /games --------------------------------------------------------------


async def test_list_games_returns_the_standard_envelope(client: httpx.AsyncClient) -> None:
    await create(client, player_x_name="Ada")
    await create(client, player_x_name="Linus")

    response = await client.get("/api/v1/games", params={"sort": "created_at"})

    assert response.status_code == 200
    body = response.json()
    assert set(body) == {"items", "total", "page", "page_size"}
    assert (body["total"], body["page"], body["page_size"]) == (2, 1, 25)
    assert [item["player_x_name"] for item in body["items"]] == ["Ada", "Linus"]
    assert set(body["items"][0]) == SUMMARY_KEYS


async def test_list_games_filters_by_q_and_pages(client: httpx.AsyncClient) -> None:
    for name in ("Ada", "Adam", "Linus"):
        await create(client, player_x_name=name)

    response = await client.get(
        "/api/v1/games", params={"q": "ada", "sort": "created_at", "page": 2, "page_size": 1}
    )

    body = response.json()
    assert body["total"] == 2
    assert [item["player_x_name"] for item in body["items"]] == ["Adam"]


async def test_list_games_leaves_out_deleted_games(client: httpx.AsyncClient) -> None:
    kept = await create(client, player_x_name="Kept")
    deleted = await create(client, player_x_name="Deleted")
    await client.post(f"/api/v1/games/{deleted['id']}/archive")

    body = (await client.get("/api/v1/games")).json()

    assert [item["id"] for item in body["items"]] == [kept["id"]]


@pytest.mark.parametrize(
    "params",
    [
        pytest.param({"sort": "player_x_name"}, id="sort field not whitelisted"),
        pytest.param({"page": 0}, id="page below 1"),
        pytest.param({"page_size": 0}, id="page_size below 1"),
        pytest.param({"page_size": 101}, id="page_size above 100"),
    ],
)
async def test_list_games_with_invalid_query_is_422(
    client: httpx.AsyncClient, params: dict[str, Any]
) -> None:
    response = await client.get("/api/v1/games", params=params)

    assert_error(response, 422, "validation_error")


# --- GET /games/{id} ---------------------------------------------------------


async def test_get_game_returns_the_full_game(client: httpx.AsyncClient) -> None:
    game = await create(client)
    await move(client, game["id"], 4, 2)

    response = await client.get(f"/api/v1/games/{game['id']}")

    assert response.status_code == 200
    body = response.json()
    assert set(body) == DETAIL_KEYS
    assert body["cells"][4][2] == "x"
    assert body["next_player"] == "o"
    assert body["required_board"] == 2
    assert [(m["sequence"], m["player"]) for m in body["moves"]] == [(0, "x")]


async def test_get_missing_game_is_404(client: httpx.AsyncClient) -> None:
    assert_error(await client.get("/api/v1/games/999"), 404, "game_not_found")


# --- PATCH /games/{id} -------------------------------------------------------


async def test_rename_players_returns_the_updated_game(client: httpx.AsyncClient) -> None:
    game = await create(client, player_x_name="Ada", player_o_name="Grace")

    response = await client.patch(f"/api/v1/games/{game['id']}", json={"player_o_name": "Ken"})

    assert response.status_code == 200
    body = response.json()
    assert set(body) == DETAIL_KEYS
    assert (body["player_x_name"], body["player_o_name"]) == ("Ada", "Ken")


async def test_rename_with_null_name_is_422(client: httpx.AsyncClient) -> None:
    game = await create(client)

    response = await client.patch(f"/api/v1/games/{game['id']}", json={"player_x_name": None})

    assert_error(response, 422, "validation_error")


async def test_rename_missing_game_is_404(client: httpx.AsyncClient) -> None:
    response = await client.patch("/api/v1/games/999", json={"player_x_name": "Ada"})

    assert_error(response, 404, "game_not_found")


# --- POST /games/{id}/archive ------------------------------------------------


async def test_archive_game_is_204_and_the_game_is_gone(client: httpx.AsyncClient) -> None:
    game = await create(client)

    response = await client.post(f"/api/v1/games/{game['id']}/archive")

    assert response.status_code == 204
    assert response.content == b""
    assert_error(await client.get(f"/api/v1/games/{game['id']}"), 404, "game_not_found")


async def test_archive_missing_game_is_404(client: httpx.AsyncClient) -> None:
    assert_error(await client.post("/api/v1/games/999/archive"), 404, "game_not_found")


# --- POST /games/{id}/moves --------------------------------------------------


async def test_make_move_returns_201_location_and_the_new_state(
    client: httpx.AsyncClient,
) -> None:
    game = await create(client)

    response = await move(client, game["id"], 0, 3)

    assert response.status_code == 201
    assert response.headers["Location"] == f"/api/v1/games/{game['id']}"
    body = response.json()
    assert set(body) == DETAIL_KEYS
    assert body["cells"][0][3] == "x"
    assert body["required_board"] == 3
    assert body["move_count"] == 1


async def test_winning_move_reports_the_winner(client: httpx.AsyncClient) -> None:
    game = await create(client)
    for board, cell in X_WINS_TOP_ROW:
        response = await move(client, game["id"], board, cell)

    body = response.json()
    assert body["status"] == "x_won"
    assert body["next_player"] is None
    assert body["board_statuses"][:5] == ["x_won", "x_won", "x_won", "o_won", "o_won"]


@pytest.mark.parametrize(
    ("setup", "attempt", "code"),
    [
        pytest.param([(0, 3)], (2, 2), "wrong_board", id="wrong board"),
        pytest.param([(0, 3), (3, 0)], (0, 3), "cell_occupied", id="cell occupied"),
        pytest.param([*X_WINS_TOP_ROW[:5], (5, 0)], (0, 6), "board_closed", id="board closed"),
        pytest.param(X_WINS_TOP_ROW, (5, 5), "game_over", id="game over"),
    ],
)
async def test_illegal_move_is_409_with_the_rule_that_refused_it(
    client: httpx.AsyncClient,
    setup: list[tuple[int, int]],
    attempt: tuple[int, int],
    code: str,
) -> None:
    game = await create(client)
    for board, cell in setup:
        await move(client, game["id"], board, cell)

    response = await move(client, game["id"], *attempt)

    assert_error(response, 409, code)


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({"board_index": 9, "cell_index": 0}, id="board above 8"),
        pytest.param({"board_index": 0, "cell_index": -1}, id="cell below 0"),
        pytest.param({"board_index": 0}, id="cell missing"),
    ],
)
async def test_make_move_with_invalid_body_is_422(
    client: httpx.AsyncClient, payload: dict[str, Any]
) -> None:
    game = await create(client)

    response = await client.post(f"/api/v1/games/{game['id']}/moves", json=payload)

    assert_error(response, 422, "validation_error")


async def test_make_move_on_missing_game_is_404(client: httpx.AsyncClient) -> None:
    assert_error(await move(client, 999, 0, 0), 404, "game_not_found")


# --- Framework errors use the same envelope ----------------------------------


async def test_unknown_url_uses_the_error_envelope(client: httpx.AsyncClient) -> None:
    assert_error(await client.get("/api/v1/nothing-here"), 404, "not_found")


async def test_wrong_method_uses_the_error_envelope(client: httpx.AsyncClient) -> None:
    assert_error(await client.delete("/api/v1/games"), 405, "method_not_allowed")


async def test_openapi_documents_the_error_envelope_for_every_error(
    client: httpx.AsyncClient,
) -> None:
    # The frontend's types are generated from this schema, so the documented
    # error shape must match what the handlers actually send.
    schema = (await client.get("/openapi.json")).json()

    error_refs = {
        response["content"]["application/json"]["schema"]["$ref"]
        for path in schema["paths"].values()
        for operation in path.values()
        for code, response in operation["responses"].items()
        if code.startswith(("4", "5"))
    }
    assert error_refs == {"#/components/schemas/ErrorResponse"}


# --- POST /games/{id}/rematch (D-035, D-037) -----------------------------------


async def test_rematch_returns_201_location_and_the_new_game_with_letters_swapped(
    client: httpx.AsyncClient,
) -> None:
    game = await create(client, player_x_name="Ada", player_o_name="Grace")
    for board, cell in X_WINS_TOP_ROW:
        await move(client, game["id"], board, cell)

    response = await client.post(f"/api/v1/games/{game['id']}/rematch")

    assert response.status_code == 201
    body = response.json()
    assert set(body) == DETAIL_KEYS
    assert response.headers["Location"] == f"/api/v1/games/{body['id']}"
    assert body["id"] != game["id"]
    assert (body["player_x_name"], body["player_o_name"]) == ("Grace", "Ada")
    # Seen from the rematch, X is Grace (no wins) and O is Ada (one win).
    assert body["record"] == {
        "series": {"player_x_wins": 0, "player_o_wins": 1, "draws": 0, "games_played": 1},
        "head_to_head": {"player_x_wins": 0, "player_o_wins": 1, "draws": 0, "games_played": 1},
        "games_in_series": 2,
    }


async def test_rematch_of_an_unfinished_game_is_409(client: httpx.AsyncClient) -> None:
    game = await create(client)

    response = await client.post(f"/api/v1/games/{game['id']}/rematch")

    assert_error(response, 409, "game_not_over")


async def test_rematch_of_a_missing_game_is_404(client: httpx.AsyncClient) -> None:
    assert_error(await client.post("/api/v1/games/999/rematch"), 404, "game_not_found")


# --- GET /games/{id}?at_move=n (D-039) ----------------------------------------


async def test_get_game_at_a_move_returns_that_position(client: httpx.AsyncClient) -> None:
    game = await create(client, player_x_name="Ada", player_o_name="Grace")
    for board, cell in X_WINS_TOP_ROW:
        await move(client, game["id"], board, cell)

    response = await client.get(f"/api/v1/games/{game['id']}", params={"at_move": 5})

    assert response.status_code == 200
    body = response.json()
    assert set(body) == DETAIL_KEYS
    assert body["move_count"] == 5
    assert body["status"] == "in_progress"
    assert body["next_player"] == "o"
    assert body["board_statuses"][0] == "x_won"
    assert [m["sequence"] for m in body["moves"]] == [0, 1, 2, 3, 4]


async def test_get_game_at_move_zero_is_the_empty_board(client: httpx.AsyncClient) -> None:
    game = await create(client)
    await move(client, game["id"], 4, 4)

    body = (await client.get(f"/api/v1/games/{game['id']}", params={"at_move": 0})).json()

    assert body["cells"] == [[None] * 9] * 9
    assert body["moves"] == []


async def test_get_game_at_a_move_past_the_end_is_404(client: httpx.AsyncClient) -> None:
    game = await create(client)

    response = await client.get(f"/api/v1/games/{game['id']}", params={"at_move": 1})

    assert_error(response, 404, "move_not_found")


async def test_get_game_at_a_negative_move_is_422(client: httpx.AsyncClient) -> None:
    game = await create(client)

    response = await client.get(f"/api/v1/games/{game['id']}", params={"at_move": -1})

    assert_error(response, 422, "validation_error")
