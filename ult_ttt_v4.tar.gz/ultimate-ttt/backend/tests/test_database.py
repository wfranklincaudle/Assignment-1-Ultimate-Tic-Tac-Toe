"""Timestamps are stored and returned as timezone-aware UTC."""

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy.exc import StatementError
from sqlalchemy.orm import Session

from app.models import Game

EASTERN = timezone(timedelta(hours=-4))


def test_timestamp_in_another_timezone_is_returned_as_utc(session: Session) -> None:
    game = Game(
        player_x_name="Ada",
        player_o_name="Grace",
        created_at=datetime(2026, 9, 28, 11, 0, tzinfo=EASTERN),
    )
    session.add(game)
    session.commit()
    session.expunge_all()

    loaded = session.get(Game, game.id)

    assert loaded is not None
    assert loaded.created_at.utcoffset() == timedelta(0)
    assert loaded.created_at.hour == 15  # 11:00 at UTC-4 is 15:00 UTC


def test_timestamp_without_a_timezone_is_refused(session: Session) -> None:
    session.add(Game(player_x_name="Ada", player_o_name="Grace", created_at=datetime(2026, 9, 28)))

    with pytest.raises(StatementError, match="timezone-aware"):
        session.commit()
