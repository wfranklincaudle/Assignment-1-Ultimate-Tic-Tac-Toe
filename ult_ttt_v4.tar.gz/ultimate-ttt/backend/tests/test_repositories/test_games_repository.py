"""Filtering, sorting, pagination and writes for GameRepository."""

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy.orm import Session

from app.core.errors import StaleWriteError
from app.models import Game, GameMove
from app.repositories.games import GameRepository, GameSort

START = datetime(2026, 9, 1, 12, 0, tzinfo=UTC)


def add_game(
    session: Session,
    *,
    x: str = "Ada",
    o: str = "Grace",
    created: datetime = START,
    move_times: list[datetime] | None = None,
    archived: bool = False,
) -> Game:
    game = Game(player_x_name=x, player_o_name=o, created_at=created, is_archived=archived)
    for sequence, played_at in enumerate(move_times or []):
        game.moves.append(
            GameMove(sequence=sequence, board_index=sequence, cell_index=0, created_at=played_at)
        )
    session.add(game)
    session.commit()
    return game


def names(repository: GameRepository, **kwargs: object) -> list[str]:
    params: dict[str, object] = {"q": None, "sort": GameSort.CREATED_AT, "page": 1, "page_size": 25}
    params.update(kwargs)
    page = repository.list_page(**params)  # type: ignore[arg-type]
    return [row.game.player_x_name for row in page.rows]


# --- get ---------------------------------------------------------------------


def test_get_returns_the_game_with_its_moves(session: Session, repository: GameRepository) -> None:
    game = add_game(session, move_times=[START + timedelta(minutes=1)])

    row = repository.get(game.id)

    assert row is not None
    assert row.game.id == game.id
    assert [m.sequence for m in row.game.moves] == [0]


def test_get_returns_none_for_a_missing_game(repository: GameRepository) -> None:
    assert repository.get(999) is None


def test_get_skips_archived_games_unless_asked(
    session: Session, repository: GameRepository
) -> None:
    game = add_game(session, archived=True)

    assert repository.get(game.id) is None
    assert repository.get(game.id, include_archived=True) is not None


# --- last_played_at (D-012) --------------------------------------------------


def test_last_played_at_is_the_time_of_the_latest_move(
    session: Session, repository: GameRepository
) -> None:
    latest = START + timedelta(hours=2)
    game = add_game(session, move_times=[START + timedelta(hours=1), latest])

    row = repository.get(game.id)

    assert row is not None
    assert row.last_played_at == latest


def test_last_played_at_falls_back_to_created_at_with_no_moves(
    session: Session, repository: GameRepository
) -> None:
    game = add_game(session, created=START)

    row = repository.get(game.id)

    assert row is not None
    assert row.last_played_at == START
    assert row.last_played_at.tzinfo is not None


# --- filtering ---------------------------------------------------------------


def test_q_matches_either_player_name_ignoring_case(
    session: Session, repository: GameRepository
) -> None:
    add_game(session, x="Ada", o="Grace")
    add_game(session, x="Linus", o="Ada Lovelace")
    add_game(session, x="Ken", o="Dennis")

    assert names(repository, q="ada") == ["Ada", "Linus"]


def test_q_with_no_match_returns_an_empty_page(
    session: Session, repository: GameRepository
) -> None:
    add_game(session)

    page = repository.list_page(q="nobody", sort=GameSort.CREATED_AT, page=1, page_size=25)

    assert page.rows == []
    assert page.total == 0


def test_archived_games_are_left_out_of_the_list_unless_asked(
    session: Session, repository: GameRepository
) -> None:
    add_game(session, x="Kept")
    add_game(session, x="Deleted", archived=True)

    assert names(repository) == ["Kept"]
    assert names(repository, include_archived=True) == ["Kept", "Deleted"]


# --- sorting -----------------------------------------------------------------


def test_sort_by_created_at_both_directions(session: Session, repository: GameRepository) -> None:
    add_game(session, x="Second", created=START + timedelta(days=1))
    add_game(session, x="First", created=START)
    add_game(session, x="Third", created=START + timedelta(days=2))

    assert names(repository, sort=GameSort.CREATED_AT) == ["First", "Second", "Third"]
    assert names(repository, sort=GameSort.CREATED_AT_DESC) == ["Third", "Second", "First"]


def test_sort_by_last_played_at_uses_moves_then_creation_time(
    session: Session, repository: GameRepository
) -> None:
    # Created first but played most recently.
    add_game(session, x="Old but active", created=START, move_times=[START + timedelta(days=5)])
    # Never played; its creation time counts.
    add_game(session, x="New, unplayed", created=START + timedelta(days=3))
    add_game(session, x="Played long ago", created=START, move_times=[START + timedelta(days=1)])

    assert names(repository, sort=GameSort.LAST_PLAYED_AT_DESC) == [
        "Old but active",
        "New, unplayed",
        "Played long ago",
    ]
    assert names(repository, sort=GameSort.LAST_PLAYED_AT) == [
        "Played long ago",
        "New, unplayed",
        "Old but active",
    ]


def test_equal_timestamps_are_ordered_by_id(session: Session, repository: GameRepository) -> None:
    add_game(session, x="A")
    add_game(session, x="B")

    assert names(repository, sort=GameSort.CREATED_AT) == ["A", "B"]
    assert names(repository, sort=GameSort.CREATED_AT_DESC) == ["B", "A"]


# --- pagination --------------------------------------------------------------


@pytest.fixture
def five_games(session: Session) -> None:
    for i in range(5):
        add_game(session, x=f"G{i}", created=START + timedelta(minutes=i))


@pytest.mark.usefixtures("five_games")
@pytest.mark.parametrize(
    ("page", "page_size", "expected"),
    [
        pytest.param(1, 2, ["G0", "G1"], id="first page"),
        pytest.param(3, 2, ["G4"], id="last page, partly full"),
        pytest.param(4, 2, [], id="page past the end"),
        pytest.param(2, 1, ["G1"], id="page_size 1"),
        pytest.param(1, 100, ["G0", "G1", "G2", "G3", "G4"], id="page_size at maximum"),
    ],
)
def test_pagination_boundaries(
    repository: GameRepository, page: int, page_size: int, expected: list[str]
) -> None:
    result = repository.list_page(q=None, sort=GameSort.CREATED_AT, page=page, page_size=page_size)

    assert [row.game.player_x_name for row in result.rows] == expected
    assert result.total == 5  # the total counts every match, not just this page


# --- writes ------------------------------------------------------------------


def test_add_move_saves_the_move(session: Session, repository: GameRepository) -> None:
    game = add_game(session)

    repository.add_move(game, sequence=0, board_index=4, cell_index=4)

    session.expire_all()
    row = repository.get(game.id)
    assert row is not None
    assert [(m.sequence, m.board_index, m.cell_index) for m in row.game.moves] == [(0, 4, 4)]


def test_add_move_with_a_taken_sequence_raises_stale_write(
    session: Session, repository: GameRepository
) -> None:
    game = add_game(session, move_times=[START])  # sequence 0 already exists

    with pytest.raises(StaleWriteError):
        repository.add_move(game, sequence=0, board_index=8, cell_index=8)

    # The failed write is rolled back and the session can still be used.
    row = repository.get(game.id)
    assert row is not None
    assert len(row.game.moves) == 1
