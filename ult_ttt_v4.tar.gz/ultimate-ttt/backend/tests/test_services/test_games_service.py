"""GameService: loading, renaming, deleting and playing saved games."""

from pathlib import Path

import pytest
from sqlalchemy import inspect
from sqlalchemy.orm import Session, sessionmaker

from app.core.database import Base, build_engine
from app.core.errors import DomainError, NotFoundError
from app.models import Game, GameMove
from app.repositories.games import GameRepository, GameSort
from app.services.games import GameService, GameView
from app.services.rules import BoardStatus, GameStatus, MoveRejectedError, MoveRejection, Player
from tests.conftest import StatementLog
from tests.game_fixtures import X_WINS_TOP_ROW


def new_game(service: GameService) -> GameView:
    return service.create_game(player_x_name="Ada", player_o_name="Grace")


def play(service: GameService, game_id: int, positions: list[tuple[int, int]]) -> GameView:
    view = service.get_game(game_id)
    for board, cell in positions:
        view = service.make_move(game_id, board_index=board, cell_index=cell)
    return view


def assert_not_found(error: pytest.ExceptionInfo[NotFoundError]) -> None:
    assert error.value.code == "game_not_found"


# --- create and get ----------------------------------------------------------


def test_created_game_is_empty_with_x_to_move(service: GameService) -> None:
    view = new_game(service)

    assert view.game.player_x_name == "Ada"
    assert view.game.player_o_name == "Grace"
    assert view.state.move_count == 0
    assert view.state.next_player is Player.X
    assert view.last_played_at == view.game.created_at


def test_get_missing_game_is_not_found(service: GameService) -> None:
    with pytest.raises(NotFoundError) as caught:
        service.get_game(999)
    assert_not_found(caught)


def test_resumed_game_has_the_state_it_was_left_in(service: GameService, session: Session) -> None:
    game_id = new_game(service).game.id
    play(service, game_id, [(0, 3), (3, 0)])

    session.expunge_all()  # force a fresh read, as a new request would do
    resumed = service.get_game(game_id)

    assert resumed.state.move_count == 2
    assert resumed.state.next_player is Player.X
    assert resumed.state.required_board == 0


# --- list --------------------------------------------------------------------


def test_list_reports_each_games_status(service: GameService) -> None:
    finished = new_game(service).game.id
    play(service, finished, X_WINS_TOP_ROW)
    new_game(service)

    result = service.list_games(q=None, sort=GameSort.CREATED_AT, page=1, page_size=25)

    assert [v.state.status for v in result.items] == [GameStatus.X_WON, GameStatus.IN_PROGRESS]
    assert (result.total, result.page, result.page_size) == (2, 1, 25)


# --- rename (D-008) ----------------------------------------------------------


def test_rename_both_players(service: GameService) -> None:
    game_id = new_game(service).game.id

    view = service.rename_players(game_id, player_x_name="Linus", player_o_name="Ken")

    assert (view.game.player_x_name, view.game.player_o_name) == ("Linus", "Ken")


def test_rename_one_player_keeps_the_other(service: GameService) -> None:
    game_id = new_game(service).game.id

    view = service.rename_players(game_id, player_x_name=None, player_o_name="Ken")

    assert (view.game.player_x_name, view.game.player_o_name) == ("Ada", "Ken")


def test_rename_is_allowed_after_the_game_is_over(service: GameService) -> None:
    game_id = new_game(service).game.id
    play(service, game_id, X_WINS_TOP_ROW)

    view = service.rename_players(game_id, player_x_name="Winner", player_o_name=None)

    assert view.game.player_x_name == "Winner"
    assert view.state.status is GameStatus.X_WON


def test_rename_missing_game_is_not_found(service: GameService) -> None:
    with pytest.raises(NotFoundError) as caught:
        service.rename_players(999, player_x_name="A", player_o_name=None)
    assert_not_found(caught)


# --- archive (D-009) ---------------------------------------------------------


def test_archived_game_is_kept_but_treated_as_gone(
    service: GameService, repository: GameRepository
) -> None:
    game_id = new_game(service).game.id

    service.archive_game(game_id)

    with pytest.raises(NotFoundError):
        service.get_game(game_id)
    # Soft delete: the row is still there.
    assert repository.get(game_id, include_archived=True) is not None


@pytest.mark.parametrize(
    "action",
    [
        pytest.param(lambda s, g: s.archive_game(g), id="archive again"),
        pytest.param(lambda s, g: s.make_move(g, board_index=0, cell_index=0), id="move"),
        pytest.param(
            lambda s, g: s.rename_players(g, player_x_name="A", player_o_name=None), id="rename"
        ),
        pytest.param(lambda s, g: s.rematch(g), id="rematch"),
    ],
)
def test_archived_game_cannot_be_changed(service: GameService, action: object) -> None:
    game_id = new_game(service).game.id
    service.archive_game(game_id)

    with pytest.raises(NotFoundError) as caught:
        action(service, game_id)  # type: ignore[operator]
    assert_not_found(caught)


# --- making moves ------------------------------------------------------------


def test_legal_move_is_saved_and_returns_the_new_state(
    service: GameService, session: Session
) -> None:
    game_id = new_game(service).game.id

    view = service.make_move(game_id, board_index=4, cell_index=2)

    assert view.state.cells[4][2] is Player.X
    assert view.state.required_board == 2
    session.expunge_all()
    assert service.get_game(game_id).state.move_count == 1


def test_illegal_move_is_refused_and_nothing_is_saved(
    service: GameService, session: Session
) -> None:
    game_id = new_game(service).game.id
    service.make_move(game_id, board_index=0, cell_index=3)  # O must now play in board 3

    with pytest.raises(MoveRejectedError) as caught:
        service.make_move(game_id, board_index=2, cell_index=2)

    assert caught.value.reason is MoveRejection.WRONG_BOARD
    session.expunge_all()
    assert service.get_game(game_id).state.move_count == 1


def test_move_on_a_missing_game_is_not_found(service: GameService) -> None:
    with pytest.raises(NotFoundError) as caught:
        service.make_move(999, board_index=0, cell_index=0)
    assert_not_found(caught)


def test_move_that_loses_a_race_is_refused_as_stale(tmp_path: Path) -> None:
    """Two requests validate against the same state; only the first may save (D-014)."""
    engine = build_engine(f"sqlite:///{tmp_path / 'race.db'}")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)

    with factory() as setup:
        game = Game(player_x_name="Ada", player_o_name="Grace")
        setup.add(game)
        setup.commit()
        game_id = game.id

    class RacingRepository(GameRepository):
        """Lets a second request save its move just before this one does."""

        def add_move(self, game: Game, *, sequence: int, board_index: int, cell_index: int) -> None:
            with factory() as other_request:
                other_request.add(
                    GameMove(game_id=game.id, sequence=sequence, board_index=8, cell_index=8)
                )
                other_request.commit()
            super().add_move(
                game, sequence=sequence, board_index=board_index, cell_index=cell_index
            )

    with factory() as session:
        service = GameService(RacingRepository(session))
        with pytest.raises(DomainError) as caught:
            service.make_move(game_id, board_index=0, cell_index=0)

    assert caught.value.code == "stale_game"
    with factory() as check:
        saved = GameService(GameRepository(check)).get_game(game_id)
    assert [(m.board_index, m.cell_index) for m in saved.game.moves] == [(8, 8)]
    engine.dispose()


# --- derived values are computed, not stored (D-004) -------------------------

DERIVED_FIELDS = {
    "status": lambda v: v.state.status is GameStatus.X_WON,
    "next_player": lambda v: v.state.next_player is None,
    "required_board": lambda v: v.state.required_board is None,
    "board_statuses": lambda v: v.state.board_statuses[3] is BoardStatus.O_WON,
    "cells": lambda v: v.state.cells[0][3] is Player.X,
    "move_count": lambda v: v.state.move_count == len(X_WINS_TOP_ROW),
    "last_played_at": lambda v: v.last_played_at == v.game.moves[-1].created_at,
    "record": lambda v: v.record.series.player_x_wins == 1,
}


@pytest.mark.parametrize("field", DERIVED_FIELDS)
def test_derived_field_is_computed_on_read_not_stored(
    field: str, service: GameService, session: Session, statement_log: StatementLog
) -> None:
    game_id = new_game(service).game.id
    play(service, game_id, X_WINS_TOP_ROW)
    session.expunge_all()
    statement_log.statements.clear()

    view = service.get_game(game_id)

    assert DERIVED_FIELDS[field](view)
    assert statement_log.writes == []  # reading the game wrote nothing
    stored_columns = {
        column["name"]
        for table in ("games", "moves")
        for column in inspect(session.get_bind()).get_columns(table)
    }
    assert field not in stored_columns
