"""Rematch series and win/draw tallies (DECISIONS.md D-035, D-037)."""

import pytest

from app.core.errors import DomainError, NotFoundError
from app.repositories.games import GameRepository, GameSort
from app.services.games import GameService, GameView, Tally
from tests.game_fixtures import DRAWN_GAME, X_WINS_TOP_ROW, Position

# X opens in a corner that sends O to board 0; O then follows X's winning plan.
O_WINS: list[Position] = [(8, 0), *X_WINS_TOP_ROW]


def start(service: GameService, x: str = "Ada", o: str = "Grace") -> GameView:
    return service.create_game(player_x_name=x, player_o_name=o)


def play(service: GameService, game_id: int, positions: list[Position]) -> GameView:
    view = service.get_game(game_id)
    for board, cell in positions:
        view = service.make_move(game_id, board_index=board, cell_index=cell)
    return view


def tally(x_wins: int, o_wins: int, draws: int) -> Tally:
    return Tally(
        player_x_wins=x_wins,
        player_o_wins=o_wins,
        draws=draws,
        games_played=x_wins + o_wins + draws,
    )


# --- Starting a rematch --------------------------------------------------------


def test_rematch_swaps_the_letters_and_joins_the_same_series(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, X_WINS_TOP_ROW)

    rematch = service.rematch(first.game.id)

    assert (rematch.game.player_x_name, rematch.game.player_o_name) == ("Grace", "Ada")
    assert rematch.game.id != first.game.id
    assert rematch.game.series_key == first.game.series_key
    assert rematch.state.move_count == 0
    assert rematch.record.games_in_series == 2


def test_rematch_after_a_draw_is_allowed(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, DRAWN_GAME)

    rematch = service.rematch(first.game.id)

    assert rematch.game.player_x_name == "Grace"


def test_rematch_is_refused_while_the_game_is_being_played(
    service: GameService, repository: GameRepository
) -> None:
    first = start(service)
    play(service, first.game.id, X_WINS_TOP_ROW[:4])

    with pytest.raises(DomainError) as caught:
        service.rematch(first.game.id)

    assert caught.value.code == "game_not_over"
    page = repository.list_page(q=None, sort=GameSort.CREATED_AT, page=1, page_size=25)
    assert page.total == 1  # no rematch was created


def test_rematch_of_a_rematch_stays_in_the_first_games_series(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, X_WINS_TOP_ROW)
    second = service.rematch(first.game.id)
    play(service, second.game.id, X_WINS_TOP_ROW)

    third = service.rematch(second.game.id)

    assert (third.game.player_x_name, third.game.player_o_name) == ("Ada", "Grace")
    assert third.game.series_key == first.game.id
    assert third.record.games_in_series == 3


def test_rematch_of_a_missing_game_is_not_found(service: GameService) -> None:
    with pytest.raises(NotFoundError) as caught:
        service.rematch(999)
    assert caught.value.code == "game_not_found"


# --- The series tally -----------------------------------------------------------


def test_a_new_game_starts_with_an_empty_tally(service: GameService) -> None:
    view = start(service)

    assert view.record.series == tally(0, 0, 0)
    assert view.record.head_to_head == tally(0, 0, 0)
    assert view.record.games_in_series == 1


def test_series_tally_follows_each_player_when_the_letters_swap(service: GameService) -> None:
    first = start(service)  # Ada is X
    play(service, first.game.id, X_WINS_TOP_ROW)  # Ada wins as X
    second = service.rematch(first.game.id)  # Grace is X, Ada is O
    play(service, second.game.id, O_WINS)  # Ada wins again, as O

    # Seen from the rematch: X is Grace (0 wins), O is Ada (2 wins).
    assert service.get_game(second.game.id).record.series == tally(0, 2, 0)
    # Seen from the first game: X is Ada.
    assert service.get_game(first.game.id).record.series == tally(2, 0, 0)


def test_draws_count_and_unfinished_games_do_not(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, DRAWN_GAME)
    second = service.rematch(first.game.id)
    play(service, second.game.id, X_WINS_TOP_ROW[:3])  # still being played

    record = service.get_game(second.game.id).record

    assert record.series == tally(0, 0, 1)
    assert record.games_in_series == 2


def test_a_deleted_game_is_removed_from_both_tallies(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, X_WINS_TOP_ROW)  # Ada wins
    second = service.rematch(first.game.id)
    play(service, second.game.id, X_WINS_TOP_ROW)  # Grace wins (she is X)

    service.archive_game(first.game.id)

    record = service.get_game(second.game.id).record
    assert record.series == tally(1, 0, 0)  # only Grace's win is left
    assert record.head_to_head == tally(1, 0, 0)
    assert record.games_in_series == 1


# --- The head-to-head tally -----------------------------------------------------


def test_head_to_head_counts_every_game_between_the_two_names(service: GameService) -> None:
    # Series 1: Ada (X) beats Grace.
    one = start(service, "Ada", "Grace")
    play(service, one.game.id, X_WINS_TOP_ROW)
    # Series 2, started separately, names the other way round and in other case.
    two = start(service, "grace", "ADA")
    play(service, two.game.id, X_WINS_TOP_ROW)  # grace (X) wins
    # A game with someone else does not count.
    other = start(service, "Ada", "Linus")
    play(service, other.game.id, X_WINS_TOP_ROW)

    record = service.get_game(one.game.id).record

    assert record.series == tally(1, 0, 0)  # just its own series
    assert record.head_to_head == tally(1, 1, 0)  # Ada 1, Grace 1


def test_when_both_players_share_a_name_a_win_counts_for_both(service: GameService) -> None:
    view = start(service, "Sam", "Sam")
    play(service, view.game.id, X_WINS_TOP_ROW)

    record = service.get_game(view.game.id).record

    assert (record.series.player_x_wins, record.series.player_o_wins) == (1, 1)


def test_list_includes_each_games_tally(service: GameService) -> None:
    first = start(service)
    play(service, first.game.id, X_WINS_TOP_ROW)
    service.rematch(first.game.id)

    result = service.list_games(q=None, sort=GameSort.CREATED_AT, page=1, page_size=25)

    first_view, rematch_view = result.items
    assert first_view.record.series == tally(1, 0, 0)  # Ada is X here
    assert rematch_view.record.series == tally(0, 1, 0)  # Ada is O here
    assert rematch_view.record.games_in_series == 2


def test_list_of_nothing_needs_no_tally_query(service: GameService) -> None:
    result = service.list_games(q="nobody", sort=GameSort.CREATED_AT, page=1, page_size=25)

    assert result.items == []
