"""Tests for the Ultimate Tic-Tac-Toe rules engine (DECISIONS.md D-001).

Each rule gets one test where it permits a move and one where it refuses,
asserting the specific rejection code.

Positions are (board, cell), both numbered 0-8 in reading order.
"""

import pytest

from app.services.rules import (
    BoardStatus,
    GameState,
    GameStatus,
    Move,
    MoveRejectedError,
    MoveRejection,
    Player,
    apply_move,
    initial_state,
    replay,
)
from tests.game_fixtures import (
    DRAWN_GAME,
    SENT_TO_DRAWN_BOARD,
    X_DRAW_X_DIAGONAL,
    X_WINS_TOP_ROW,
    Position,
)


def play(positions: list[Position]) -> GameState:
    return replay(Move(board, cell) for board, cell in positions)


def assert_rejected(state: GameState, move: Move, reason: MoveRejection) -> None:
    with pytest.raises(MoveRejectedError) as caught:
        apply_move(state, move)
    assert caught.value.reason is reason
    assert caught.value.code == reason.value
    assert caught.value.detail  # a human-readable sentence is always present


# --- Starting position (rule 1) ---------------------------------------------


def test_new_game_has_x_to_move_anywhere_on_open_boards() -> None:
    state = initial_state()

    assert state.status is GameStatus.IN_PROGRESS
    assert state.next_player is Player.X
    assert state.required_board is None
    assert state.board_statuses == (BoardStatus.OPEN,) * 9
    assert state.move_count == 0


@pytest.mark.parametrize("position", [(0, 0), (4, 4), (8, 8), (2, 6)])
def test_first_move_may_go_in_any_cell_of_any_board(position: Position) -> None:
    board, cell = position

    state = apply_move(initial_state(), Move(board, cell))

    assert state.cells[board][cell] is Player.X
    assert state.move_count == 1


def test_turns_alternate_between_x_and_o() -> None:
    after_one = play([(0, 3)])
    after_two = play([(0, 3), (3, 0)])

    assert after_one.next_player is Player.O
    assert after_two.next_player is Player.X
    assert after_two.cells[3][0] is Player.O


def test_applying_a_move_leaves_the_previous_state_unchanged() -> None:
    before = initial_state()

    apply_move(before, Move(4, 4))

    assert before.cells[4][4] is None
    assert before.move_count == 0


# --- The send rule (rule 2) --------------------------------------------------


def test_cell_played_sends_opponent_to_matching_board() -> None:
    state = play([(0, 3)])

    assert state.required_board == 3


def test_move_in_the_required_board_is_permitted() -> None:
    state = apply_move(play([(0, 3)]), Move(3, 7))

    assert state.cells[3][7] is Player.O


def test_move_outside_the_required_board_is_refused() -> None:
    assert_rejected(play([(0, 3)]), Move(2, 2), MoveRejection.WRONG_BOARD)


# --- Occupied cells ----------------------------------------------------------


def test_move_into_an_empty_cell_of_the_required_board_is_permitted() -> None:
    # O sends X back to board 0, where X already holds cell 3.
    state = apply_move(play([(0, 3), (3, 0)]), Move(0, 4))

    assert state.cells[0][4] is Player.X


def test_move_into_an_occupied_cell_is_refused() -> None:
    assert_rejected(play([(0, 3), (3, 0)]), Move(0, 3), MoveRejection.CELL_OCCUPIED)


# --- Winning and closing a small board (rules 3, 4, 5) -----------------------


def test_three_in_a_row_wins_a_small_board() -> None:
    state = play(X_WINS_TOP_ROW[:5])

    assert state.board_statuses[0] is BoardStatus.X_WON
    assert all(status is BoardStatus.OPEN for status in state.board_statuses[1:])
    assert state.status is GameStatus.IN_PROGRESS


def test_being_sent_to_a_won_board_allows_any_open_board() -> None:
    # X has won board 0. O plays cell 0, which would send X to board 0.
    state = play([*X_WINS_TOP_ROW[:5], (5, 0)])

    assert state.required_board is None
    after = apply_move(state, Move(7, 7))
    assert after.cells[7][7] is Player.X


def test_move_into_a_won_board_is_refused_even_with_empty_cells() -> None:
    state = play([*X_WINS_TOP_ROW[:5], (5, 0)])

    assert state.cells[0][6] is None  # the cell is empty, the board is still closed
    assert_rejected(state, Move(0, 6), MoveRejection.BOARD_CLOSED)


# --- Drawn small boards (rules 4 and 6) --------------------------------------


def test_full_board_with_no_winner_is_a_draw() -> None:
    state = play(SENT_TO_DRAWN_BOARD)

    assert state.board_statuses[5] is BoardStatus.DRAW
    assert all(cell is not None for cell in state.cells[5])


def test_being_sent_to_a_drawn_board_allows_any_open_board() -> None:
    state = play(SENT_TO_DRAWN_BOARD)

    assert state.next_player is Player.O
    assert state.required_board is None
    after = apply_move(state, Move(0, 0))
    assert after.cells[0][0] is Player.O


def test_move_into_a_drawn_board_is_refused() -> None:
    assert_rejected(play(SENT_TO_DRAWN_BOARD), Move(5, 0), MoveRejection.BOARD_CLOSED)


def test_drawn_board_does_not_complete_a_line_for_either_player() -> None:
    state = play(X_DRAW_X_DIAGONAL)

    assert state.board_statuses[2] is BoardStatus.X_WON
    assert state.board_statuses[4] is BoardStatus.DRAW
    assert state.board_statuses[6] is BoardStatus.X_WON
    assert state.status is GameStatus.IN_PROGRESS
    assert state.next_player is not None


# --- Winning the game (rule 7) -----------------------------------------------


def test_three_small_boards_in_a_row_wins_the_game() -> None:
    state = play(X_WINS_TOP_ROW)

    assert state.status is GameStatus.X_WON
    assert state.board_statuses == (
        BoardStatus.X_WON, BoardStatus.X_WON, BoardStatus.X_WON,
        BoardStatus.O_WON, BoardStatus.O_WON, BoardStatus.OPEN,
        BoardStatus.OPEN, BoardStatus.OPEN, BoardStatus.OPEN,
    )  # fmt: skip
    assert state.next_player is None
    assert state.required_board is None


def test_o_can_win_the_game() -> None:
    # X opens with (8, 0), sending O to board 0. From there O follows X's
    # winning plan above move for move, and the roles are reversed.
    state = play([(8, 0), *X_WINS_TOP_ROW])

    assert state.status is GameStatus.O_WON
    assert state.board_statuses[:3] == (BoardStatus.O_WON,) * 3
    assert state.next_player is None


def test_move_after_the_game_is_won_is_refused() -> None:
    # Board 5 is still open, but the game is over.
    assert_rejected(play(X_WINS_TOP_ROW), Move(5, 5), MoveRejection.GAME_OVER)


# --- Drawn game (rule 8) -----------------------------------------------------


def test_game_with_every_board_finished_and_no_line_is_a_draw() -> None:
    state = play(DRAWN_GAME)

    assert state.status is GameStatus.DRAW
    assert BoardStatus.OPEN not in state.board_statuses
    assert state.next_player is None
    assert state.required_board is None


def test_move_after_a_drawn_game_is_refused() -> None:
    state = play(DRAWN_GAME)
    empty = next(
        (board, cell) for board in range(9) for cell in range(9) if state.cells[board][cell] is None
    )

    assert_rejected(state, Move(*empty), MoveRejection.GAME_OVER)


def test_game_one_move_before_the_draw_is_still_in_progress() -> None:
    state = play(DRAWN_GAME[:-1])

    assert state.status is GameStatus.IN_PROGRESS


# --- Replaying and input guards ----------------------------------------------


def test_replay_rejects_a_sequence_containing_an_illegal_move() -> None:
    with pytest.raises(MoveRejectedError) as caught:
        play([(0, 3), (3, 0), (0, 3)])

    assert caught.value.reason is MoveRejection.CELL_OCCUPIED


@pytest.mark.parametrize(("board", "cell"), [(-1, 0), (9, 0), (0, -1), (0, 9)])
def test_move_outside_the_grid_cannot_be_constructed(board: int, cell: int) -> None:
    with pytest.raises(ValueError, match="between 0 and 8"):
        Move(board, cell)
