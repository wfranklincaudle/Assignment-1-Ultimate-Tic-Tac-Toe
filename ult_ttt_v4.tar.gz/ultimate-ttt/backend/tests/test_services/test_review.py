"""Looking back at a game move by move (DECISIONS.md D-039)."""

import pytest

from app.core.errors import NotFoundError
from app.services.games import GameService, GameView
from app.services.rules import BoardStatus, GameStatus, Player
from tests.conftest import StatementLog
from tests.game_fixtures import X_WINS_TOP_ROW


def finished_game(service: GameService) -> GameView:
    view = service.create_game(player_x_name="Ada", player_o_name="Grace")
    for board, cell in X_WINS_TOP_ROW:
        view = service.make_move(view.game.id, board_index=board, cell_index=cell)
    return view


def test_move_zero_is_the_empty_board_with_x_to_play_anywhere(service: GameService) -> None:
    game = finished_game(service)

    start = service.get_game_at_move(game.game.id, 0)

    assert start.state.move_count == 0
    assert start.state.status is GameStatus.IN_PROGRESS
    assert start.state.next_player is Player.X
    assert start.state.required_board is None
    assert start.shown_moves == []


def test_a_middle_position_has_that_moment_s_board_and_turn(service: GameService) -> None:
    game = finished_game(service)

    after_five = service.get_game_at_move(game.game.id, 5)  # X has just won board 0

    assert after_five.state.board_statuses[0] is BoardStatus.X_WON
    assert after_five.state.board_statuses[1] is BoardStatus.OPEN
    assert after_five.state.status is GameStatus.IN_PROGRESS
    assert after_five.state.next_player is Player.O
    assert after_five.state.required_board == 5  # sent by the last cell played
    assert [m.sequence for m in after_five.shown_moves] == [0, 1, 2, 3, 4]
    assert after_five.state.cells[2][3] is None  # a later move is not shown


def test_the_last_move_shows_the_finished_game(service: GameService) -> None:
    game = finished_game(service)

    end = service.get_game_at_move(game.game.id, len(X_WINS_TOP_ROW))

    assert end.state == game.state
    assert len(end.shown_moves) == len(X_WINS_TOP_ROW)


def test_looking_back_keeps_the_game_s_current_tally(service: GameService) -> None:
    game = finished_game(service)

    start = service.get_game_at_move(game.game.id, 0)

    assert start.record == game.record


def test_a_move_past_the_end_is_not_found(service: GameService) -> None:
    game = finished_game(service)

    with pytest.raises(NotFoundError) as caught:
        service.get_game_at_move(game.game.id, len(X_WINS_TOP_ROW) + 1)

    assert caught.value.code == "move_not_found"
    assert "17 moves" in caught.value.detail


def test_looking_back_changes_nothing_that_is_saved(
    service: GameService, statement_log: StatementLog
) -> None:
    game = finished_game(service)
    statement_log.statements.clear()

    service.get_game_at_move(game.game.id, 3)

    assert statement_log.writes == []
    assert service.get_game(game.game.id).state == game.state
