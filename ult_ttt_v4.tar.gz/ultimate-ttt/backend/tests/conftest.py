"""Shared fixtures.

Each test gets its own empty in-memory SQLite database, so tests never see each
other's data. StaticPool keeps that one in-memory database alive across the
threads FastAPI uses to run sync endpoints.
"""

from collections.abc import AsyncIterator, Iterator
from typing import Any

import httpx
import pytest
from sqlalchemy import Engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401  (registers every model on Base.metadata)
from app.core.database import Base, build_engine, get_session
from app.main import create_app
from app.repositories.games import GameRepository
from app.services.games import GameService


@pytest.fixture
def engine() -> Iterator[Engine]:
    engine = build_engine("sqlite://", poolclass=StaticPool)
    Base.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, expire_on_commit=False)


@pytest.fixture
def session(session_factory: sessionmaker[Session]) -> Iterator[Session]:
    with session_factory() as session:
        yield session


@pytest.fixture
def repository(session: Session) -> GameRepository:
    return GameRepository(session)


@pytest.fixture
def service(repository: GameRepository) -> GameService:
    return GameService(repository)


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


@pytest.fixture
async def client(session_factory: sessionmaker[Session]) -> AsyncIterator[httpx.AsyncClient]:
    app = create_app()

    def override_session() -> Iterator[Session]:
        with session_factory() as session:
            yield session

    app.dependency_overrides[get_session] = override_session
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        yield client


class StatementLog:
    """Records every SQL statement sent to the database while active."""

    def __init__(self) -> None:
        self.statements: list[str] = []

    @property
    def writes(self) -> list[str]:
        return [
            s
            for s in self.statements
            if s.lstrip().upper().startswith(("INSERT", "UPDATE", "DELETE"))
        ]


@pytest.fixture
def statement_log(engine: Engine) -> Iterator[StatementLog]:
    log = StatementLog()

    def record(_conn: Any, _cursor: Any, statement: str, *_args: Any) -> None:
        log.statements.append(statement)

    event.listen(engine, "before_cursor_execute", record)
    yield log
    event.remove(engine, "before_cursor_execute", record)
