"""Recorded games used by several test modules. Positions are (board, cell)."""

type Position = tuple[int, int]

# Hand-built game that X wins with the top row of boards (0, 1, 2).
# X plays cells 3, 4, 5 of each target board; O answers by sending X straight back.
# Along the way O wins boards 3 and 4.
X_WINS_TOP_ROW: list[Position] = [
    (0, 3), (3, 0), (0, 4), (4, 0), (0, 5),  # X wins board 0 on move 5
    (5, 1),
    (1, 3), (3, 1), (1, 4), (4, 1), (1, 5),  # X wins board 1
    (5, 2),
    (2, 3), (3, 2), (2, 4), (4, 2), (2, 5),  # O wins boards 3, 4; X wins board 2 and the game
]  # fmt: skip

# The fixtures below were found by random play in a separate reference
# implementation (not this engine) and are replayed here as a cross-check.

# 39 moves. The last move, (0, 5), sends O to board 5, which is full with no winner.
SENT_TO_DRAWN_BOARD: list[Position] = [
    (8, 2), (2, 5), (5, 7), (7, 6), (6, 4), (4, 3), (3, 5), (5, 8), (8, 5), (5, 1),
    (1, 5), (5, 6), (6, 7), (7, 8), (8, 0), (0, 1), (1, 6), (6, 1), (1, 8), (8, 6),
    (6, 6), (6, 5), (5, 4), (4, 6), (6, 8), (8, 7), (7, 5), (5, 5), (5, 3), (3, 6),
    (5, 2), (2, 8), (8, 3), (3, 0), (0, 8), (8, 4), (4, 5), (5, 0), (0, 5),
]  # fmt: skip

# 63 moves, still in progress. The diagonal 2-4-6 is X-won, drawn, X-won,
# which must NOT count as a line for X.
X_DRAW_X_DIAGONAL: list[Position] = [
    (3, 3), (3, 2), (2, 5), (5, 7), (7, 1), (1, 0), (0, 7), (7, 5), (5, 3), (3, 1),
    (1, 8), (8, 8), (8, 7), (7, 4), (4, 2), (2, 3), (3, 8), (8, 1), (1, 7), (7, 7),
    (7, 6), (6, 0), (0, 1), (1, 2), (2, 8), (8, 5), (5, 0), (0, 3), (3, 0), (0, 4),
    (4, 8), (8, 6), (6, 7), (7, 8), (8, 4), (4, 6), (6, 8), (8, 3), (3, 7), (7, 0),
    (0, 5), (5, 1), (1, 1), (1, 4), (4, 4), (4, 1), (1, 5), (5, 6), (6, 6), (2, 4),
    (4, 7), (4, 5), (5, 8), (8, 2), (2, 7), (4, 0), (0, 2), (2, 2), (2, 6), (0, 0),
    (0, 8), (3, 4), (4, 3),
]  # fmt: skip

# 62 moves ending with every board finished and no line of boards for anyone.
DRAWN_GAME: list[Position] = [
    (8, 1), (1, 1), (1, 8), (8, 5), (5, 0), (0, 0), (0, 3), (3, 7), (7, 5), (5, 6),
    (6, 0), (0, 4), (4, 7), (7, 3), (3, 6), (6, 2), (2, 3), (3, 4), (4, 4), (4, 6),
    (6, 8), (8, 6), (6, 7), (7, 0), (0, 6), (6, 4), (4, 0), (0, 5), (5, 8), (8, 4),
    (4, 3), (3, 3), (3, 0), (0, 2), (2, 5), (5, 1), (1, 0), (0, 8), (8, 2), (2, 8),
    (8, 7), (7, 6), (6, 3), (3, 1), (1, 7), (4, 1), (1, 3), (6, 5), (5, 5), (5, 4),
    (4, 5), (5, 7), (1, 4), (2, 1), (8, 3), (8, 8), (8, 0), (2, 0), (6, 1), (2, 6),
    (6, 6), (2, 7),
]  # fmt: skip
