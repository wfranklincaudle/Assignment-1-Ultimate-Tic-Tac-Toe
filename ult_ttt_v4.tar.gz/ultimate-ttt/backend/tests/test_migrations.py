"""The Alembic migrations must build exactly the schema the models describe."""

from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.exc import IntegrityError

from app.core.database import build_engine

BACKEND_DIR = Path(__file__).resolve().parents[1]


def _alembic_config(database_url: str) -> Config:
    config = Config(str(BACKEND_DIR / "alembic.ini"))
    config.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    config.set_main_option("sqlalchemy.url", database_url)
    config.attributes["configure_logger"] = False
    return config


def test_migrations_match_the_models_and_can_be_undone(tmp_path: Path) -> None:
    url = f"sqlite:///{tmp_path / 'migrations.db'}"
    config = _alembic_config(url)

    command.upgrade(config, "head")
    # Raises if autogenerate finds any difference between models and database.
    command.check(config)

    command.downgrade(config, "base")
    engine = create_engine(url)
    assert set(inspect(engine).get_table_names()) == {"alembic_version"}
    engine.dispose()


def test_names_saved_before_the_25_character_limit_are_shortened(tmp_path: Path) -> None:
    url = f"sqlite:///{tmp_path / 'names.db'}"
    config = _alembic_config(url)
    command.upgrade(config, "0e28a57baf99")  # the schema that allowed 50 characters
    engine = create_engine(url)
    with engine.begin() as connection:
        connection.execute(
            text(
                "INSERT INTO games (player_x_name, player_o_name, is_archived, created_at) "
                "VALUES (:x, 'Grace', 0, '2026-09-01 12:00:00')"
            ),
            {"x": "A" * 40},
        )

    command.upgrade(config, "head")

    with engine.connect() as connection:
        names = connection.execute(text("SELECT player_x_name, player_o_name FROM games")).one()
    assert tuple(names) == ("A" * 25, "Grace")
    engine.dispose()


def _seed_game_with_a_move(url: str) -> None:
    engine = create_engine(url)
    with engine.begin() as connection:
        connection.execute(
            text(
                "INSERT INTO games (player_x_name, player_o_name, is_archived, created_at) "
                "VALUES ('Ada', 'Grace', 0, '2026-09-01 12:00:00')"
            )
        )
        connection.execute(
            text(
                "INSERT INTO moves (game_id, sequence, board_index, cell_index, created_at) "
                "VALUES (1, 0, 4, 4, '2026-09-01 12:01:00')"
            )
        )
    engine.dispose()


def _saved_rows(url: str) -> tuple[list[tuple[object, ...]], list[tuple[object, ...]]]:
    engine = create_engine(url)
    with engine.connect() as connection:
        games = connection.execute(text("SELECT id, player_x_name, player_o_name FROM games"))
        moves = connection.execute(text("SELECT game_id, sequence, board_index FROM moves"))
        result = ([tuple(r) for r in games], [tuple(r) for r in moves])
    engine.dispose()
    return result


def test_every_migration_runs_on_a_database_that_already_has_moves(tmp_path: Path) -> None:
    """Regression (D-040): rebuilding `games` used to fail on saved moves."""
    url = f"sqlite:///{tmp_path / 'played.db'}"
    config = _alembic_config(url)
    command.upgrade(config, "0e28a57baf99")  # the very first version
    _seed_game_with_a_move(url)

    command.upgrade(config, "head")

    assert _saved_rows(url) == ([(1, "Ada", "Grace")], [(1, 0, 4)])
    command.check(config)


def test_the_app_still_enforces_foreign_keys_after_migrating(tmp_path: Path) -> None:
    url = f"sqlite:///{tmp_path / 'keys.db'}"
    command.upgrade(_alembic_config(url), "head")

    engine = build_engine(url)  # how the app connects
    with pytest.raises(IntegrityError), engine.begin() as connection:
        connection.execute(
            text(
                "INSERT INTO moves (game_id, sequence, board_index, cell_index, created_at) "
                "VALUES (999, 0, 0, 0, '2026-09-01 12:00:00')"
            )
        )
    engine.dispose()


def test_a_migration_that_failed_partway_is_cleaned_up_and_finished(tmp_path: Path) -> None:
    """Regression (D-040): a failed attempt left `_alembic_tmp_games` behind,
    and every restart then failed with "table already exists"."""
    url = f"sqlite:///{tmp_path / 'stuck.db'}"
    config = _alembic_config(url)
    command.upgrade(config, "2f9bec88be52")
    _seed_game_with_a_move(url)
    engine = create_engine(url)
    with engine.begin() as connection:
        connection.execute(text("CREATE TABLE _alembic_tmp_games (id INTEGER)"))
    engine.dispose()

    command.upgrade(config, "head")

    engine = create_engine(url)
    assert "_alembic_tmp_games" not in inspect(engine).get_table_names()
    engine.dispose()
    assert _saved_rows(url) == ([(1, "Ada", "Grace")], [(1, 0, 4)])
