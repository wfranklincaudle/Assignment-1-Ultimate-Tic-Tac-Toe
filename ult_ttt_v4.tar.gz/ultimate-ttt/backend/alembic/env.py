"""Alembic migration environment.

The database URL comes from app settings (DATABASE_URL), never from alembic.ini,
so migrations always run against the same database as the app. A caller may
override it by setting ``sqlalchemy.url`` on the Config (the tests do this).
"""

from logging.config import fileConfig
from typing import Any, Literal

from alembic import context
from alembic.autogenerate.api import AutogenContext
from sqlalchemy import Connection, inspect, text

import app.models  # noqa: F401  (registers every model on Base.metadata)
from app.core.config import get_settings
from app.core.database import Base, UTCDateTime, build_engine

config = context.config

if config.config_file_name is not None and config.attributes.get("configure_logger", True):
    fileConfig(config.config_file_name)

target_metadata = Base.metadata
database_url = config.get_main_option("sqlalchemy.url") or get_settings().database_url


def render_item(type_: str, obj: Any, autogen_context: AutogenContext) -> str | Literal[False]:
    # Migrations must not import app code, which changes over time. UTCDateTime
    # is written into migrations as the plain column type it wraps.
    if type_ == "type" and isinstance(obj, UTCDateTime):
        return "sa.DateTime(timezone=True)"
    return False


def run_migrations_offline() -> None:
    context.configure(
        url=database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,
        render_item=render_item,
    )
    with context.begin_transaction():
        context.run_migrations()


def _remove_leftover_batch_tables(connection: Connection) -> None:
    """Clear up after a SQLite batch migration that failed partway (D-040).

    Batch mode copies a table into ``_alembic_tmp_<name>``, drops the original
    and renames the copy. If it failed before the drop, the original still holds
    every row and the copy blocks every later attempt with "already exists".
    Only copies whose original table still exists are removed, so no data can
    be lost here.
    """
    tables = set(inspect(connection).get_table_names())
    for table in sorted(tables):
        original = table.removeprefix("_alembic_tmp_")
        if table != original and original in tables:
            connection.execute(text(f'DROP TABLE "{table}"'))
    connection.commit()


def run_migrations_online() -> None:
    engine = build_engine(database_url)
    with engine.connect() as connection:
        sqlite = connection.dialect.name == "sqlite"
        if sqlite:
            _remove_leftover_batch_tables(connection)
            # Batch mode rebuilds a table by dropping and recreating it, which
            # foreign keys from other tables (moves -> games) would block. The
            # rows are copied unchanged, so the keys are switched off for the
            # rebuild and every key is checked afterwards (D-040). The setting
            # only takes effect outside a transaction.
            connection.exec_driver_sql("PRAGMA foreign_keys=OFF")
            connection.commit()

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            # SQLite cannot ALTER most things in place; batch mode rebuilds the
            # table instead. It is harmless on PostgreSQL.
            render_as_batch=True,
            render_item=render_item,
        )
        with context.begin_transaction():
            context.run_migrations()

        if sqlite:
            broken = connection.exec_driver_sql("PRAGMA foreign_key_check").fetchall()
            if broken:
                raise RuntimeError(f"Migration left rows pointing at nothing: {broken}")
            connection.exec_driver_sql("PRAGMA foreign_keys=ON")
    engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
