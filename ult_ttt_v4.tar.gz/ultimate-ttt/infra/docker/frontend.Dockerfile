# syntax=docker/dockerfile:1
#
# Frontend image. Build context: frontend/, plus an extra build context named
# "infra" pointing at infra/docker/ for nginx.conf (see docker-compose.yml).
#   docker build -f infra/docker/frontend.Dockerfile --build-context infra=infra/docker frontend

# ---- Stage 1: build the static site ------------------------------------------
FROM node:24-alpine AS build

WORKDIR /app
# Corepack installs the pnpm version pinned in package.json's "packageManager".
RUN corepack enable

COPY package.json pnpm-lock.yaml ./
RUN --mount=type=cache,id=pnpm-store,target=/root/.local/share/pnpm/store \
    pnpm install --frozen-lockfile

COPY . .
RUN pnpm build

# ---- Stage 2: serve it with nginx, not root ----------------------------------
# nginx-unprivileged runs as a non-root user and listens on 8080.
FROM nginxinc/nginx-unprivileged:1.29-alpine AS runtime

COPY --from=infra nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html

EXPOSE 8080
