# syntax=docker/dockerfile:1
#
# Backend image. Build context: backend/ (see docker-compose.yml).
#   docker build -f infra/docker/backend.Dockerfile backend

# ---- Stage 1: install dependencies with uv -----------------------------------
FROM python:3.14-slim AS build

# The same uv version the lock file was made with. The image comes from uv's own registry.
COPY --from=ghcr.io/astral-sh/uv:0.12.19 /uv /bin/uv

ENV UV_COMPILE_BYTECODE=1 \
    UV_LINK_MODE=copy \
    UV_PYTHON_DOWNLOADS=never

WORKDIR /app

# Dependencies first, so this layer is reused until uv.lock changes.
COPY pyproject.toml uv.lock .python-version ./
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --locked --no-dev

COPY alembic.ini ./
COPY alembic ./alembic
COPY app ./app

# ---- Stage 2: runtime, no build tools, not root -----------------------------
FROM python:3.14-slim AS runtime

RUN groupadd --system app \
    && useradd --system --gid app --home-dir /app --no-create-home app \
    && mkdir /data \
    && chown app:app /data

WORKDIR /app
COPY --from=build --chown=app:app /app /app

ENV PATH="/app/.venv/bin:$PATH" \
    PYTHONUNBUFFERED=1 \
    DATABASE_URL=sqlite:////data/ultimate_ttt.db

USER app
EXPOSE 8000

# Bring the database schema up to date, then start the API (DECISIONS.md D-027).
CMD ["sh", "-c", "alembic upgrade head && exec uvicorn app.main:app --host 0.0.0.0 --port 8000"]
