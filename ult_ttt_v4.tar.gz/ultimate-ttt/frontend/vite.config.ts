import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { loadEnv } from "vite";
import { defineConfig } from "vitest/config";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");

  return {
    plugins: [react(), tailwindcss()],
    server: {
      // In development the API runs separately. Proxying keeps the browser on
      // one origin, the same as production behind nginx.
      proxy: {
        "/api": env.API_PROXY_TARGET || "http://localhost:8000",
      },
    },
    test: {
      environment: "jsdom",
      setupFiles: ["./test_setup.ts"],
      include: ["src/**/*.test.{ts,tsx}"],
      coverage: {
        provider: "v8",
        include: ["src/**/*.{ts,tsx}"],
        exclude: ["src/**/*.test.{ts,tsx}", "src/test/**", "src/api/schema.d.ts", "src/main.tsx"],
        reporter: ["text", "html"],
        thresholds: { lines: 80 },
      },
    },
  };
});
