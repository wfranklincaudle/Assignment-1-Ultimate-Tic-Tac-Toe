/**
 * The one happy path through the real app, backend and all:
 * first open shows the rules → back to the home menu → start a game → name the
 * players → play until X wins → reload and find the game, names and all, as it
 * was left → open the rules and return → review it move by move → start a
 * rematch with letters swapped
 * and see the tally follow the players → find both games in Saved Games →
 * delete the first and see its win leave the tally → delete the rematch.
 */
import { expect, test, type Page } from "@playwright/test";

const POSITIONS = [
  "top left",
  "top middle",
  "top right",
  "middle left",
  "center",
  "middle right",
  "bottom left",
  "bottom middle",
  "bottom right",
];

// X wins boards 0, 1 and 2 (the top row). The same game the backend tests use.
const X_WINS_TOP_ROW: [number, number][] = [
  [0, 3], [3, 0], [0, 4], [4, 0], [0, 5], [5, 1],
  [1, 3], [3, 1], [1, 4], [4, 1], [1, 5], [5, 2],
  [2, 3], [3, 2], [2, 4], [4, 2], [2, 5],
]; // prettier-ignore

function cellName(board: number, cell: number): string {
  const boardName = POSITIONS[board] ?? "";
  return `${boardName.charAt(0).toUpperCase()}${boardName.slice(1)} board, ${POSITIONS[cell] ?? ""}`;
}

async function play(page: Page, board: number, cell: number, letter: "X" | "O") {
  const name = cellName(board, cell);
  await page.getByRole("button", { name: `${name}, empty`, exact: true }).click();
  // Wait until the server has saved the move and the board shows it.
  await expect(page.getByRole("button", { name: `${name}, ${letter}, last move` })).toBeVisible();
}

test("play a whole game, resume it, rematch, and delete both", async ({ page }) => {
  // The database may hold games from earlier runs, so these names are unique.
  const run = String(Date.now() % 100_000);
  const xName = `Ada ${run}`;
  const oName = `Grace ${run}`;
  const title = `${xName} vs ${oName}`;

  // First open in a fresh browser shows the rules; Back leads to the home menu.
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "How to play" })).toBeVisible();
  await page.getByRole("link", { name: "Back to home" }).first().click();
  const menu = page.getByRole("navigation", { name: "Start" });
  await expect(menu).toBeVisible();

  await menu.getByRole("button", { name: "New game" }).click();
  await expect(page.getByRole("heading", { name: "Player X vs Player O" })).toBeVisible();

  // Names are typed but never explicitly saved: clicking the board saves them.
  await page.getByLabel("Player X").fill(xName);
  await page.getByLabel("Player O").fill(oName);

  for (const [index, [board, cell]] of X_WINS_TOP_ROW.entries()) {
    await play(page, board, cell, index % 2 === 0 ? "X" : "O");
  }
  const status = page.getByRole("status");
  await expect(status).toHaveText(`${xName} (X) wins the game!`);

  // Everything was saved on the server: a reload shows the same finished game.
  await page.reload();
  await expect(page.getByRole("heading", { name: title })).toBeVisible();
  await expect(status).toHaveText(`${xName} (X) wins the game!`);
  await expect(page.getByRole("region", { name: "Top left board, won by X" })).toBeVisible();

  // The rules open from the game and return to it.
  await page.getByRole("link", { name: "Rules" }).click();
  await page.getByRole("link", { name: "Back to game" }).first().click();
  await expect(page.getByRole("heading", { name: title })).toBeVisible();

  // Review the finished game move by move (D-039). Positions come from the
  // real server replaying the saved moves.
  await page.getByRole("button", { name: "Review moves" }).click();
  const review = page.getByRole("navigation", { name: "Review moves" });
  await expect(review).toContainText("Move 17 of 17");
  await review.getByRole("button", { name: "First move" }).click();
  await expect(status).toHaveText(`Start of the game. ${xName} (X) moves first.`);
  await expect(
    page.getByRole("button", { name: "Top left board, middle left, empty" }),
  ).toBeVisible();
  for (let step = 1; step <= 5; step++) {
    await review.getByRole("button", { name: "Next move" }).click();
    await expect(review).toContainText(`Move ${step} of 17`);
  }
  await expect(status).toHaveText(
    `Move 5 of 17: ${xName} (X) played the middle right square of the top left board, winning that board.`,
  );
  await expect(page.getByRole("region", { name: /^Top left board, won by X/ })).toBeVisible();
  await expect(page.getByRole("region", { name: /^Top middle board, won by X/ })).toHaveCount(0);
  await review.getByRole("button", { name: "Done reviewing" }).click();
  await expect(page.getByRole("region", { name: "Rematch" })).toBeVisible();

  // A rematch swaps the letters: Grace is X now and moves first.
  const rematchTitle = `${oName} vs ${xName}`;
  await page.getByRole("button", { name: "Rematch" }).click();
  await expect(page.getByRole("heading", { name: rematchTitle })).toBeVisible();
  await expect(status).toHaveText(`${oName} (X) to move. Play in any open board.`);
  // The server's tally follows Ada to O: one win for her, none yet for Grace.
  const record = page.getByRole("region", { name: "Record" });
  await expect(record).toContainText(
    `This series (2 games): ${oName} 0 wins · ${xName} 1 win · 0 draws`,
  );
  await expect(record).toContainText(
    `All games between them: ${oName} 0 wins · ${xName} 1 win · 0 draws`,
  );

  // Opening the app again shows the home menu, not the rules.
  await page.goto("/");
  await menu.getByRole("link", { name: "Saved Games" }).click();
  await expect(page.getByRole("heading", { name: "Saved Games" })).toBeVisible();

  await page.getByLabel("Search player names").fill(run);
  await page.getByRole("button", { name: "Search" }).click();
  // Both games are saved: the finished one and the rematch.
  const listItem = page.getByRole("listitem").filter({ hasText: title });
  const rematchItem = page.getByRole("listitem").filter({ hasText: rematchTitle });
  await expect(listItem).toContainText(`${xName} (X) won`);
  await expect(listItem).toContainText("17 moves");
  await expect(rematchItem).toContainText(`${oName} (X) to move`);
  await expect(listItem).toContainText(
    `This series (2 games): ${xName} 1 win · ${oName} 0 wins · 0 draws`,
  );
  // Finished games offer Review; unfinished ones offer Resume (D-038).
  await expect(listItem.getByRole("link", { name: `Review ${title}` })).toBeVisible();
  await expect(rematchItem.getByRole("link", { name: `Resume ${rematchTitle}` })).toBeVisible();

  // Deleting the finished game takes its win off the tally (D-037).
  await listItem.getByRole("button", { name: `Delete ${title}` }).click();
  await listItem.getByRole("button", { name: "Delete game" }).click();
  await expect(listItem).toHaveCount(0);
  await rematchItem.getByRole("link", { name: `Resume ${rematchTitle}` }).click();
  await expect(page.getByRole("heading", { name: rematchTitle })).toBeVisible();
  await expect(page.getByRole("region", { name: "Record" })).toHaveCount(0);

  // Delete the rematch too, which leaves the database as it was found.
  await page.getByRole("link", { name: "Back to Saved Games" }).click();
  await page.getByLabel("Search player names").fill(run);
  await page.getByRole("button", { name: "Search" }).click();
  await rematchItem.getByRole("button", { name: `Delete ${rematchTitle}` }).click();
  await rematchItem.getByRole("button", { name: "Delete game" }).click();
  await expect(rematchItem).toHaveCount(0);
  await expect(page.getByText(`No saved games match “${run}”.`)).toBeVisible();
});
