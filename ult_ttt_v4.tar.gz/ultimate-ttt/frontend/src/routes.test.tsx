import { screen, within } from "@testing-library/react";
import type { UserEvent } from "@testing-library/user-event";
import { http } from "msw";
import { afterEach, describe, expect, it, vi } from "vitest";

import { Layout } from "./components/Layout";
import { RouteErrorPage } from "./pages/NotFoundPage";
import { seedGame } from "./test/fakeApi";
import { errorResponse } from "./test/handlers";
import { renderApp } from "./test/renderApp";
import { server } from "./test/server";

afterEach(() => {
  vi.restoreAllMocks();
});

/**
 * The Rules page has its return button at the top and the bottom, both with
 * the same name and destination. Clicks the first one.
 */
async function clickBack(user: UserEvent, name: string) {
  const [first] = await screen.findAllByRole("link", { name });
  if (!first) throw new Error(`No "${name}" link`);
  await user.click(first);
}

/** Pretend this browser has opened the app before, so "/" shows the home menu. */
function returningVisitor() {
  window.localStorage.setItem("ultimate-ttt:rules-seen", "true");
}

async function showsHome() {
  expect(
    await screen.findByRole("heading", { name: "Ultimate Tic-Tac-Toe", level: 1 }),
  ).toBeInTheDocument();
}

describe("opening the app (D-006, D-032)", () => {
  it("shows the rules the very first time, with a way on to the home menu", async () => {
    const { user } = renderApp("/");

    expect(await screen.findByRole("heading", { name: "How to play" })).toBeInTheDocument();

    await clickBack(user, "Back to home");
    await showsHome();
  });

  it("shows the home menu every time after that", async () => {
    renderApp("/");
    await screen.findByRole("heading", { name: "How to play" });

    // A second visit in the same browser.
    document.body.innerHTML = "";
    renderApp("/");

    await showsHome();
  });

  it("shows the rules each time if the browser cannot store anything", async () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new Error("blocked");
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("blocked");
    });

    renderApp("/");

    expect(await screen.findByRole("heading", { name: "How to play" })).toBeInTheDocument();
  });
});

describe("home menu (D-032)", () => {
  function menu() {
    return screen.getByRole("navigation", { name: "Start" });
  }

  it("offers a new game, saved games, and the rules", async () => {
    returningVisitor();
    renderApp("/");
    await showsHome();

    expect(within(menu()).getByRole("button", { name: "New game" })).toBeEnabled();
    expect(within(menu()).getByRole("link", { name: "Saved Games" })).toHaveAttribute(
      "href",
      "/games",
    );
    expect(within(menu()).getByRole("link", { name: "Rules" })).toHaveAttribute("href", "/rules");
  });

  it("starts a new game and opens its board", async () => {
    returningVisitor();
    const { user } = renderApp("/");
    await showsHome();

    await user.click(within(menu()).getByRole("button", { name: "New game" }));

    expect(
      await screen.findByRole("heading", { name: "Player X vs Player O", level: 1 }),
    ).toBeInTheDocument();
  });

  it("opens the saved games", async () => {
    returningVisitor();
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/");
    await showsHome();

    await user.click(within(menu()).getByRole("link", { name: "Saved Games" }));

    expect(await screen.findByRole("link", { name: "Ada vs Grace" })).toBeInTheDocument();
  });

  it("opens the rules, and the rules lead back to the home menu", async () => {
    returningVisitor();
    const { user } = renderApp("/");
    await showsHome();

    await user.click(within(menu()).getByRole("link", { name: "Rules" }));
    expect(await screen.findByRole("heading", { name: "How to play" })).toBeInTheDocument();

    await clickBack(user, "Back to home");
    await showsHome();
  });

  it("explains if a new game cannot be started", async () => {
    returningVisitor();
    server.use(http.post("/api/v1/games", () => errorResponse(500, "server_error", "Try later.")));
    const { user } = renderApp("/");
    await showsHome();

    await user.click(within(menu()).getByRole("button", { name: "New game" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Could not start a new game. Try later.",
    );
  });

  it("can be reached from any page through the title in the header", async () => {
    returningVisitor();
    const { user } = renderApp("/games");
    await screen.findByText(/No saved games yet/);

    await user.click(screen.getByRole("link", { name: "Ultimate Tic-Tac-Toe" }));

    await showsHome();
  });
});

describe("rules page return button (D-033)", () => {
  it("returns to the game the rules were opened from", async () => {
    returningVisitor();
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/games/1");
    await screen.findByRole("heading", { name: "Ada vs Grace" });

    await user.click(screen.getByRole("link", { name: "Rules" }));
    expect(await screen.findByRole("heading", { name: "How to play" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Rules" })).toHaveAttribute("aria-current", "page");

    await clickBack(user, "Back to game");

    expect(await screen.findByRole("heading", { name: "Ada vs Grace" })).toBeInTheDocument();
  });

  it("returns to Saved Games, keeping the search", async () => {
    returningVisitor();
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    seedGame({ player_x_name: "Linus", player_o_name: "Ken" });
    const { user } = renderApp("/games?q=ken");
    await screen.findByRole("link", { name: "Linus vs Ken" });

    await user.click(screen.getByRole("link", { name: "Rules" }));
    await clickBack(user, "Back to Saved Games");

    expect(await screen.findByRole("link", { name: "Linus vs Ken" })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Ada vs Grace" })).not.toBeInTheDocument();
    expect(screen.getByLabelText("Search player names")).toHaveValue("ken");
  });

  it("returns to the home menu when there is nowhere else to go back to", async () => {
    returningVisitor();
    renderApp("/rules"); // typed straight into the address bar

    expect(await screen.findAllByRole("link", { name: "Back to home" })).toHaveLength(2);
  });
});

describe("unknown addresses and crashes", () => {
  it("says the page was not found", async () => {
    renderApp("/no/such/page");

    expect(await screen.findByRole("heading", { name: "Page not found" })).toBeInTheDocument();
  });

  it("shows an error page instead of a blank screen if a page crashes", async () => {
    vi.spyOn(console, "error").mockImplementation(() => undefined); // React logs the crash
    function Broken(): never {
      throw new Error("Kaboom");
    }

    renderApp("/", [
      {
        path: "/",
        element: <Layout />,
        errorElement: <RouteErrorPage />,
        children: [{ index: true, element: <Broken /> }],
      },
    ]);

    expect(await screen.findByRole("heading", { name: "Something went wrong" })).toBeVisible();
    expect(screen.getByRole("alert")).toHaveTextContent("Kaboom");
  });
});
