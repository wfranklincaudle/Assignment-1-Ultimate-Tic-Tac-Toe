import { Link, NavLink, Outlet, useLocation } from "react-router";

import { PlayerColorsProvider } from "./PlayerColorsContext";

const navLinkClass = ({ isActive }: { isActive: boolean }) =>
  [
    "rounded-md px-3 py-1.5 font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900",
    isActive ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-200",
  ].join(" ");

export function Layout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <Link
            to="/"
            className="rounded-md text-lg font-bold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
          >
            Ultimate Tic-Tac-Toe
          </Link>
          <nav aria-label="Main">
            <ul className="flex gap-2">
              <li>
                <NavLink to="/games" end className={navLinkClass}>
                  Saved Games
                </NavLink>
              </li>
              <li>
                {/* Tells the Rules page where its return button should go (D-033). */}
                <NavLink
                  to="/rules"
                  state={{ from: `${location.pathname}${location.search}` }}
                  className={navLinkClass}
                >
                  Rules
                </NavLink>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-4xl px-4 py-6">
        <PlayerColorsProvider>
          <Outlet />
        </PlayerColorsProvider>
      </main>
    </div>
  );
}
