import type { GameSummary } from "../api/client";

type Tally = GameSummary["record"]["series"];

function plural(count: number, word: string): string {
  return `${count} ${word}${count === 1 ? "" : "s"}`;
}

/**
 * "Ada 2 wins · Grace 1 win · 1 draw". Wins are listed by this game's X player
 * first, then O; the server has already matched them to names (D-037).
 */
export function formatTally(tally: Tally, xName: string, oName: string): string {
  return [
    `${xName} ${plural(tally.player_x_wins, "win")}`,
    `${oName} ${plural(tally.player_o_wins, "win")}`,
    plural(tally.draws, "draw"),
  ].join(" · ");
}

/** Nothing worth showing until a game has finished or a rematch has been played. */
export function hasRecord(game: GameSummary): boolean {
  return game.record.head_to_head.games_played > 0 || game.record.games_in_series > 1;
}

/**
 * The two tallies asked for (D-037): this rematch series, and every game
 * between the same two names. Deleted games are not counted.
 */
export function RecordSummary({ game, className = "" }: { game: GameSummary; className?: string }) {
  if (!hasRecord(game)) return null;
  const { series, head_to_head } = game.record;

  return (
    <section aria-label="Record" className={className}>
      <dl className="space-y-1 text-sm">
        <div className="flex flex-wrap gap-x-2">
          <dt className="font-semibold">
            This series ({plural(game.record.games_in_series, "game")}):
          </dt>{" "}
          <dd>{formatTally(series, game.player_x_name, game.player_o_name)}</dd>
        </div>
        <div className="flex flex-wrap gap-x-2">
          <dt className="font-semibold">All games between them:</dt>{" "}
          <dd>{formatTally(head_to_head, game.player_x_name, game.player_o_name)}</dd>
        </div>
      </dl>
    </section>
  );
}
