import type { BoardStatus, GameDetail, Player } from "../api/client";
import { capitalize, positionName } from "../lib/positions";

interface UltimateBoardProps {
  game: GameDetail;
  onPlay: (boardIndex: number, cellIndex: number) => void;
  /** True while a move is being sent, so a second click cannot race it. */
  disabled: boolean;
}

const INDEXES = [0, 1, 2, 3, 4, 5, 6, 7, 8] as const;

/**
 * Whether the next move may go in this board. This mirrors the server's rules
 * only to switch off buttons that could never work; the server still decides.
 */
function isBoardPlayable(game: GameDetail, boardIndex: number): boolean {
  return (
    game.status === "in_progress" &&
    game.board_statuses[boardIndex] === "open" &&
    (game.required_board === null || game.required_board === boardIndex)
  );
}

function boardDescription(status: BoardStatus | undefined, playable: boolean): string {
  switch (status) {
    case "x_won":
      return "won by X";
    case "o_won":
      return "won by O";
    case "draw":
      return "drawn";
    default:
      return playable ? "play here" : "open";
  }
}

export function UltimateBoard({ game, onPlay, disabled }: UltimateBoardProps) {
  const lastMove = game.moves.at(-1);

  return (
    <div className="mx-auto grid w-full max-w-xl grid-cols-3 gap-2 rounded-lg bg-slate-800 p-2 sm:gap-3 sm:p-3">
      {INDEXES.map((boardIndex) => (
        <SmallBoard
          key={boardIndex}
          boardIndex={boardIndex}
          status={game.board_statuses[boardIndex]}
          cells={game.cells[boardIndex] ?? []}
          playable={isBoardPlayable(game, boardIndex)}
          lastCell={lastMove?.board_index === boardIndex ? lastMove.cell_index : null}
          disabled={disabled}
          onPlay={(cellIndex) => {
            onPlay(boardIndex, cellIndex);
          }}
        />
      ))}
    </div>
  );
}

interface SmallBoardProps {
  boardIndex: number;
  status: BoardStatus | undefined;
  cells: (Player | null)[];
  playable: boolean;
  lastCell: number | null;
  disabled: boolean;
  onPlay: (cellIndex: number) => void;
}

function SmallBoard({
  boardIndex,
  status,
  cells,
  playable,
  lastCell,
  disabled,
  onPlay,
}: SmallBoardProps) {
  const boardName = `${capitalize(positionName(boardIndex))} board`;
  const description = boardDescription(status, playable);
  const winner = status === "x_won" ? "X" : status === "o_won" ? "O" : null;

  return (
    <section
      aria-label={`${boardName}, ${description}`}
      className={[
        "relative rounded-md p-1 sm:p-1.5",
        playable ? "bg-highlight ring-4 ring-highlight" : "bg-slate-200",
      ].join(" ")}
    >
      <div className="grid grid-cols-3 gap-0.5 sm:gap-1">
        {INDEXES.map((cellIndex) => {
          const occupant = cells[cellIndex] ?? null;
          const isLast = lastCell === cellIndex;
          const canPlay = playable && occupant === null && !disabled;
          const label = [
            `${boardName}, ${positionName(cellIndex)}`,
            occupant ? occupant.toUpperCase() : "empty",
            ...(isLast ? ["last move"] : []),
          ].join(", ");

          return (
            <button
              key={cellIndex}
              type="button"
              aria-label={label}
              disabled={!canPlay}
              onClick={() => {
                onPlay(cellIndex);
              }}
              className={[
                "flex aspect-square items-center justify-center rounded-sm text-lg font-bold sm:text-2xl",
                "focus-visible:outline-3 focus-visible:outline-offset-1 focus-visible:outline-slate-900",
                occupant === "x" ? "text-player-x" : "text-player-o",
                canPlay ? "cursor-pointer bg-white hover:bg-slate-100" : "bg-slate-50",
                isLast ? "underline decoration-4 underline-offset-4" : "",
              ].join(" ")}
            >
              {occupant?.toUpperCase()}
            </button>
          );
        })}
      </div>

      {winner && (
        <div
          aria-hidden="true"
          className={[
            "absolute inset-0 flex items-center justify-center rounded-md text-7xl font-black opacity-90 sm:text-8xl",
            winner === "X" ? "bg-player-x-soft text-player-x" : "bg-player-o-soft text-player-o",
          ].join(" ")}
        >
          {winner}
        </div>
      )}
      {status === "draw" && (
        <div
          aria-hidden="true"
          className="absolute inset-0 flex items-center justify-center rounded-md bg-slate-300/85 text-lg font-bold text-slate-800"
        >
          Drawn
        </div>
      )}
    </section>
  );
}
