/**
 * Stepping through a game one move at a time (D-039).
 *
 * The position for each step comes from the server, which replays the saved
 * moves through the game rules. Nothing here works out who won what.
 */
import type { GameDetail } from "../api/client";
import { playerLabel } from "../lib/describe";
import { positionName } from "../lib/positions";

const stepClass =
  "rounded-md border border-slate-300 bg-white px-3 py-2 font-medium hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 disabled:cursor-not-allowed disabled:opacity-40";

interface ReviewControlsProps {
  move: number;
  total: number;
  onMove: (move: number) => void;
  onDone: () => void;
}

export function ReviewControls({ move, total, onMove, onDone }: ReviewControlsProps) {
  const atStart = move === 0;
  const atEnd = move === total;

  return (
    <nav
      aria-label="Review moves"
      className="flex flex-wrap items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-3"
    >
      <button
        type="button"
        aria-label="First move"
        disabled={atStart}
        onClick={() => {
          onMove(0);
        }}
        className={stepClass}
      >
        <span aria-hidden="true">⏮ </span>First
      </button>
      <button
        type="button"
        aria-label="Previous move"
        disabled={atStart}
        onClick={() => {
          onMove(move - 1);
        }}
        className={stepClass}
      >
        <span aria-hidden="true">◀ </span>Previous
      </button>
      <p className="min-w-32 text-center font-semibold">
        Move {move} of {total}
      </p>
      <button
        type="button"
        aria-label="Next move"
        disabled={atEnd}
        onClick={() => {
          onMove(move + 1);
        }}
        className={stepClass}
      >
        Next<span aria-hidden="true"> ▶</span>
      </button>
      <button
        type="button"
        aria-label="Last move"
        disabled={atEnd}
        onClick={() => {
          onMove(total);
        }}
        className={stepClass}
      >
        Last<span aria-hidden="true"> ⏭</span>
      </button>
      <button
        type="button"
        onClick={onDone}
        className="rounded-md bg-slate-900 px-3 py-2 font-medium text-white hover:bg-slate-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
      >
        Done reviewing
      </button>
    </nav>
  );
}

/** What happened on the move shown, in words (also read out by screen readers). */
export function describeReviewStep(position: GameDetail, total: number): string {
  const shown = position.moves.length;
  const last = position.moves.at(-1);
  if (!last) {
    return `Start of the game. ${playerLabel(position, "x")} moves first.`;
  }

  const board = positionName(last.board_index);
  const cell = positionName(last.cell_index);
  let text = `Move ${shown} of ${total}: ${playerLabel(position, last.player)} played the ${cell} square of the ${board} board`;

  // The move can close the board it was played in.
  const boardStatus = position.board_statuses[last.board_index];
  if (boardStatus === `${last.player}_won`) {
    text += `, winning that board`;
  } else if (boardStatus === "draw") {
    text += `, filling that board with no winner`;
  }
  text += ".";

  if (position.status === "x_won" || position.status === "o_won") {
    text += ` ${playerLabel(position, position.status === "x_won" ? "x" : "o")} wins the game.`;
  } else if (position.status === "draw") {
    text += " The game is a draw.";
  }
  return text;
}
