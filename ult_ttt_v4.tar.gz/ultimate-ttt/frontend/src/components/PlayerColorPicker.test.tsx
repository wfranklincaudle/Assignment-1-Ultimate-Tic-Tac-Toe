import { screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { seedGame } from "../test/fakeApi";
import { renderApp } from "../test/renderApp";

afterEach(() => {
  vi.restoreAllMocks();
});

/** Open a game and show its color options. */
async function openGame() {
  seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
  const result = renderApp("/games/1");
  await screen.findByRole("heading", { name: "Ada vs Grace" });
  await result.user.click(screen.getByRole("button", { name: "Change colors" }));
  return result;
}

function picker(name: string) {
  return screen.getByRole("group", { name });
}

describe("showing and hiding the color options (D-025)", () => {
  it("keeps the color options hidden until asked for", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/games/1");
    await screen.findByRole("heading", { name: "Ada vs Grace" });

    const toggle = screen.getByRole("button", { name: "Change colors" });
    expect(toggle).toHaveAttribute("aria-expanded", "false");
    expect(screen.queryByRole("group", { name: "Color for Ada (X)" })).not.toBeInTheDocument();

    await user.click(toggle);
    expect(screen.getByRole("button", { name: "Hide colors" })).toHaveAttribute(
      "aria-expanded",
      "true",
    );
    expect(screen.getByRole("group", { name: "Color for Ada (X)" })).toBeVisible();

    await user.click(screen.getByRole("button", { name: "Hide colors" }));
    expect(screen.queryByRole("group", { name: "Color for Ada (X)" })).not.toBeInTheDocument();
  });

  it("keeps a chosen color after the options are hidden", async () => {
    const { user } = await openGame();
    await user.click(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Teal" }));

    await user.click(screen.getByRole("button", { name: "Hide colors" }));
    await user.click(screen.getByRole("button", { name: "Change colors" }));

    expect(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Teal" })).toBeChecked();
  });
});

describe("choosing player colors (D-024)", () => {
  it("starts with blue for X and red for O", async () => {
    await openGame();

    expect(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Blue" })).toBeChecked();
    expect(within(picker("Color for Grace (O)")).getByRole("radio", { name: "Red" })).toBeChecked();
  });

  it("lets a player pick a new color from the palette", async () => {
    const { user } = await openGame();

    await user.click(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Green" }));

    const xPicker = picker("Color for Ada (X)");
    expect(within(xPicker).getByRole("radio", { name: "Green" })).toBeChecked();
    expect(within(xPicker).getByRole("radio", { name: "Blue" })).not.toBeChecked();
    // Blue is free again for O.
    expect(
      within(picker("Color for Grace (O)")).getByRole("radio", { name: "Blue" }),
    ).toBeEnabled();
  });

  it("does not let both players have the same color", async () => {
    await openGame();

    const taken = within(picker("Color for Grace (O)")).getByRole("radio", {
      name: "Blue, used by the other player",
    });
    expect(taken).toBeDisabled();
    expect(
      within(picker("Color for Ada (X)")).getByRole("radio", {
        name: "Red, used by the other player",
      }),
    ).toBeDisabled();
  });

  it("can be changed with the keyboard", async () => {
    const { user } = await openGame();

    within(picker("Color for Grace (O)")).getByRole("radio", { name: "Red" }).focus();
    await user.keyboard("{ArrowRight}");

    // The next swatch after Red is Green.
    expect(
      within(picker("Color for Grace (O)")).getByRole("radio", { name: "Green" }),
    ).toBeChecked();
  });

  it("remembers the choice in this browser for every game", async () => {
    const { user } = await openGame();
    await user.click(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Purple" }));

    // Open a different game later in the same browser.
    document.body.innerHTML = "";
    seedGame({ player_x_name: "Linus", player_o_name: "Ken" });
    const second = renderApp("/games/2");
    await screen.findByRole("heading", { name: "Linus vs Ken" });
    await second.user.click(screen.getByRole("button", { name: "Change colors" }));

    expect(
      within(picker("Color for Linus (X)")).getByRole("radio", { name: "Purple" }),
    ).toBeChecked();
  });

  it("uses the default colors if what was saved is not a valid choice", async () => {
    window.localStorage.setItem(
      "ultimate-ttt:player-colors",
      JSON.stringify({ x: "red", o: "red" }),
    );

    await openGame();

    expect(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Blue" })).toBeChecked();
  });

  it("still works for this visit if the browser cannot store anything", async () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new Error("blocked");
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("blocked");
    });
    const { user } = await openGame();

    await user.click(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Teal" }));

    expect(within(picker("Color for Ada (X)")).getByRole("radio", { name: "Teal" })).toBeChecked();
  });
});
