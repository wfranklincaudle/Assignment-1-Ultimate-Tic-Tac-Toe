import { screen, waitFor, within } from "@testing-library/react";
import { http } from "msw";
import { describe, expect, it } from "vitest";

import { applyMove, findGame, seedGame } from "../test/fakeApi";
import { errorResponse } from "../test/handlers";
import { renderApp } from "../test/renderApp";
import { server } from "../test/server";

/** A finished three-move game: X center/center, O center/top-right, X top-right/center. */
function seedPlayedGame() {
  const game = seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
  for (const [board, cell] of [
    [4, 4],
    [4, 2],
    [2, 4],
  ] as const) {
    applyMove(game, board, cell);
  }
  Object.assign(game, { status: "x_won", next_player: null });
  return game;
}

function controls() {
  return screen.getByRole("navigation", { name: "Review moves" });
}

/** Wait until the status line (read out by screen readers) says this. */
async function statusSays(text: string) {
  await waitFor(() => {
    expect(screen.getByRole("status")).toHaveTextContent(text);
  });
}

function cellName(name: string) {
  return screen.getByRole("button", { name: new RegExp(`^${name},`) });
}

describe("reviewing a game move by move (D-039)", () => {
  it("opens at the last move with the result, and cannot be played on", async () => {
    seedPlayedGame();
    renderApp("/games/1?move=3");

    await statusSays(
      "Move 3 of 3: Ada (X) played the center square of the top right board. Ada (X) wins the game.",
    );
    expect(controls()).toHaveTextContent("Move 3 of 3");
    expect(within(controls()).getByRole("button", { name: "Next move" })).toBeDisabled();
    expect(within(controls()).getByRole("button", { name: "Last move" })).toBeDisabled();
    expect(cellName("Top right board, center")).toHaveAccessibleName(
      "Top right board, center, X, last move",
    );
    expect(cellName("Bottom left board, center")).toBeDisabled();
  });

  it("steps back one move at a time", async () => {
    seedPlayedGame();
    const { user } = renderApp("/games/1?move=3");
    await statusSays("Move 3 of 3");

    await user.click(within(controls()).getByRole("button", { name: "Previous move" }));

    await statusSays("Move 2 of 3: Grace (O) played the top right square of the center board.");
    expect(controls()).toHaveTextContent("Move 2 of 3");
    expect(cellName("Top right board, center")).toHaveAccessibleName(
      "Top right board, center, empty",
    );
    expect(cellName("Center board, top right")).toHaveAccessibleName(
      "Center board, top right, O, last move",
    );
  });

  it("jumps to the start, then steps forward", async () => {
    seedPlayedGame();
    const { user } = renderApp("/games/1?move=3");
    await statusSays("Move 3 of 3");

    await user.click(within(controls()).getByRole("button", { name: "First move" }));

    await statusSays("Start of the game. Ada (X) moves first.");
    expect(cellName("Center board, center")).toHaveAccessibleName("Center board, center, empty");
    expect(within(controls()).getByRole("button", { name: "First move" })).toBeDisabled();
    expect(within(controls()).getByRole("button", { name: "Previous move" })).toBeDisabled();

    await user.click(within(controls()).getByRole("button", { name: "Next move" }));

    await statusSays("Move 1 of 3: Ada (X) played the center square of the center board.");
  });

  it("jumps back to the last move", async () => {
    seedPlayedGame();
    const { user } = renderApp("/games/1?move=0");
    await statusSays("Start of the game.");

    await user.click(within(controls()).getByRole("button", { name: "Last move" }));

    await statusSays("Move 3 of 3");
  });

  it("describes a move that wins or fills a board", async () => {
    const game = seedPlayedGame();
    // What the server would report after move 3 closed the top right board.
    Object.assign(game, {
      board_statuses: ["open", "open", "x_won", "open", "open", "open", "open", "open", "open"],
    });
    renderApp("/games/1?move=3");

    await statusSays("played the center square of the top right board, winning that board.");
  });

  it("shows the last move for a move number past the end", async () => {
    seedPlayedGame();
    renderApp("/games/1?move=99");

    await statusSays("Move 3 of 3");
  });

  it("explains if a move cannot be loaded, with a retry that works", async () => {
    seedPlayedGame();
    // The first request for a past position fails; everything else works.
    let failed = false;
    server.use(
      http.get("/api/v1/games/:id", ({ request }) => {
        if (failed || !new URL(request.url).searchParams.has("at_move")) return undefined;
        failed = true;
        return errorResponse(500, "server_error", "Timed out.");
      }),
    );
    const { user } = renderApp("/games/1?move=1");

    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Could not load this move. Timed out.");
    await user.click(within(alert).getByRole("button", { name: "Try again" }));

    await statusSays("Move 1 of 3");
  });

  it("works for an unfinished game too, and Done returns to playing", async () => {
    const game = seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    applyMove(game, 4, 4);
    applyMove(game, 4, 2);
    const { user } = renderApp("/games/1?move=1");
    await statusSays("Move 1 of 2");

    await user.click(within(controls()).getByRole("button", { name: "Done reviewing" }));

    expect(screen.getByRole("status")).toHaveTextContent(
      "Ada (X) to move. Play in the top right board.",
    );
    expect(cellName("Top right board, center")).toBeEnabled();
    expect(findGame(1)?.moves).toHaveLength(2); // reviewing changed nothing
  });
});
