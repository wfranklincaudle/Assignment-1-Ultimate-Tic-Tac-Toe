import type { Player } from "../api/client";
import { PALETTE } from "../lib/playerColors";
import { usePlayerColors } from "./PlayerColorsContext";

interface PlayerColorPickerProps {
  player: Player;
  playerName: string;
}

/**
 * A row of color swatches for one player. They are real radio buttons, so the
 * arrow keys move between them. Each has its color's name as its label, and
 * the chosen one shows a check mark, so nothing relies on seeing the color.
 */
export function PlayerColorPicker({ player, playerName }: PlayerColorPickerProps) {
  const { colors, setColor } = usePlayerColors();
  const other: Player = player === "x" ? "o" : "x";
  const letter = player.toUpperCase();

  return (
    <fieldset className="flex flex-col gap-1">
      <legend className="mb-1 text-sm font-medium text-slate-700">
        Color for {playerName} ({letter})
      </legend>
      <div className="flex flex-wrap gap-1.5">
        {PALETTE.map((color) => {
          const takenByOther = colors[other] === color.id;
          const checked = colors[player] === color.id;
          return (
            <label
              key={color.id}
              title={takenByOther ? `${color.name} (used by the other player)` : color.name}
              className={[
                "relative flex size-8 items-center justify-center rounded-full border-2 text-sm font-bold text-white",
                "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-slate-900",
                checked ? "border-slate-900" : "border-white shadow-[0_0_0_1px_#cbd5e1]",
                takenByOther ? "cursor-not-allowed opacity-30" : "cursor-pointer",
              ].join(" ")}
              style={{ backgroundColor: color.main }}
            >
              <input
                type="radio"
                name={`player-${player}-color`}
                value={color.id}
                checked={checked}
                disabled={takenByOther}
                onChange={() => {
                  setColor(player, color.id);
                }}
                aria-label={takenByOther ? `${color.name}, used by the other player` : color.name}
                className="sr-only"
              />
              {checked && <span aria-hidden="true">✓</span>}
              {takenByOther && (
                <span aria-hidden="true" className="absolute text-base">
                  ✕
                </span>
              )}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
