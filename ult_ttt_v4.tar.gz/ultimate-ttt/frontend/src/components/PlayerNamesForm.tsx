import { useId, useState } from "react";

import { validatePlayerName } from "../lib/playerNames";

export interface PlayerNames {
  player_x_name: string;
  player_o_name: string;
}

type Field = keyof PlayerNames;

interface PlayerNamesFormProps {
  /** The names as last saved on the server. */
  saved: PlayerNames;
  /** Called with only the names that changed. */
  onSave: (changes: Partial<PlayerNames>) => void;
  saving: boolean;
  /** A message from the server if the last save failed. */
  saveError: string | null;
}

type Errors = Partial<Record<Field, string>>;

/**
 * Player names save automatically, like moves (D-003, D-031): when a player
 * leaves a name box (Tab, clicking the board, clicking a link) or presses
 * Enter in it. There is no Save button to forget. Names can be changed at any point
 * in the game (D-008).
 */
export function PlayerNamesForm({ saved, onSave, saving, saveError }: PlayerNamesFormProps) {
  // What is typed in the boxes. It is not reset from `saved` after each save,
  // so a save finishing never overwrites what the player is typing.
  const [names, setNames] = useState(saved);
  const [errors, setErrors] = useState<Errors>({});

  function commit(fields: readonly Field[]) {
    // Errors for the other box are kept; this box's error is replaced.
    const found: Errors = Object.fromEntries(
      Object.entries(errors).filter(([field]) => !fields.includes(field as Field)),
    );
    const changes: Partial<PlayerNames> = {};
    for (const field of fields) {
      const message = validatePlayerName(names[field]);
      if (message) {
        found[field] = message;
        continue;
      }
      const trimmed = names[field].trim();
      if (trimmed !== saved[field]) changes[field] = trimmed;
    }
    setErrors(found);
    if (Object.keys(changes).length > 0) onSave(changes);
  }

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
      }}
      noValidate
      aria-label="Player names"
      className="flex flex-wrap items-start gap-3"
    >
      <NameField
        label="Player X"
        player="x"
        value={names.player_x_name}
        error={errors.player_x_name}
        onChange={(value) => {
          setNames({ ...names, player_x_name: value });
        }}
        onDone={() => {
          commit(["player_x_name"]);
        }}
      />
      <NameField
        label="Player O"
        player="o"
        value={names.player_o_name}
        error={errors.player_o_name}
        onChange={(value) => {
          setNames({ ...names, player_o_name: value });
        }}
        onDone={() => {
          commit(["player_o_name"]);
        }}
      />
      <p aria-live="polite" className="w-full text-sm text-slate-600">
        {saving ? "Saving names…" : "Names are saved automatically."}
      </p>
      {saveError && (
        <p role="alert" className="w-full text-sm text-red-800">
          {saveError}
        </p>
      )}
    </form>
  );
}

/**
 * Each name box is tinted in its player's color, the same color as that
 * player's letters on the board. Full class names are written out so Tailwind
 * can find them.
 */
const PLAYER_STYLES = {
  x: {
    label: "text-player-x",
    fill: "bg-player-x-soft focus-visible:outline-player-x",
    border: "border-player-x/50",
  },
  o: {
    label: "text-player-o",
    fill: "bg-player-o-soft focus-visible:outline-player-o",
    border: "border-player-o/50",
  },
} as const;

interface NameFieldProps {
  label: string;
  player: keyof typeof PLAYER_STYLES;
  value: string;
  error: string | undefined;
  onChange: (value: string) => void;
  /** The player has finished with this box (it lost focus). */
  onDone: () => void;
}

function NameField({ label, player, value, error, onChange, onDone }: NameFieldProps) {
  const inputId = useId();
  const errorId = useId();
  const styles = PLAYER_STYLES[player];

  return (
    <div className="flex min-w-40 flex-1 flex-col gap-1">
      <label htmlFor={inputId} className={`text-sm font-semibold ${styles.label}`}>
        {label}
      </label>
      <input
        id={inputId}
        type="text"
        value={value}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        onChange={(event) => {
          onChange(event.target.value);
        }}
        onBlur={onDone}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            onDone();
          }
        }}
        className={[
          "rounded-md border px-3 py-2 text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-1",
          styles.fill,
          // An invalid box keeps its tint but gets a red border next to the message.
          error ? "border-2 border-red-600" : styles.border,
        ].join(" ")}
      />
      {error && (
        <p id={errorId} className="text-sm text-red-800">
          {error}
        </p>
      )}
    </div>
  );
}
