/**
 * Shares the players' chosen colors with every part of the page.
 *
 * This is local UI state (a browser setting, not server data), so it lives in
 * useState and is handed down with React context rather than a state library.
 * The colors are applied by overriding the Tailwind theme variables
 * (--color-player-x and friends) on a wrapper element, so every existing
 * `text-player-x`, `bg-player-o-soft`, etc. class follows the choice.
 */
import { createContext, use, useState, type CSSProperties, type ReactNode } from "react";

import type { Player } from "../api/client";
import {
  colorById,
  loadColors,
  saveColors,
  type ColorId,
  type PlayerColors,
} from "../lib/playerColors";

interface PlayerColorsValue {
  colors: PlayerColors;
  /** Ignored if the other player already has this color (D-024). */
  setColor: (player: Player, color: ColorId) => void;
}

const PlayerColorsContext = createContext<PlayerColorsValue | null>(null);

export function PlayerColorsProvider({ children }: { children: ReactNode }) {
  const [colors, setColors] = useState(loadColors);

  function setColor(player: Player, color: ColorId) {
    const other: Player = player === "x" ? "o" : "x";
    if (colors[other] === color) return;
    const next = { ...colors, [player]: color };
    setColors(next);
    saveColors(next);
  }

  const x = colorById(colors.x);
  const o = colorById(colors.o);
  const style = {
    "--color-player-x": x.main,
    "--color-player-x-soft": x.soft,
    "--color-player-o": o.main,
    "--color-player-o-soft": o.soft,
  } as CSSProperties;

  return (
    <PlayerColorsContext value={{ colors, setColor }}>
      <div style={style} className="contents">
        {children}
      </div>
    </PlayerColorsContext>
  );
}

export function usePlayerColors(): PlayerColorsValue {
  const value = use(PlayerColorsContext);
  if (!value) {
    throw new Error("usePlayerColors must be used inside PlayerColorsProvider");
  }
  return value;
}
