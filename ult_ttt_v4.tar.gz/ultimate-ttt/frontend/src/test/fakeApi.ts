/**
 * An in-memory stand-in for the backend, used by the MSW handlers.
 *
 * It follows the API's shapes and status codes but NOT the full game rules:
 * a move is refused only if the game is over or the cell is taken. Tests that
 * need a particular board position seed it directly with `seedGame`. The real
 * rules are tested in the backend.
 */
import type { BoardStatus, GameDetail, GameSummary, Player } from "../api/client";

const BASE_TIME = Date.parse("2026-09-01T12:00:00Z");

let games: GameDetail[] = [];
let nextId = 1;

export function resetFakeApi() {
  games = [];
  nextId = 1;
}

function emptyCells(): (Player | null)[][] {
  return Array.from({ length: 9 }, () => Array<Player | null>(9).fill(null));
}

const NO_RESULTS = { player_x_wins: 0, player_o_wins: 0, draws: 0, games_played: 0 };

export function emptyRecord(): GameDetail["record"] {
  return { series: { ...NO_RESULTS }, head_to_head: { ...NO_RESULTS }, games_in_series: 1 };
}

/** Tallies are worked out by the real server; tests seed them where they matter. */
export function seedGame(overrides: Partial<GameDetail> = {}): GameDetail {
  const id = nextId++;
  const created = new Date(BASE_TIME + id * 60_000).toISOString();
  const game: GameDetail = {
    id,
    player_x_name: "Player X",
    player_o_name: "Player O",
    status: "in_progress",
    next_player: "x",
    move_count: 0,
    created_at: created,
    last_played_at: created,
    required_board: null,
    board_statuses: Array<BoardStatus>(9).fill("open"),
    cells: emptyCells(),
    moves: [],
    record: emptyRecord(),
    ...overrides,
  };
  games.push(game);
  return game;
}

export function findGame(id: number): GameDetail | undefined {
  return games.find((game) => game.id === id);
}

export function deleteGame(id: number): boolean {
  const before = games.length;
  games = games.filter((game) => game.id !== id);
  return games.length < before;
}

export function listGames(params: URLSearchParams) {
  const q = params.get("q")?.toLowerCase() ?? "";
  const sort = params.get("sort") ?? "-last_played_at";
  const page = Number(params.get("page") ?? "1");
  const pageSize = Number(params.get("page_size") ?? "25");

  const field = sort.replace("-", "") as "created_at" | "last_played_at";
  const direction = sort.startsWith("-") ? -1 : 1;
  const matches = games
    .filter(
      (g) =>
        !q ||
        g.player_x_name.toLowerCase().includes(q) ||
        g.player_o_name.toLowerCase().includes(q),
    )
    .sort((a, b) => direction * (a[field].localeCompare(b[field]) || a.id - b.id));

  const items: GameSummary[] = matches.slice((page - 1) * pageSize, page * pageSize).map((g) => ({
    id: g.id,
    player_x_name: g.player_x_name,
    player_o_name: g.player_o_name,
    status: g.status,
    next_player: g.next_player,
    move_count: g.move_count,
    created_at: g.created_at,
    last_played_at: g.last_played_at,
    record: g.record,
  }));
  return { items, total: matches.length, page, page_size: pageSize };
}

type MoveResult = { game: GameDetail } | { code: string; detail: string };

export function applyMove(game: GameDetail, board: number, cell: number): MoveResult {
  if (game.status !== "in_progress" || !game.next_player) {
    return { code: "game_over", detail: "This game is already over." };
  }
  const row = game.cells[board];
  if (!row || row[cell] !== null) {
    return { code: "cell_occupied", detail: `Cell ${cell} of board ${board} is already taken.` };
  }
  const player = game.next_player;
  row[cell] = player;
  const playedAt = new Date(Date.parse(game.last_played_at) + 1000).toISOString();
  game.moves.push({
    sequence: game.move_count,
    player,
    board_index: board,
    cell_index: cell,
    created_at: playedAt,
  });
  game.move_count += 1;
  game.last_played_at = playedAt;
  game.next_player = player === "x" ? "o" : "x";
  game.required_board = game.board_statuses[cell] === "open" ? cell : null;
  return { game };
}

type RematchResult = { game: GameDetail } | { status: number; code: string; detail: string };

/** A rematch: letters swapped, same series, tallies seen from the swapped side. */
export function startRematch(id: number): RematchResult {
  const game = findGame(id);
  if (!game) return { status: 404, code: "game_not_found", detail: `Game ${id} does not exist.` };
  if (game.status === "in_progress") {
    return {
      status: 409,
      code: "game_not_over",
      detail: "A rematch can only start once this game has ended.",
    };
  }
  const flip = (t: typeof NO_RESULTS) => ({
    ...t,
    player_x_wins: t.player_o_wins,
    player_o_wins: t.player_x_wins,
  });
  return {
    game: seedGame({
      player_x_name: game.player_o_name,
      player_o_name: game.player_x_name,
      record: {
        series: flip(game.record.series),
        head_to_head: flip(game.record.head_to_head),
        games_in_series: game.record.games_in_series + 1,
      },
    }),
  };
}

/**
 * The game after its first `n` moves. Only places the letters and works out
 * whose turn it is; it does not detect won boards. Tests that need won boards
 * seed them, and the real replay is tested in the backend.
 */
export function gameAtMove(game: GameDetail, n: number): GameDetail | null {
  if (n > game.moves.length) return null;
  if (n === game.moves.length) return game;
  const moves = game.moves.slice(0, n);
  const cells = emptyCells();
  for (const m of moves) {
    const row = cells[m.board_index];
    if (row) row[m.cell_index] = m.player;
  }
  return {
    ...game,
    cells,
    moves,
    move_count: n,
    status: "in_progress",
    next_player: n % 2 === 0 ? "x" : "o",
    required_board: moves.at(-1)?.cell_index ?? null,
    board_statuses: Array<BoardStatus>(9).fill("open"),
  };
}
