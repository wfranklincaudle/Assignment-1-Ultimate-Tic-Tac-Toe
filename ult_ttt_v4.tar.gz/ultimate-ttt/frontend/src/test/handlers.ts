/** MSW handlers for every endpoint, backed by the in-memory fake in fakeApi.ts. */
import { http, HttpResponse } from "msw";

import type { ErrorResponse, GameDetail } from "../api/client";
import {
  applyMove,
  deleteGame,
  findGame,
  gameAtMove,
  listGames,
  seedGame,
  startRematch,
} from "./fakeApi";

const GAMES = "/api/v1/games";

export function errorResponse(status: number, code: string, detail: string) {
  return HttpResponse.json<ErrorResponse>({ code, detail }, { status });
}

function notFound(id: number) {
  return errorResponse(404, "game_not_found", `Game ${id} does not exist.`);
}

export const handlers = [
  http.get(GAMES, ({ request }) => HttpResponse.json(listGames(new URL(request.url).searchParams))),

  http.post(GAMES, async ({ request }) => {
    const body = (await request.json()) as Partial<GameDetail>;
    const game = seedGame({
      player_x_name: body.player_x_name ?? "Player X",
      player_o_name: body.player_o_name ?? "Player O",
    });
    return HttpResponse.json(game, { status: 201, headers: { Location: `${GAMES}/${game.id}` } });
  }),

  http.get(`${GAMES}/:id`, ({ params, request }) => {
    const game = findGame(Number(params.id));
    if (!game) return notFound(Number(params.id));
    const atMove = new URL(request.url).searchParams.get("at_move");
    if (atMove === null) return HttpResponse.json(game);
    const position = gameAtMove(game, Number(atMove));
    return position
      ? HttpResponse.json(position)
      : errorResponse(404, "move_not_found", `This game has ${game.moves.length} moves.`);
  }),

  http.patch(`${GAMES}/:id`, async ({ params, request }) => {
    const game = findGame(Number(params.id));
    if (!game) return notFound(Number(params.id));
    const body = (await request.json()) as Partial<GameDetail>;
    Object.assign(game, body);
    return HttpResponse.json(game);
  }),

  http.post(`${GAMES}/:id/archive`, ({ params }) =>
    deleteGame(Number(params.id))
      ? new HttpResponse(null, { status: 204 })
      : notFound(Number(params.id)),
  ),

  http.post(`${GAMES}/:id/rematch`, ({ params }) => {
    const result = startRematch(Number(params.id));
    if ("code" in result) return errorResponse(result.status, result.code, result.detail);
    return HttpResponse.json(result.game, {
      status: 201,
      headers: { Location: `${GAMES}/${result.game.id}` },
    });
  }),

  http.post(`${GAMES}/:id/moves`, async ({ params, request }) => {
    const game = findGame(Number(params.id));
    if (!game) return notFound(Number(params.id));
    const { board_index, cell_index } = (await request.json()) as {
      board_index: number;
      cell_index: number;
    };
    const result = applyMove(game, board_index, cell_index);
    if ("code" in result) {
      return errorResponse(409, result.code, result.detail);
    }
    return HttpResponse.json(result.game, {
      status: 201,
      headers: { Location: `${GAMES}/${game.id}` },
    });
  }),
];
