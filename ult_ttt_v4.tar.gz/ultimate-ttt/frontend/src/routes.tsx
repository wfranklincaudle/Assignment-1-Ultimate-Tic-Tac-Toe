import { redirect, type RouteObject } from "react-router";

import { Layout } from "./components/Layout";
import { hasSeenRules, markRulesSeen } from "./lib/rulesSeen";
import { GamePage } from "./pages/GamePage";
import { GamesPage } from "./pages/GamesPage";
import { HomePage } from "./pages/HomePage";
import { NotFoundPage, RouteErrorPage } from "./pages/NotFoundPage";
import { RulesPage } from "./pages/RulesPage";

/**
 * The very first time the app is opened in a browser, it shows the rules
 * (D-006). Every other time, the opening page is the home menu (D-032).
 */
export function firstOpenLoader() {
  if (hasSeenRules()) {
    return null;
  }
  markRulesSeen();
  return redirect("/rules");
}

export const routes: RouteObject[] = [
  {
    path: "/",
    element: <Layout />,
    errorElement: <RouteErrorPage />,
    children: [
      { index: true, loader: firstOpenLoader, element: <HomePage /> },
      { path: "rules", element: <RulesPage /> },
      { path: "games", element: <GamesPage /> },
      { path: "games/:gameId", element: <GamePage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
];
