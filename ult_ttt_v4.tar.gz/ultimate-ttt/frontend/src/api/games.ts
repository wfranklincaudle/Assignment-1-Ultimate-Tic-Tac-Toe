/**
 * TanStack Query hooks for games. Components get server state only through
 * these hooks; nothing fetches in a useEffect.
 */
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { api, unwrap, type GameDetail, type GameSort } from "./client";

export interface GameListParams {
  q: string;
  sort: GameSort;
  page: number;
  pageSize: number;
}

export const gameKeys = {
  all: ["games"] as const,
  lists: () => [...gameKeys.all, "list"] as const,
  list: (params: GameListParams) => [...gameKeys.lists(), params] as const,
  detail: (id: number) => [...gameKeys.all, "detail", id] as const,
};

export function useGameList(params: GameListParams) {
  return useQuery({
    queryKey: gameKeys.list(params),
    queryFn: async () =>
      unwrap(
        await api.GET("/api/v1/games", {
          params: {
            query: {
              q: params.q || undefined,
              sort: params.sort,
              page: params.page,
              page_size: params.pageSize,
            },
          },
        }),
      ),
    // Keep showing the current page while the next one loads.
    placeholderData: keepPreviousData,
  });
}

export function useGame(id: number) {
  return useQuery({
    queryKey: gameKeys.detail(id),
    queryFn: async () =>
      unwrap(await api.GET("/api/v1/games/{game_id}", { params: { path: { game_id: id } } })),
  });
}

/**
 * The game as it stood after `move` moves (D-039), for reviewing it move by
 * move. Pass null to skip fetching. While the next position loads, the one on
 * screen stays put.
 */
export function useGamePosition(id: number, move: number | null) {
  return useQuery({
    queryKey: [...gameKeys.detail(id), "at", move] as const,
    queryFn: async () =>
      unwrap(
        await api.GET("/api/v1/games/{game_id}", {
          params: { path: { game_id: id }, query: { at_move: move ?? 0 } },
        }),
      ),
    enabled: move !== null,
    placeholderData: keepPreviousData,
  });
}

type PlayerNames = Pick<GameDetail, "player_x_name" | "player_o_name">;

/**
 * After a write, update the cached game and mark every list as out of date.
 *
 * Every reply carries the whole game, but a name save and a move can be in
 * flight at the same time (typing a name, then clicking the board). Their
 * replies can arrive in either order, and each is a snapshot from when it was
 * made. So each write only copies across the part it changed (D-034):
 * a move updates the board, a rename updates only the names it sent.
 */
function useStoreGame() {
  const queryClient = useQueryClient();
  return (game: GameDetail, pick: (cached: GameDetail) => GameDetail = () => game) => {
    queryClient.setQueryData<GameDetail>(gameKeys.detail(game.id), (cached) =>
      cached ? pick(cached) : game,
    );
    void queryClient.invalidateQueries({ queryKey: gameKeys.lists() });
  };
}

export function useCreateGame() {
  const storeGame = useStoreGame();
  return useMutation({
    // Names are optional; the server fills in "Player X" and "Player O".
    mutationFn: async (names?: Partial<PlayerNames>) =>
      unwrap(await api.POST("/api/v1/games", { body: names ?? {} })),
    onSuccess: (game) => {
      storeGame(game);
    },
  });
}

/** Start the next game in this game's series, letters swapped (D-035, D-037). */
export function useRematch(gameId: number) {
  const storeGame = useStoreGame();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () =>
      unwrap(
        await api.POST("/api/v1/games/{game_id}/rematch", {
          params: { path: { game_id: gameId } },
        }),
      ),
    onSuccess: (game) => {
      storeGame(game);
      // Every game in the series now shows one more game in it.
      void queryClient.invalidateQueries({ queryKey: [...gameKeys.all, "detail"] });
    },
  });
}

export function useMakeMove(gameId: number) {
  const storeGame = useStoreGame();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (move: { board_index: number; cell_index: number }) =>
      unwrap(
        await api.POST("/api/v1/games/{game_id}/moves", {
          params: { path: { game_id: gameId } },
          body: move,
        }),
      ),
    // Take the new board, but keep the names already on screen.
    onSuccess: (game) => {
      storeGame(game, (cached) => ({
        ...game,
        player_x_name: cached.player_x_name,
        player_o_name: cached.player_o_name,
      }));
      // A finishing move changes the tallies shown on the other games (D-037).
      if (game.status !== "in_progress") {
        void queryClient.invalidateQueries({
          queryKey: [...gameKeys.all, "detail"],
          predicate: (query) => query.queryKey[2] !== game.id,
        });
      }
    },
    // A refused move means the board on screen may be out of date (for example
    // after a double-click), so fetch the real one.
    onError: () => queryClient.invalidateQueries({ queryKey: gameKeys.detail(gameId) }),
  });
}

export function useRenamePlayers(gameId: number) {
  const storeGame = useStoreGame();
  return useMutation({
    // Only the names being changed are sent; the other one is left as it is.
    mutationFn: async (names: Partial<PlayerNames>) =>
      unwrap(
        await api.PATCH("/api/v1/games/{game_id}", {
          params: { path: { game_id: gameId } },
          body: names,
        }),
      ),
    // Take only the names this save sent; keep the board already on screen.
    onSuccess: (game, sent) => {
      storeGame(game, (cached) => ({
        ...cached,
        ...(sent.player_x_name !== undefined && { player_x_name: game.player_x_name }),
        ...(sent.player_o_name !== undefined && { player_o_name: game.player_o_name }),
      }));
    },
  });
}

export function useArchiveGame() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (gameId: number) => {
      unwrap(
        await api.POST("/api/v1/games/{game_id}/archive", {
          params: { path: { game_id: gameId } },
        }),
      );
    },
    onSuccess: (_data, gameId) => {
      queryClient.removeQueries({ queryKey: gameKeys.detail(gameId) });
      return queryClient.invalidateQueries({ queryKey: gameKeys.lists() });
    },
  });
}
