/**
 * The typed API client. Every request and response type comes from
 * `schema.d.ts`, which is generated from the backend (run `pnpm gen:api`).
 */
import createClient from "openapi-fetch";

import type { components, paths } from "./schema";

export type GameDetail = components["schemas"]["GameDetail"];
export type GameSummary = components["schemas"]["GameSummary"];
export type GamePage = components["schemas"]["Page_GameSummary_"];
export type GameSort = components["schemas"]["GameSort"];
export type Player = components["schemas"]["Player"];
export type BoardStatus = components["schemas"]["BoardStatus"];
export type GameStatus = components["schemas"]["GameStatus"];
export type ErrorResponse = components["schemas"]["ErrorResponse"];

export const api = createClient<paths>({
  baseUrl: window.location.origin,
  // Look up fetch on every call rather than once at startup, so test tools that
  // replace fetch (MSW) are picked up even if they start after this module loads.
  fetch: (request) => globalThis.fetch(request),
});

/** An error response from the API, carrying the standard `code` and `detail`. */
export class ApiError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, body: unknown) {
    const { code, detail } = isErrorResponse(body)
      ? body
      : { code: "unexpected_error", detail: "Something went wrong. Please try again." };
    super(detail);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

function isErrorResponse(body: unknown): body is ErrorResponse {
  return (
    typeof body === "object" &&
    body !== null &&
    typeof (body as Record<string, unknown>).code === "string" &&
    typeof (body as Record<string, unknown>).detail === "string"
  );
}

/** Return the data from an openapi-fetch result, or throw an ApiError. */
export function unwrap<T>(result: { data?: T; error?: unknown; response: Response }): T {
  if (!result.response.ok) {
    throw new ApiError(result.response.status, result.error);
  }
  return result.data as T;
}
