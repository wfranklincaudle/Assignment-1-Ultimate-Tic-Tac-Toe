/**
 * Where the Rules page's return button goes, and what it says (D-033).
 *
 * Links to the rules pass the page they came from as router state
 * (`state={{ from: "/games/12" }}`). Without it (the first-open redirect, a
 * bookmark, a typed address) the button goes to the opening page.
 */
export interface BackLink {
  to: string;
  label: string;
}

export function backLinkFrom(state: unknown): BackLink {
  const from = typeof state === "object" && state !== null && "from" in state ? state.from : null;

  // Only paths inside this app, never a full URL to somewhere else.
  if (typeof from !== "string" || !from.startsWith("/") || from.startsWith("//")) {
    return { to: "/", label: "Back to home" };
  }
  if (/^\/games\/[^/?#]+/.test(from)) {
    return { to: from, label: "Back to game" };
  }
  if (from.startsWith("/games")) {
    return { to: from, label: "Back to Saved Games" };
  }
  return { to: "/", label: "Back to home" };
}
