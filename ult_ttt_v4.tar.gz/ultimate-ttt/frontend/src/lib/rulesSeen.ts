/**
 * Remembers whether this browser has opened the app before, so the rules page
 * only opens automatically the first time (DECISIONS.md D-006, D-017).
 *
 * Storage can be unavailable (private browsing, blocked site data). Then the
 * app cannot remember, and shows the rules each time rather than never.
 */
const KEY = "ultimate-ttt:rules-seen";

export function hasSeenRules(): boolean {
  try {
    return window.localStorage.getItem(KEY) === "true";
  } catch {
    return false;
  }
}

export function markRulesSeen(): void {
  try {
    window.localStorage.setItem(KEY, "true");
  } catch {
    // Nothing to do: see the note above.
  }
}
