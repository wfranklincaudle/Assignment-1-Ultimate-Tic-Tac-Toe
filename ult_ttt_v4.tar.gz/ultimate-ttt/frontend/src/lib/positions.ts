/**
 * Boards and cells are numbered 0-8 in reading order, the same as the API:
 *
 *   0 | 1 | 2
 *   3 | 4 | 5
 *   6 | 7 | 8
 *
 * These names are what screen readers announce, so a player hears
 * "top right board, center" rather than "board 2, cell 4".
 */
export const POSITION_NAMES = [
  "top left",
  "top middle",
  "top right",
  "middle left",
  "center",
  "middle right",
  "bottom left",
  "bottom middle",
  "bottom right",
] as const;

export function positionName(index: number): string {
  const name = POSITION_NAMES[index];
  if (name === undefined) {
    throw new RangeError(`Position must be 0-8, got ${index}`);
  }
  return name;
}

export function capitalize(text: string): string {
  return text.charAt(0).toUpperCase() + text.slice(1);
}
