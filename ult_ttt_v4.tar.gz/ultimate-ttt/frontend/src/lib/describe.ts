import type { GameStatus, Player } from "../api/client";

interface NamedGame {
  player_x_name: string;
  player_o_name: string;
  status: GameStatus;
  next_player: Player | null;
}

export function playerLabel(game: NamedGame, player: Player): string {
  const name = player === "x" ? game.player_x_name : game.player_o_name;
  return `${name} (${player.toUpperCase()})`;
}

/** A one-line summary of where a game stands, used in the list and on the board. */
export function describeStatus(game: NamedGame): string {
  switch (game.status) {
    case "x_won":
      return `${playerLabel(game, "x")} won`;
    case "o_won":
      return `${playerLabel(game, "o")} won`;
    case "draw":
      return "Draw";
    case "in_progress":
      return game.next_player ? `${playerLabel(game, game.next_player)} to move` : "In progress";
  }
}

const dateFormat = new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" });

export function formatTimestamp(iso: string): string {
  return dateFormat.format(new Date(iso));
}
