/** Mirrors the backend rule in DECISIONS.md D-015. */
export const PLAYER_NAME_MAX_LENGTH = 25;

/** Returns an error message for an invalid name, or null if it is fine. */
export function validatePlayerName(name: string): string | null {
  const trimmed = name.trim();
  if (trimmed.length === 0) {
    return "Enter a name.";
  }
  if (trimmed.length > PLAYER_NAME_MAX_LENGTH) {
    return `Use ${PLAYER_NAME_MAX_LENGTH} characters or fewer.`;
  }
  return null;
}
