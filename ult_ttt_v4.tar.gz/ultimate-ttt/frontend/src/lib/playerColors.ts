/**
 * The colors players can choose from (DECISIONS.md D-024).
 *
 * Every `main` color has at least 4.5:1 contrast (WCAG AA for normal text)
 * both on white and on its own `soft` tint, so X and O stay readable
 * whichever colors are picked.
 */
import type { Player } from "../api/client";

export const PALETTE = [
  { id: "blue", name: "Blue", main: "#1d4ed8", soft: "#dbeafe" },
  { id: "red", name: "Red", main: "#b91c1c", soft: "#fee2e2" },
  { id: "green", name: "Green", main: "#15803d", soft: "#dcfce7" },
  { id: "purple", name: "Purple", main: "#7e22ce", soft: "#f3e8ff" },
  { id: "orange", name: "Orange", main: "#c2410c", soft: "#ffedd5" },
  { id: "teal", name: "Teal", main: "#0f766e", soft: "#ccfbf1" },
  { id: "pink", name: "Pink", main: "#be185d", soft: "#fce7f3" },
  { id: "gray", name: "Gray", main: "#334155", soft: "#e2e8f0" },
] as const;

export type ColorId = (typeof PALETTE)[number]["id"];
export type PlayerColors = Record<Player, ColorId>;

export const DEFAULT_COLORS: PlayerColors = { x: "blue", o: "red" };

export function colorById(id: ColorId) {
  // Every ColorId is in PALETTE, so this always finds one.
  return PALETTE.find((color) => color.id === id) ?? PALETTE[0];
}

function isColorId(value: unknown): value is ColorId {
  return PALETTE.some((color) => color.id === value);
}

/** Colors are a per-browser setting (D-024). Unusable storage means defaults. */
const KEY = "ultimate-ttt:player-colors";

export function loadColors(): PlayerColors {
  try {
    const stored: unknown = JSON.parse(window.localStorage.getItem(KEY) ?? "null");
    if (typeof stored === "object" && stored !== null) {
      const { x, o } = stored as Record<string, unknown>;
      // Ignore anything unrecognised or against the rules (both the same color).
      if (isColorId(x) && isColorId(o) && x !== o) {
        return { x, o };
      }
    }
  } catch {
    // Fall through to the defaults.
  }
  return DEFAULT_COLORS;
}

export function saveColors(colors: PlayerColors): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(colors));
  } catch {
    // The choice still applies until the page is closed; it just isn't remembered.
  }
}
