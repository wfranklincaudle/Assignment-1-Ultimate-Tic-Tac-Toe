import { Link, useLocation } from "react-router";

import { backLinkFrom } from "../lib/backLink";

/** The rules from DECISIONS.md D-001, in players' words. */
const backClass =
  "inline-block rounded-md px-5 py-2.5 font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900";

export function RulesPage() {
  // Returns to wherever the rules were opened from (D-033).
  const back = backLinkFrom(useLocation().state);

  return (
    <article className="mx-auto max-w-2xl space-y-6">
      <Link
        to={back.to}
        className={`${backClass} border border-slate-300 bg-white hover:bg-slate-100`}
      >
        <span aria-hidden="true">← </span>
        {back.label}
      </Link>

      <h1 className="text-3xl font-bold">How to play</h1>

      <p className="text-lg text-slate-700">
        Ultimate Tic-Tac-Toe is nine games of tic-tac-toe inside one big one. Two players share this
        screen and take turns.
      </p>

      <ol className="list-decimal space-y-3 pl-6 marker:font-bold">
        <li>
          <strong>X goes first</strong> and may play in any square of any small board.
        </li>
        <li>
          <strong>Where you play decides where your opponent plays.</strong> If you play in the
          top-right square of a small board, your opponent must play next in the top-right small
          board. The board they must use is highlighted and labelled “play here”.
        </li>
        <li>
          <strong>Win a small board</strong> by getting three in a row inside it. That board is then
          yours, and nobody can play in it again.
        </li>
        <li>
          <strong>A small board that fills up with no winner</strong> is a draw. It belongs to
          nobody.
        </li>
        <li>
          <strong>If you are sent to a board that is won or full</strong>, you may play in any open
          board instead.
        </li>
        <li>
          <strong>Win the game</strong> by winning three small boards in a row: across, down, or
          diagonally.
        </li>
        <li>
          <strong>If no moves are left</strong> and nobody has three boards in a row, the game is a
          draw.
        </li>
      </ol>

      <p className="text-slate-700">
        Every move is saved as you play, so you can leave a game and come back to it from{" "}
        <strong>Saved Games</strong>. You can change the players’ names at any time.
      </p>

      <Link to={back.to} className={`${backClass} bg-slate-900 text-white hover:bg-slate-700`}>
        {back.label}
      </Link>
    </article>
  );
}
