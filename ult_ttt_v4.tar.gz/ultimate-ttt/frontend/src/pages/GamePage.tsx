import { useId, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router";

import { ApiError, type GameDetail } from "../api/client";
import { useGame, useGamePosition, useMakeMove, useRematch, useRenamePlayers } from "../api/games";
import { describeReviewStep, ReviewControls } from "../components/MoveReview";
import { PlayerColorPicker } from "../components/PlayerColorPicker";
import { PlayerNamesForm } from "../components/PlayerNamesForm";
import { RecordSummary } from "../components/RecordSummary";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { UltimateBoard } from "../components/UltimateBoard";
import { playerLabel } from "../lib/describe";
import { positionName } from "../lib/positions";

export function GamePage() {
  const { gameId } = useParams();
  const id = Number(gameId);

  if (!Number.isInteger(id) || id < 1) {
    return <GameNotFound />;
  }
  // key: a different game gets fresh state (pending move, form contents).
  return <GameScreen key={id} id={id} />;
}

function GameNotFound() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Game not found</h1>
      <p>This game does not exist or has been deleted.</p>
      <Link to="/games" className="font-medium underline underline-offset-4">
        Back to Saved Games
      </Link>
    </div>
  );
}

/** `?move=5` in the address means "reviewing, after move 5" (D-039). */
function readMove(value: string | null): number | null {
  if (value === null) return null;
  const move = Number(value);
  return Number.isInteger(move) && move >= 0 ? move : null;
}

function GameScreen({ id }: { id: number }) {
  const game = useGame(id);
  const makeMove = useMakeMove(id);
  const rename = useRenamePlayers(id);

  // Reviewing is part of the address, so reload and Back keep your place.
  const [searchParams, setSearchParams] = useSearchParams();
  const total = game.data?.move_count;
  const requested = readMove(searchParams.get("move"));
  // A move past the end (an old link, a typo) shows the last move instead.
  const reviewMove = requested === null || total === undefined ? null : Math.min(requested, total);
  // The final position is the game itself; earlier ones come from the server.
  const position = useGamePosition(
    id,
    reviewMove !== null && reviewMove < (total ?? 0) ? reviewMove : null,
  );

  function showMove(move: number | null) {
    setSearchParams(move === null ? {} : { move: String(move) }, { replace: true });
  }

  if (game.isPending) {
    return <LoadingMessage label="Loading game…" />;
  }
  if (game.isError) {
    if (game.error instanceof ApiError && game.error.status === 404) {
      return <GameNotFound />;
    }
    return (
      <ErrorMessage
        message={`Could not load this game. ${game.error.message}`}
        onRetry={() => void game.refetch()}
      />
    );
  }

  const data = game.data;
  const reviewing = reviewMove !== null;
  const shown = !reviewing || reviewMove === data.move_count ? data : position.data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold">
          {data.player_x_name} vs {data.player_o_name}
        </h1>
        <Link to="/games" className="font-medium underline underline-offset-4">
          Back to Saved Games
        </Link>
      </div>

      <PlayerNamesForm
        saved={{ player_x_name: data.player_x_name, player_o_name: data.player_o_name }}
        onSave={(changes) => {
          rename.mutate(changes);
        }}
        saving={rename.isPending}
        saveError={rename.isError ? `Could not save the names. ${rename.error.message}` : null}
      />

      <ColorOptions playerXName={data.player_x_name} playerOName={data.player_o_name} />

      {reviewing ? (
        <>
          <ReviewControls
            move={reviewMove}
            total={data.move_count}
            onMove={showMove}
            onDone={() => {
              showMove(null);
            }}
          />
          {position.isError && reviewMove < data.move_count ? (
            <ErrorMessage
              message={`Could not load this move. ${position.error.message}`}
              onRetry={() => void position.refetch()}
            />
          ) : shown ? (
            <StatusLine>{describeReviewStep(shown, data.move_count)}</StatusLine>
          ) : (
            <LoadingMessage label="Loading move…" />
          )}
        </>
      ) : (
        <StatusBanner game={data} />
      )}

      {/* Wins and draws so far (D-037), shown just above the board. */}
      <RecordSummary
        game={data}
        className="rounded-md border border-slate-200 bg-white px-4 py-3"
      />

      {makeMove.isError && <ErrorMessage message={makeMove.error.message} />}

      {/* The rematch offer sits on top of the finished board (D-036). Same width
          as the board, so the dimming covers exactly the board. */}
      {shown && (
        <div className="relative mx-auto w-full max-w-xl">
          <UltimateBoard
            game={shown}
            // Nothing can be played while looking back at the game.
            disabled={reviewing || makeMove.isPending}
            onPlay={(board_index, cell_index) => {
              makeMove.mutate({ board_index, cell_index });
            }}
          />
          {data.status !== "in_progress" && !reviewing && (
            <RematchOffer
              game={data}
              onReview={() => {
                showMove(data.move_count);
              }}
            />
          )}
        </div>
      )}
    </div>
  );
}

/** The color pickers stay hidden until a player asks for them (D-025). */
function ColorOptions({ playerXName, playerOName }: { playerXName: string; playerOName: string }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();

  return (
    <div className="space-y-3">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => {
          setOpen(!open);
        }}
        className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
      >
        {open ? "Hide colors" : "Change colors"}
      </button>
      {open && (
        <div id={panelId} className="flex flex-wrap gap-6">
          <PlayerColorPicker player="x" playerName={playerXName} />
          <PlayerColorPicker player="o" playerName={playerOName} />
        </div>
      )}
    </div>
  );
}

/**
 * After a game ends, the same two players can play again with their letters
 * swapped, so whoever went second now goes first (D-035). The finished game
 * stays in Saved Games; the rematch is a new game.
 *
 * Shown as a card over the finished board (D-036). "Review moves" steps
 * through the game instead (D-039); "Done reviewing" brings the card back.
 */
function RematchOffer({ game, onReview }: { game: GameDetail; onReview: () => void }) {
  const startRematch = useRematch(game.id);
  const navigate = useNavigate();
  // Swapped: this game's O player is the rematch's X player, and moves first.
  // The server does the swap; this is only for the sentence on the card.
  const rematch = { player_x_name: game.player_o_name, player_o_name: game.player_x_name };

  return (
    <div className="absolute inset-0 flex items-center justify-center rounded-lg bg-slate-900/50 p-4">
      <section
        aria-label="Rematch"
        className="w-full max-w-sm space-y-4 rounded-lg bg-white p-6 text-center shadow-xl"
      >
        <h2 className="text-2xl font-bold">{outcome(game)}</h2>
        <RecordSummary game={game} className="rounded-md bg-slate-50 px-3 py-2 text-left" />
        <p>
          Play again with letters swapped: <strong>{rematch.player_x_name}</strong> plays X and goes
          first, <strong>{rematch.player_o_name}</strong> plays O.
        </p>
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={() => {
              startRematch.mutate(undefined, {
                onSuccess: (next) => {
                  void navigate(`/games/${next.id}`);
                },
              });
            }}
            disabled={startRematch.isPending}
            className="rounded-md bg-slate-900 px-4 py-2.5 font-semibold text-white hover:bg-slate-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {startRematch.isPending ? "Starting rematch…" : "Rematch"}
          </button>
          <button
            type="button"
            onClick={onReview}
            className="rounded-md border border-slate-300 bg-white px-4 py-2 font-medium hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
          >
            Review moves
          </button>
        </div>
        {startRematch.isError && (
          <div className="text-left">
            <ErrorMessage message={`Could not start the rematch. ${startRematch.error.message}`} />
          </div>
        )}
      </section>
    </div>
  );
}

/** A short headline for a finished game. */
function outcome(game: GameDetail): string {
  switch (game.status) {
    case "x_won":
      return `${playerLabel(game, "x")} wins!`;
    case "o_won":
      return `${playerLabel(game, "o")} wins!`;
    default:
      return "It's a draw!";
  }
}

function StatusBanner({ game }: { game: GameDetail }) {
  let message: string;
  switch (game.status) {
    case "x_won":
      message = `${playerLabel(game, "x")} wins the game!`;
      break;
    case "o_won":
      message = `${playerLabel(game, "o")} wins the game!`;
      break;
    case "draw":
      message = "The game is a draw. No moves are left.";
      break;
    case "in_progress": {
      const player = game.next_player ? playerLabel(game, game.next_player) : "Next player";
      const where =
        game.required_board === null
          ? "any open board"
          : `the ${positionName(game.required_board)} board`;
      message = `${player} to move. Play in ${where}.`;
      break;
    }
  }

  return <StatusLine>{message}</StatusLine>;
}

/** The one line announced to screen readers after every move or review step. */
function StatusLine({ children }: { children: string }) {
  return (
    <p
      role="status"
      className="rounded-md border border-slate-200 bg-white px-4 py-3 text-lg font-medium"
    >
      {children}
    </p>
  );
}
