import { screen, waitFor, within } from "@testing-library/react";
import { delay, http, HttpResponse } from "msw";
import { describe, expect, it } from "vitest";

import type { BoardStatus } from "../api/client";
import { applyMove, findGame, seedGame } from "../test/fakeApi";
import { errorResponse } from "../test/handlers";
import { renderApp } from "../test/renderApp";
import { server } from "../test/server";

/** Wait for the game to finish loading, then return the status line. */
async function gameStatus() {
  await screen.findByRole("heading", { level: 1 });
  return screen.getByRole("status");
}

function cell(name: string) {
  return screen.getByRole("button", { name: new RegExp(`^${name},`) });
}

function enabledCells() {
  return screen
    .getAllByRole("button")
    .filter(
      (b) => b.getAttribute("aria-label")?.includes(" board, ") && !b.hasAttribute("disabled"),
    );
}

/**
 * Wait until both a name save and a move have finished, as a player would see
 * it: the "Saving names…" note is gone and the board can be played again
 * (after a move to a cell, the board of the same position is the next one).
 */
async function bothSavesFinished(nextBoardCell: string) {
  await waitFor(() => {
    expect(screen.getByText("Names are saved automatically.")).toBeInTheDocument();
    expect(cell(nextBoardCell)).toBeEnabled();
  });
}

describe("GamePage states", () => {
  it("shows a loading message while the game loads", () => {
    seedGame();
    renderApp("/games/1");

    expect(screen.getByRole("status")).toHaveTextContent("Loading game…");
  });

  it("shows an error with a retry that works", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    server.use(
      http.get("/api/v1/games/:id", () => errorResponse(500, "server_error", "Timed out."), {
        once: true,
      }),
    );
    const { user } = renderApp("/games/1");

    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Could not load this game. Timed out.");
    await user.click(within(alert).getByRole("button", { name: "Try again" }));

    expect(await screen.findByRole("heading", { name: "Ada vs Grace" })).toBeInTheDocument();
  });

  it("says the game is not found for a deleted or unknown game", async () => {
    renderApp("/games/42");

    expect(await screen.findByRole("heading", { name: "Game not found" })).toBeInTheDocument();
  });

  it("says the game is not found for an address that is not a game number", () => {
    renderApp("/games/abc");

    expect(screen.getByRole("heading", { name: "Game not found" })).toBeInTheDocument();
  });

  it("shows a new game as an empty board where X may play anywhere", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    renderApp("/games/1");

    expect(await gameStatus()).toHaveTextContent("Ada (X) to move. Play in any open board.");
    expect(enabledCells()).toHaveLength(81);
    expect(cell("Center board, center")).toHaveAccessibleName("Center board, center, empty");
  });

  it("shows won and drawn boards and closes them to play", async () => {
    const statuses: BoardStatus[] = ["x_won", "draw", ...Array<BoardStatus>(7).fill("open")];
    seedGame({ board_statuses: statuses });
    renderApp("/games/1");

    expect(await screen.findByRole("region", { name: "Top left board, won by X" })).toBeVisible();
    expect(screen.getByRole("region", { name: "Top middle board, drawn" })).toBeVisible();
    expect(cell("Top left board, top left")).toBeDisabled();
    expect(cell("Top middle board, center")).toBeDisabled();
    expect(enabledCells()).toHaveLength(63);
  });

  it("announces the winner and closes every board when the game is over", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", status: "o_won", next_player: null });
    renderApp("/games/1");

    expect(await gameStatus()).toHaveTextContent("Grace (O) wins the game!");
    expect(enabledCells()).toHaveLength(0);
  });

  it("announces when X wins", async () => {
    seedGame({ player_x_name: "Ada", status: "x_won", next_player: null });
    renderApp("/games/1");

    expect(await gameStatus()).toHaveTextContent("Ada (X) wins the game!");
  });

  it("says when the game is a draw", async () => {
    seedGame({ status: "draw", next_player: null });
    renderApp("/games/1");

    expect(await gameStatus()).toHaveTextContent("The game is a draw.");
  });
});

describe("GamePage flows", () => {
  it("plays a move, then sends the opponent to the matching board", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/games/1");
    await screen.findByRole("heading", { name: "Ada vs Grace" });

    await user.click(cell("Center board, top right"));

    expect(await screen.findByRole("status")).toHaveTextContent(
      "Grace (O) to move. Play in the top right board.",
    );
    expect(cell("Center board, top right")).toHaveAccessibleName(
      "Center board, top right, X, last move",
    );
    expect(cell("Center board, top right")).toHaveTextContent("X");
    expect(screen.getByRole("region", { name: "Top right board, play here" })).toBeVisible();
    expect(screen.getByRole("region", { name: "Center board, open" })).toBeVisible();
    // Only the nine cells of the top right board can be played now.
    expect(enabledCells()).toHaveLength(9);
    expect(cell("Top left board, center")).toBeDisabled();
  });

  it("shows why the server refused a move", async () => {
    seedGame();
    server.use(
      http.post("/api/v1/games/:id/moves", () =>
        errorResponse(409, "wrong_board", "This move must be played in board 2."),
      ),
    );
    const { user } = renderApp("/games/1");
    await screen.findByRole("heading", { name: "Player X vs Player O" });

    await user.click(cell("Center board, center"));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "This move must be played in board 2.",
    );
    expect(cell("Center board, center")).toHaveAccessibleName("Center board, center, empty");
  });

  it("can be played with the keyboard alone", async () => {
    seedGame();
    const { user } = renderApp("/games/1");
    await screen.findByRole("heading", { name: "Player X vs Player O" });

    cell("Top left board, top left").focus();
    await user.keyboard("{Enter}");

    expect(await screen.findByRole("status")).toHaveTextContent(
      "Player O (O) to move. Play in the top left board.",
    );
  });

  it("saves a player's name as soon as they leave the name box", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/games/1");
    const xName = await screen.findByLabelText("Player X");

    await user.clear(xName);
    await user.type(xName, "  Linus ");
    await user.tab();

    expect(await screen.findByRole("heading", { name: "Linus vs Grace" })).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveTextContent("Linus (X) to move");
  });

  it("saves a name when Enter is pressed", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    const { user } = renderApp("/games/1");
    const oName = await screen.findByLabelText("Player O");

    await user.clear(oName);
    await user.type(oName, "Ken{Enter}");

    expect(await screen.findByRole("heading", { name: "Ada vs Ken" })).toBeInTheDocument();
  });

  it("keeps names typed before the first move, and the game remembers them", async () => {
    seedGame();
    const { user } = renderApp("/games/1");
    await user.type(await screen.findByLabelText("Player X"), "{Control>}a{/Control}Ada");
    await user.type(screen.getByLabelText("Player O"), "{Control>}a{/Control}Grace");

    // Going straight to the board, without pressing anything else.
    await user.click(cell("Center board, center"));
    expect(await screen.findByRole("heading", { name: "Ada vs Grace" })).toBeInTheDocument();

    // Leave the game and come back: the names are still there.
    await user.click(screen.getByRole("link", { name: "Back to Saved Games" }));
    await user.click(await screen.findByRole("link", { name: "Ada vs Grace" }));
    expect(await screen.findByLabelText("Player X")).toHaveValue("Ada");
    expect(screen.getByLabelText("Player O")).toHaveValue("Grace");
  });

  it("does not save when nothing changed", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    let saves = 0;
    server.events.on("request:start", ({ request }) => {
      if (request.method === "PATCH") saves++;
    });
    const { user } = renderApp("/games/1");

    await user.click(await screen.findByLabelText("Player X"));
    await user.tab();
    await user.tab();

    expect(screen.getByText("Names are saved automatically.")).toBeInTheDocument();
    expect(saves).toBe(0);
    server.events.removeAllListeners();
  });

  it("a slow name save does not wipe a move made meanwhile (D-034)", async () => {
    const beforeTheMove = structuredClone(seedGame());
    // The server saves the name, but its reply is a snapshot from before the
    // move and arrives after the move's reply.
    server.use(
      http.patch("/api/v1/games/:id", async ({ params, request }) => {
        const game = findGame(Number(params.id));
        if (!game) return errorResponse(404, "game_not_found", "Not found.");
        const names = (await request.json()) as object;
        Object.assign(game, names);
        await delay(150);
        return HttpResponse.json({ ...beforeTheMove, ...names });
      }),
    );
    const { user } = renderApp("/games/1");
    await user.type(await screen.findByLabelText("Player O"), "{Control>}a{/Control}Grace");

    await user.click(cell("Center board, center")); // leaves the box: name save starts
    await bothSavesFinished("Center board, top left");

    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Player X vs Grace");
    expect(cell("Center board, center")).toHaveAccessibleName("Center board, center, X, last move");
  });

  it("a slow move does not bring back an old name (D-034)", async () => {
    seedGame();
    // The move's reply is a snapshot taken before the rename, and arrives last.
    server.use(
      http.post("/api/v1/games/:id/moves", async ({ params, request }) => {
        const game = findGame(Number(params.id));
        if (!game) return errorResponse(404, "game_not_found", "Not found.");
        const { board_index, cell_index } = (await request.json()) as {
          board_index: number;
          cell_index: number;
        };
        applyMove(game, board_index, cell_index);
        // Taken before the rename landed: still the old name.
        const snapshot = { ...structuredClone(game), player_o_name: "Player O" };
        await delay(150);
        return HttpResponse.json(snapshot, { status: 201 });
      }),
    );
    const { user } = renderApp("/games/1");
    await user.type(await screen.findByLabelText("Player O"), "{Control>}a{/Control}Grace");

    await user.click(cell("Center board, center"));
    await bothSavesFinished("Center board, top left");

    expect(cell("Center board, center")).toHaveAccessibleName("Center board, center, X, last move");
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Player X vs Grace");
  });

  it("explains when the names could not be saved", async () => {
    seedGame();
    server.use(
      http.patch("/api/v1/games/:id", () => errorResponse(500, "server_error", "Try later.")),
    );
    const { user } = renderApp("/games/1");

    await user.type(await screen.findByLabelText("Player O"), "!");
    await user.tab();

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Could not save the names. Try later.",
    );
  });
});

describe("Player name validation", () => {
  it("requires a name, and ties the message to the empty field", async () => {
    seedGame();
    const { user } = renderApp("/games/1");
    const oName = await screen.findByLabelText("Player O");

    await user.clear(oName);
    await user.type(oName, "   ");
    await user.tab();

    expect(oName).toHaveAccessibleDescription("Enter a name.");
    expect(oName).toBeInvalid();
    expect(screen.getByLabelText("Player X")).not.toHaveAccessibleDescription();
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Player X vs Player O");
  });

  it("limits names to 25 characters, and ties the message to the long field", async () => {
    seedGame();
    const { user } = renderApp("/games/1");
    const xName = await screen.findByLabelText("Player X");

    await user.clear(xName);
    await user.type(xName, "a".repeat(26));
    await user.tab();

    expect(xName).toHaveAccessibleDescription("Use 25 characters or fewer.");
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Player X vs Player O");
  });

  it("clears the message once the name is fixed", async () => {
    seedGame();
    const { user } = renderApp("/games/1");
    const xName = await screen.findByLabelText("Player X");
    await user.clear(xName);
    await user.tab();
    expect(xName).toHaveAccessibleDescription("Enter a name.");

    await user.type(xName, "Ada");
    await user.tab();

    expect(xName).not.toHaveAccessibleDescription();
    expect(await screen.findByRole("heading", { name: "Ada vs Player O" })).toBeInTheDocument();
  });
});

describe("rematch (D-035)", () => {
  it("is not offered while the game is still being played", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    renderApp("/games/1");
    await screen.findByRole("heading", { name: "Ada vs Grace" });

    expect(screen.queryByRole("button", { name: "Rematch" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Review moves" })).not.toBeInTheDocument();
  });

  it("is offered when the game is won, saying who will play which letter", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", status: "x_won", next_player: null });
    renderApp("/games/1");

    const offer = await screen.findByRole("region", { name: "Rematch" });
    expect(offer).toHaveTextContent("Grace plays X and goes first, Ada plays O.");
    expect(within(offer).getByRole("button", { name: "Rematch" })).toBeEnabled();
  });

  it("is offered when the game is a draw", async () => {
    seedGame({ status: "draw", next_player: null });
    renderApp("/games/1");

    const offer = await screen.findByRole("region", { name: "Rematch" });
    expect(within(offer).getByRole("heading", { name: "It's a draw!" })).toBeVisible();
    expect(within(offer).getByRole("button", { name: "Rematch" })).toBeEnabled();
  });

  it("names the winner at the top of the offer", async () => {
    seedGame({ player_x_name: "Ada", status: "x_won", next_player: null });
    renderApp("/games/1");

    const offer = await screen.findByRole("region", { name: "Rematch" });
    expect(within(offer).getByRole("heading", { name: "Ada (X) wins!" })).toBeVisible();
  });

  it("offers to review the moves, and comes back when done (D-039)", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", status: "x_won", next_player: null });
    const { user } = renderApp("/games/1");

    await user.click(await screen.findByRole("button", { name: "Review moves" }));

    expect(screen.queryByRole("region", { name: "Rematch" })).not.toBeInTheDocument();
    expect(screen.getByRole("navigation", { name: "Review moves" })).toBeVisible();

    await user.click(screen.getByRole("button", { name: "Done reviewing" }));

    expect(screen.getByRole("region", { name: "Rematch" })).toBeVisible();
    expect(screen.queryByRole("navigation", { name: "Review moves" })).not.toBeInTheDocument();
  });

  it("starts a new game with the letters swapped, keeping the finished one", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", status: "x_won", next_player: null });
    const { user } = renderApp("/games/1");

    await user.click(await screen.findByRole("button", { name: "Rematch" }));

    expect(await screen.findByRole("heading", { name: "Grace vs Ada" })).toBeInTheDocument();
    expect(screen.getByLabelText("Player X")).toHaveValue("Grace");
    expect(screen.getByLabelText("Player O")).toHaveValue("Ada");
    expect(screen.getByRole("status")).toHaveTextContent(
      "Grace (X) to move. Play in any open board.",
    );
    expect(screen.queryByRole("button", { name: "Rematch" })).not.toBeInTheDocument();

    // The finished game is still in Saved Games, next to the rematch.
    await user.click(screen.getByRole("link", { name: "Back to Saved Games" }));
    expect(await screen.findByRole("link", { name: "Ada vs Grace" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Grace vs Ada" })).toBeInTheDocument();
  });

  it("explains if the rematch cannot be started", async () => {
    seedGame({ status: "o_won", next_player: null });
    server.use(
      http.post("/api/v1/games/:id/rematch", () =>
        errorResponse(500, "server_error", "Try later."),
      ),
    );
    const { user } = renderApp("/games/1");

    await user.click(await screen.findByRole("button", { name: "Rematch" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Could not start the rematch. Try later.",
    );
  });
});

describe("wins and draws (D-037)", () => {
  const record = (series: [number, number, number], all: [number, number, number], games = 2) => ({
    series: {
      player_x_wins: series[0],
      player_o_wins: series[1],
      draws: series[2],
      games_played: series[0] + series[1] + series[2],
    },
    head_to_head: {
      player_x_wins: all[0],
      player_o_wins: all[1],
      draws: all[2],
      games_played: all[0] + all[1] + all[2],
    },
    games_in_series: games,
  });

  it("shows nothing before any game has finished", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    renderApp("/games/1");
    await screen.findByRole("heading", { name: "Ada vs Grace" });

    expect(screen.queryByRole("region", { name: "Record" })).not.toBeInTheDocument();
  });

  it("shows this series and all games between the players above the board", async () => {
    seedGame({
      player_x_name: "Grace",
      player_o_name: "Ada",
      record: record([0, 2, 1], [1, 3, 1], 4),
    });
    renderApp("/games/1");

    const tallies = await screen.findByRole("region", { name: "Record" });
    expect(tallies).toHaveTextContent("This series (4 games): Grace 0 wins · Ada 2 wins · 1 draw");
    expect(tallies).toHaveTextContent("All games between them: Grace 1 win · Ada 3 wins · 1 draw");
  });

  it("shows the tallies on the rematch card when a game ends", async () => {
    seedGame({
      player_x_name: "Ada",
      player_o_name: "Grace",
      status: "x_won",
      next_player: null,
      record: record([1, 0, 0], [1, 0, 0], 1),
    });
    renderApp("/games/1");

    const card = await screen.findByRole("region", { name: "Rematch" });
    expect(within(card).getByRole("region", { name: "Record" })).toHaveTextContent(
      "This series (1 game): Ada 1 win · Grace 0 wins · 0 draws",
    );
  });

  it("carries the tally into the rematch, seen from the swapped letters", async () => {
    seedGame({
      player_x_name: "Ada",
      player_o_name: "Grace",
      status: "x_won",
      next_player: null,
      record: record([1, 0, 0], [1, 0, 0], 1),
    });
    const { user } = renderApp("/games/1");

    await user.click(await screen.findByRole("button", { name: "Rematch" }));

    expect(await screen.findByRole("heading", { name: "Grace vs Ada" })).toBeInTheDocument();
    expect(screen.getByRole("region", { name: "Record" })).toHaveTextContent(
      "This series (2 games): Grace 0 wins · Ada 1 win · 0 draws",
    );
  });
});
