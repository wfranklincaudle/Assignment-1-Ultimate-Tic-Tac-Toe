import { useState, type SubmitEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";

import type { GameSort, GameSummary } from "../api/client";
import { useArchiveGame, useCreateGame, useGameList } from "../api/games";
import { RecordSummary } from "../components/RecordSummary";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { describeStatus, formatTimestamp } from "../lib/describe";

export const PAGE_SIZE = 10;

const SORT_OPTIONS: { value: GameSort; label: string }[] = [
  { value: "-last_played_at", label: "Last played, newest first" },
  { value: "last_played_at", label: "Last played, oldest first" },
  { value: "-created_at", label: "Created, newest first" },
  { value: "created_at", label: "Created, oldest first" },
];
const DEFAULT_SORT: GameSort = "-last_played_at";

function readSort(value: string | null): GameSort {
  return SORT_OPTIONS.find((option) => option.value === value)?.value ?? DEFAULT_SORT;
}

function readPage(value: string | null): number {
  const page = Number(value);
  return Number.isInteger(page) && page >= 1 ? page : 1;
}

const buttonClass =
  "rounded-md px-4 py-2 font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 disabled:cursor-not-allowed disabled:opacity-50";

export function GamesPage() {
  // Search, sort and page live in the URL so the back button and links keep them.
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") ?? "";
  const sort = readSort(searchParams.get("sort"));
  const page = readPage(searchParams.get("page"));

  const list = useGameList({ q, sort, page, pageSize: PAGE_SIZE });
  const createGame = useCreateGame();
  const navigate = useNavigate();

  function updateParams(changes: Record<string, string | null>) {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === null || value === "") next.delete(key);
      else next.set(key, value);
    }
    setSearchParams(next);
  }

  function handleSearch(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = new FormData(event.currentTarget).get("q");
    updateParams({ q: typeof value === "string" ? value.trim() : null, page: null });
  }

  function handleNewGame() {
    createGame.mutate(undefined, {
      onSuccess: (game) => {
        void navigate(`/games/${game.id}`);
      },
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold">Saved Games</h1>
        <button
          type="button"
          onClick={handleNewGame}
          disabled={createGame.isPending}
          className={`${buttonClass} bg-slate-900 text-white hover:bg-slate-700`}
        >
          {createGame.isPending ? "Starting…" : "New game"}
        </button>
      </div>

      {createGame.isError && <ErrorMessage message={createGame.error.message} />}

      <div className="flex flex-wrap items-end gap-3">
        <form role="search" onSubmit={handleSearch} className="flex flex-1 items-end gap-2">
          <div className="flex flex-1 flex-col gap-1">
            <label htmlFor="game-search" className="text-sm font-medium text-slate-700">
              Search player names
            </label>
            <input
              id="game-search"
              name="q"
              type="search"
              defaultValue={q}
              key={q}
              className="rounded-md border border-slate-300 bg-white px-3 py-2 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-slate-900"
            />
          </div>
          <button
            type="submit"
            className={`${buttonClass} border border-slate-300 bg-white hover:bg-slate-100`}
          >
            Search
          </button>
        </form>

        <div className="flex flex-col gap-1">
          <label htmlFor="game-sort" className="text-sm font-medium text-slate-700">
            Sort by
          </label>
          <select
            id="game-sort"
            value={sort}
            onChange={(event) => {
              updateParams({ sort: event.target.value, page: null });
            }}
            className="rounded-md border border-slate-300 bg-white px-3 py-2 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-slate-900"
          >
            {SORT_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {list.isPending ? (
        <LoadingMessage label="Loading saved games…" />
      ) : list.isError ? (
        <ErrorMessage
          message={`Could not load saved games. ${list.error.message}`}
          onRetry={() => void list.refetch()}
        />
      ) : list.data.total === 0 ? (
        <p className="rounded-md border border-dashed border-slate-300 p-8 text-center text-slate-600">
          {q ? `No saved games match “${q}”.` : "No saved games yet. Start a new game to play."}
        </p>
      ) : list.data.items.length === 0 ? (
        // For example, after deleting the only game on the last page.
        <div className="rounded-md border border-dashed border-slate-300 p-8 text-center text-slate-600">
          <p>There are no games on this page.</p>
          <button
            type="button"
            onClick={() => {
              updateParams({ page: null });
            }}
            className="mt-3 font-medium underline underline-offset-4"
          >
            Go to the first page
          </button>
        </div>
      ) : (
        <>
          <ul className="space-y-3">
            {list.data.items.map((game) => (
              <GameListItem key={game.id} game={game} />
            ))}
          </ul>
          <Pagination
            page={page}
            totalPages={Math.max(1, Math.ceil(list.data.total / PAGE_SIZE))}
            onChange={(next) => {
              updateParams({ page: next === 1 ? null : String(next) });
            }}
          />
        </>
      )}
    </div>
  );
}

function GameListItem({ game }: { game: GameSummary }) {
  const archive = useArchiveGame();
  const [confirming, setConfirming] = useState(false);
  const title = `${game.player_x_name} vs ${game.player_o_name}`;
  const finished = game.status !== "in_progress";

  return (
    <li className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white p-4">
      <div>
        <h2 className="text-lg font-semibold">
          <Link
            to={`/games/${game.id}`}
            className="underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-slate-900"
          >
            {title}
          </Link>
        </h2>
        <p className="text-slate-700">{describeStatus(game)}</p>
        <p className="text-sm text-slate-500">
          Last played {formatTimestamp(game.last_played_at)} · {game.move_count}{" "}
          {game.move_count === 1 ? "move" : "moves"}
        </p>
        <RecordSummary game={game} className="mt-1 text-slate-700" />
      </div>

      {confirming ? (
        <div
          role="group"
          aria-label={`Confirm deleting ${title}`}
          className="flex items-center gap-2"
        >
          <p className="text-sm font-medium">Delete this game? This cannot be undone.</p>
          <button
            type="button"
            onClick={() => {
              archive.mutate(game.id);
            }}
            disabled={archive.isPending}
            className={`${buttonClass} bg-red-700 text-white hover:bg-red-800`}
          >
            Delete game
          </button>
          <button
            type="button"
            onClick={() => {
              setConfirming(false);
            }}
            className={`${buttonClass} border border-slate-300 bg-white hover:bg-slate-100`}
          >
            Cancel
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          {/* D-038: carry on with an unfinished game, or look back at a finished one. */}
          {finished ? (
            <Link
              // Opens the move-by-move review at the final move (D-039).
              to={`/games/${game.id}?move=${game.move_count}`}
              aria-label={`Review ${title}`}
              className={`${buttonClass} border border-slate-300 bg-white hover:bg-slate-100`}
            >
              Review
            </Link>
          ) : (
            <Link
              to={`/games/${game.id}`}
              aria-label={`Resume ${title}`}
              className={`${buttonClass} bg-slate-900 text-white hover:bg-slate-700`}
            >
              Resume
            </Link>
          )}
          <button
            type="button"
            aria-label={`Delete ${title}`}
            onClick={() => {
              setConfirming(true);
            }}
            className={`${buttonClass} border border-slate-300 bg-white text-red-800 hover:bg-red-50`}
          >
            Delete
          </button>
        </div>
      )}
      {archive.isError && (
        <p role="alert" className="w-full text-sm text-red-800">
          Could not delete this game. {archive.error.message}
        </p>
      )}
    </li>
  );
}

function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
}) {
  if (totalPages <= 1 && page === 1) return null;

  return (
    <nav aria-label="Pages" className="flex items-center justify-center gap-3">
      <button
        type="button"
        onClick={() => {
          onChange(page - 1);
        }}
        disabled={page <= 1}
        className={`${buttonClass} border border-slate-300 bg-white hover:bg-slate-100`}
      >
        Previous
      </button>
      <p>
        Page {page} of {totalPages}
      </p>
      <button
        type="button"
        onClick={() => {
          onChange(page + 1);
        }}
        disabled={page >= totalPages}
        className={`${buttonClass} border border-slate-300 bg-white hover:bg-slate-100`}
      >
        Next
      </button>
    </nav>
  );
}
