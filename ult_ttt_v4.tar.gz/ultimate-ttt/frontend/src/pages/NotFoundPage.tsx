import { Link, isRouteErrorResponse, useRouteError } from "react-router";

export function NotFoundPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p>There is nothing at this address.</p>
      <Link to="/games" className="font-medium underline underline-offset-4">
        Go to Saved Games
      </Link>
    </div>
  );
}

/** Shown if rendering a page throws. Keeps the app usable instead of a blank screen. */
export function RouteErrorPage() {
  const error = useRouteError();
  const detail = isRouteErrorResponse(error)
    ? `${error.status} ${error.statusText}`
    : error instanceof Error
      ? error.message
      : "Unknown error";

  return (
    <div role="alert" className="mx-auto max-w-2xl space-y-4 p-6">
      <h1 className="text-3xl font-bold">Something went wrong</h1>
      <p>{detail}</p>
      <a href="/games" className="font-medium underline underline-offset-4">
        Go to Saved Games
      </a>
    </div>
  );
}
