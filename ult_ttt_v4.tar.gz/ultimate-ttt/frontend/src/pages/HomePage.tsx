import { Link, useNavigate } from "react-router";

import { useCreateGame } from "../api/games";
import { ErrorMessage } from "../components/Status";

const optionClass =
  "flex w-full items-center justify-center rounded-lg px-6 py-4 text-lg font-semibold focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-slate-900 disabled:cursor-not-allowed disabled:opacity-60";

/** The opening page: start a new game, open a saved one, or read the rules (D-032). */
export function HomePage() {
  const createGame = useCreateGame();
  const navigate = useNavigate();

  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-8 py-8 text-center">
      <div className="space-y-2">
        <h1 className="text-4xl font-bold">Ultimate Tic-Tac-Toe</h1>
        <p className="text-slate-600">
          Nine games of tic-tac-toe inside one. Two players, one screen.
        </p>
      </div>

      <nav aria-label="Start" className="w-full">
        <ul className="flex flex-col gap-3">
          <li>
            <button
              type="button"
              onClick={() => {
                createGame.mutate(undefined, {
                  onSuccess: (game) => {
                    void navigate(`/games/${game.id}`);
                  },
                });
              }}
              disabled={createGame.isPending}
              className={`${optionClass} bg-slate-900 text-white hover:bg-slate-700`}
            >
              {createGame.isPending ? "Starting…" : "New game"}
            </button>
          </li>
          <li>
            <Link
              to="/games"
              className={`${optionClass} border border-slate-300 bg-white hover:bg-slate-100`}
            >
              Saved Games
            </Link>
          </li>
          <li>
            <Link
              to="/rules"
              state={{ from: "/" }}
              className={`${optionClass} border border-slate-300 bg-white hover:bg-slate-100`}
            >
              Rules
            </Link>
          </li>
        </ul>
      </nav>

      {createGame.isError && (
        <div className="w-full text-left">
          <ErrorMessage message={`Could not start a new game. ${createGame.error.message}`} />
        </div>
      )}
    </div>
  );
}
