import { screen, within } from "@testing-library/react";
import { http, HttpResponse } from "msw";
import { describe, expect, it } from "vitest";

import { seedGame } from "../test/fakeApi";
import { errorResponse } from "../test/handlers";
import { renderApp } from "../test/renderApp";
import { server } from "../test/server";

function gameTitles() {
  return screen.getAllByRole("heading", { level: 2 }).map((h) => h.textContent);
}

describe("GamesPage states", () => {
  it("shows a loading message while games load", () => {
    renderApp("/games");

    expect(screen.getByRole("status")).toHaveTextContent("Loading saved games…");
  });

  it("says there are no saved games when the list is empty", async () => {
    renderApp("/games");

    expect(await screen.findByText(/No saved games yet/)).toBeInTheDocument();
  });

  it("shows an error with a retry that works", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    server.use(
      http.get("/api/v1/games", () => errorResponse(500, "server_error", "Database is down."), {
        once: true,
      }),
    );
    const { user } = renderApp("/games");

    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Could not load saved games. Database is down.");

    await user.click(within(alert).getByRole("button", { name: "Try again" }));

    expect(await screen.findByRole("link", { name: "Ada vs Grace" })).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("shows a general message when the server's error is not in the usual format", async () => {
    server.use(
      http.get("/api/v1/games", () => new HttpResponse("<h1>Bad Gateway</h1>", { status: 502 })),
    );
    renderApp("/games");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Could not load saved games. Something went wrong. Please try again.",
    );
  });

  it("lists saved games with their status and move count", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", next_player: "o", move_count: 1 });
    seedGame({ player_x_name: "Linus", player_o_name: "Ken", status: "o_won", next_player: null });
    seedGame({ player_x_name: "Alan", player_o_name: "Joan", status: "draw", next_player: null });
    seedGame({
      player_x_name: "Barbara",
      player_o_name: "Edsger",
      status: "x_won",
      next_player: null,
    });
    renderApp("/games");

    const ada = (await screen.findByRole("link", { name: "Ada vs Grace" })).closest("li");
    expect(ada).toHaveTextContent("Grace (O) to move");
    expect(ada).toHaveTextContent("1 move");
    expect(screen.getByRole("link", { name: "Linus vs Ken" }).closest("li")).toHaveTextContent(
      "Ken (O) won",
    );
    expect(screen.getByRole("link", { name: "Alan vs Joan" }).closest("li")).toHaveTextContent(
      "Draw",
    );
    expect(screen.getByRole("link", { name: "Barbara vs Edsger" }).closest("li")).toHaveTextContent(
      "Barbara (X) won",
    );
  });
});

describe("GamesPage tallies (D-037)", () => {
  it("shows each game's wins and draws in the list, once there are any", async () => {
    seedGame({ player_x_name: "Linus", player_o_name: "Ken" }); // nothing finished yet
    seedGame({
      player_x_name: "Ada",
      player_o_name: "Grace",
      record: {
        series: { player_x_wins: 2, player_o_wins: 1, draws: 0, games_played: 3 },
        head_to_head: { player_x_wins: 2, player_o_wins: 1, draws: 0, games_played: 3 },
        games_in_series: 3,
      },
    });
    renderApp("/games");

    const ada = (await screen.findByRole("link", { name: "Ada vs Grace" })).closest("li");
    expect(ada).toHaveTextContent("This series (3 games): Ada 2 wins · Grace 1 win · 0 draws");
    const linus = screen.getByRole("link", { name: "Linus vs Ken" }).closest("li");
    expect(linus).not.toHaveTextContent("This series");
  });
});

/** The Saved Games entry for the game with this title. */
function listItem(title: string): HTMLElement {
  const item = screen.getByRole("link", { name: title }).closest("li");
  if (!item) throw new Error(`No list item for "${title}"`);
  return item;
}

describe("Resume and Review (D-038)", () => {
  it("offers Resume for unfinished games and Review for finished ones", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    seedGame({ player_x_name: "Linus", player_o_name: "Ken", status: "x_won", next_player: null });
    seedGame({ player_x_name: "Alan", player_o_name: "Joan", status: "draw", next_player: null });
    renderApp("/games");

    await screen.findByRole("link", { name: "Ada vs Grace" });
    const ada = listItem("Ada vs Grace");
    expect(within(ada).getByRole("link", { name: "Resume Ada vs Grace" })).toBeVisible();
    expect(within(ada).queryByRole("link", { name: /^Review/ })).not.toBeInTheDocument();

    for (const title of ["Linus vs Ken", "Alan vs Joan"]) {
      const item = listItem(title);
      expect(within(item).getByRole("link", { name: `Review ${title}` })).toBeVisible();
      expect(within(item).queryByRole("link", { name: /^Resume/ })).not.toBeInTheDocument();
    }
  });

  it("Resume opens the board, ready to carry on", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", next_player: "o", move_count: 1 });
    const { user } = renderApp("/games");

    await user.click(await screen.findByRole("link", { name: "Resume Ada vs Grace" }));

    expect(await screen.findByRole("heading", { name: "Ada vs Grace", level: 1 })).toBeVisible();
    expect(screen.getByRole("status")).toHaveTextContent("Grace (O) to move");
  });

  it("Review opens the finished game move by move, at its last move (D-039)", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace", status: "x_won", next_player: null });
    const { user } = renderApp("/games");

    await user.click(await screen.findByRole("link", { name: "Review Ada vs Grace" }));

    expect(await screen.findByRole("heading", { name: "Ada vs Grace", level: 1 })).toBeVisible();
    expect(screen.getByRole("navigation", { name: "Review moves" })).toHaveTextContent(
      "Move 0 of 0",
    );
    expect(screen.queryByRole("region", { name: "Rematch" })).not.toBeInTheDocument();
  });
});

describe("GamesPage flows", () => {
  it("searches player names and says when nothing matches", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    seedGame({ player_x_name: "Linus", player_o_name: "Ken" });
    const { user } = renderApp("/games");
    await screen.findByRole("link", { name: "Ada vs Grace" });

    await user.type(screen.getByLabelText("Search player names"), "ken");
    await user.click(screen.getByRole("button", { name: "Search" }));

    expect(await screen.findByRole("link", { name: "Linus vs Ken" })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Ada vs Grace" })).not.toBeInTheDocument();

    await user.clear(screen.getByLabelText("Search player names"));
    await user.type(screen.getByLabelText("Search player names"), "nobody");
    await user.click(screen.getByRole("button", { name: "Search" }));

    expect(await screen.findByText("No saved games match “nobody”.")).toBeInTheDocument();
  });

  it("changes the order when a different sort is chosen", async () => {
    seedGame({ player_x_name: "Older" });
    seedGame({ player_x_name: "Newer" });
    const { user } = renderApp("/games");
    await screen.findByRole("link", { name: "Newer vs Player O" });
    expect(gameTitles()).toEqual(["Newer vs Player O", "Older vs Player O"]);

    await user.selectOptions(screen.getByLabelText("Sort by"), "Created, oldest first");

    await screen.findByRole("option", { name: "Created, oldest first", selected: true });
    expect(await screen.findAllByRole("heading", { level: 2 })).toHaveLength(2);
    expect(gameTitles()).toEqual(["Older vs Player O", "Newer vs Player O"]);
  });

  it("pages through more games than fit on one page", async () => {
    for (let i = 1; i <= 12; i++) seedGame({ player_x_name: `Player ${i}` });
    const { user } = renderApp("/games?sort=created_at");

    expect(await screen.findByText("Page 1 of 2")).toBeInTheDocument();
    expect(gameTitles()).toHaveLength(10);
    expect(screen.getByRole("button", { name: "Previous" })).toBeDisabled();

    await user.click(screen.getByRole("button", { name: "Next" }));

    expect(await screen.findByText("Page 2 of 2")).toBeInTheDocument();
    expect(gameTitles()).toEqual(["Player 11 vs Player O", "Player 12 vs Player O"]);
    expect(screen.getByRole("button", { name: "Next" })).toBeDisabled();

    await user.click(screen.getByRole("button", { name: "Previous" }));

    expect(await screen.findByText("Page 1 of 2")).toBeInTheDocument();
  });

  it("offers a way back when a page past the end is empty", async () => {
    seedGame({ player_x_name: "Ada" });
    const { user } = renderApp("/games?page=5");

    await user.click(await screen.findByRole("button", { name: "Go to the first page" }));

    expect(await screen.findByRole("link", { name: "Ada vs Player O" })).toBeInTheDocument();
  });

  it("starts a new game and opens its board", async () => {
    const { user } = renderApp("/games");
    await screen.findByText(/No saved games yet/);

    await user.click(screen.getByRole("button", { name: "New game" }));

    expect(
      await screen.findByRole("heading", { name: "Player X vs Player O", level: 1 }),
    ).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveTextContent("Player X (X) to move");
  });

  it("shows an error if a new game cannot be started", async () => {
    server.use(http.post("/api/v1/games", () => errorResponse(500, "server_error", "Try later.")));
    const { user } = renderApp("/games");
    await screen.findByText(/No saved games yet/);

    await user.click(screen.getByRole("button", { name: "New game" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Try later.");
  });

  it("deletes a game only after the player confirms", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    seedGame({ player_x_name: "Linus", player_o_name: "Ken" });
    const { user } = renderApp("/games");

    await user.click(await screen.findByRole("button", { name: "Delete Ada vs Grace" }));
    await user.click(screen.getByRole("button", { name: "Cancel" }));
    expect(screen.getByRole("link", { name: "Ada vs Grace" })).toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Delete Ada vs Grace" }));
    const confirm = screen.getByRole("group", { name: "Confirm deleting Ada vs Grace" });
    expect(confirm).toHaveTextContent("This cannot be undone.");
    await user.click(within(confirm).getByRole("button", { name: "Delete game" }));

    await screen.findByRole("link", { name: "Linus vs Ken" });
    expect(screen.queryByRole("link", { name: "Ada vs Grace" })).not.toBeInTheDocument();
  });

  it("explains when a game cannot be deleted", async () => {
    seedGame({ player_x_name: "Ada", player_o_name: "Grace" });
    server.use(
      http.post("/api/v1/games/:id/archive", () =>
        errorResponse(404, "game_not_found", "Game 1 does not exist."),
      ),
    );
    const { user } = renderApp("/games");

    await user.click(await screen.findByRole("button", { name: "Delete Ada vs Grace" }));
    await user.click(screen.getByRole("button", { name: "Delete game" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Could not delete this game. Game 1 does not exist.",
    );
  });
});
