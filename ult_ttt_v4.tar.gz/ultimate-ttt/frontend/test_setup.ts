/**
 * Vitest setup, run before every test file (see vite.config.ts `setupFiles`).
 * MSW handlers and helpers live in src/test/.
 */
import "@testing-library/jest-dom/vitest";
import { cleanup } from "@testing-library/react";
import { afterAll, afterEach, beforeAll } from "vitest";

import { resetFakeApi } from "./src/test/fakeApi";
import { server } from "./src/test/server";

// Any request without a handler fails the test instead of silently hanging.
beforeAll(() => {
  server.listen({ onUnhandledRequest: "error" });
});

afterEach(() => {
  cleanup();
  server.resetHandlers();
  resetFakeApi();
  window.localStorage.clear();
});

afterAll(() => {
  server.close();
});
