/**
 * End-to-end smoke test against a running app (happy path only).
 *
 *   docker compose up --build --wait     # from the repository root
 *   pnpm e2e                             # from frontend/
 *
 * E2E_BASE_URL points it somewhere else, e.g. http://localhost:5173 for `pnpm dev`.
 */
import { defineConfig, devices } from "@playwright/test";

const chromiumPath = process.env.PLAYWRIGHT_CHROMIUM_PATH;

export default defineConfig({
  testDir: "./e2e",
  forbidOnly: Boolean(process.env.CI),
  // No retries: a flaky happy path is a bug to fix, not to hide.
  retries: 0,
  reporter: process.env.CI ? [["list"], ["html", { open: "never" }]] : "list",
  use: {
    baseURL: process.env.E2E_BASE_URL ?? "http://localhost:8080",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        // Only for machines with a preinstalled browser; CI runs `playwright install`.
        ...(chromiumPath ? { launchOptions: { executablePath: chromiumPath } } : {}),
      },
    },
  ],
});
