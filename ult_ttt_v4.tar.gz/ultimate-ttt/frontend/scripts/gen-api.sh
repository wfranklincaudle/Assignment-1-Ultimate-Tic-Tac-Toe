#!/bin/sh
# Regenerate the API types from the backend's OpenAPI schema.
# Run after any backend change to schemas or routes, and commit both output files.
set -eu
cd "$(dirname "$0")/.."
(cd ../backend && uv run python -c "import json; from app.main import app; print(json.dumps(app.openapi(), indent=2))") > src/api/openapi.json
# --default-non-nullable false: fields with a server-side default (such as player
# names on create) stay optional in request types instead of becoming required.
pnpm exec openapi-typescript src/api/openapi.json -o src/api/schema.d.ts --default-non-nullable false
