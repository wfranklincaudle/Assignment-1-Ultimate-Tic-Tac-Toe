# Changelog

## Unreleased

### Added (after step 4)
- Move-by-move review: First, Previous, Next and Last through any game, with each move described in words. Opened from Review in Saved Games or Review moves on the rematch card. `GET /api/v1/games/{id}?at_move=n` returns any earlier position.
- Resume and Review buttons in Saved Games.
- Win and draw tallies for rematches: this series, and every game between the same two players, shown above the board, on the rematch card and in Saved Games. Deleted games are not counted.
- `POST /api/v1/games/{id}/rematch` and a database migration linking rematches into a series.
- Rematch: when a game ends, a card over the board names the result and offers a rematch with the players' letters swapped. "View board" hides the card to see the final position. The finished game stays in Saved Games.
- Home menu on the opening page: New game, Saved Games, Rules. The header title links back to it.
- Return button on the Rules page, back to the game, Saved Games or home menu it was opened from.

### Changed (after step 4)
- Player names save automatically when you leave a name box or press Enter; the "Save names" button is gone. Names typed before playing are no longer lost.

### Fixed (after step 4)
- The backend failed to start (container "unhealthy") when upgrading a database that already had saved moves: SQLite migrations that rebuild a table were blocked by foreign keys, and the failed attempt blocked every restart. Migrations now handle both, with no data lost.
- A name save and a move made at the same moment could briefly undo each other on screen.

### Added (step 4)
- Multi-stage Dockerfiles for both apps (non-root), nginx config, and a `.dockerignore` per app.
- `docker-compose.yml`: backend and frontend with healthchecks, a named volume for SQLite, and a commented-out PostgreSQL service.
- GitHub Actions CI: backend checks, frontend checks, an API-types freshness check, and an end-to-end job that builds the images and runs Playwright.
- Playwright happy-path test (`frontend/e2e/`).
- PostgreSQL driver (`psycopg`).

### Added
- Backend project (`uv`, Ruff, mypy strict, pytest) with the layered `app/` layout.
- Rules engine for Ultimate Tic-Tac-Toe in `app/services/rules.py`, with tests covering every rule in DECISIONS.md D-001.
- Database models for games and moves, and the first Alembic migration.
- Games API under `/api/v1/games`: create, list (search, sort, pagination), get, rename players, delete (archive), and make a move.
- Standard error envelope for every error, including framework errors and validation failures.
- Frontend (Vite 8, React 19, Tailwind v4, React Router 8, TanStack Query) with API types generated from the backend.
- Rules page, shown automatically the first time the app is opened in a browser, and always reachable from the header.
- Saved games page: new game, search, sort, pagination, and delete with confirmation.
- Game board page: 9×9 board playable by mouse or keyboard, status line for screen readers, and player renaming with validation.

### Added (since the first frontend release)
- Players can choose their colors from an eight-color palette on the board screen. The choice is remembered in this browser, and the two players can never have the same color.
- The color options are hidden behind a "Change colors" button until a player opens them.

### Changed
- Player names are limited to 25 characters (was 50). A migration shortens longer names already saved.
- The name boxes are tinted in each player's colour.
- "Saved Games" is capitalised where it names the page.
