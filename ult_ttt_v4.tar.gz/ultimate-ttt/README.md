# Ultimate Tic-Tac-Toe

Two players on one screen play Ultimate Tic-Tac-Toe. Games save on every move and can be resumed, renamed, or deleted. The rules and product decisions are in `DECISIONS.md`.

## Run everything with Docker

```bash
docker compose up --build
```

Then open http://localhost:8080. Saved games live in the `sqlite-data` volume, so they survive restarts; `docker compose down --volumes` deletes them.

To use PostgreSQL instead of SQLite, uncomment the `db` service in `docker-compose.yml`, the backend's `depends_on`, and the PostgreSQL `DATABASE_URL`.

## Backend

Needs [uv](https://docs.astral.sh/uv/) 0.9 or newer (older versions only install a pre-release of Python 3.14; run `uv self update`).

```bash
cd backend
uv sync
cp .env.example .env
uv run alembic upgrade head          # create or update the database
uv run uvicorn app.main:app --reload # API at http://localhost:8000, docs at /docs
```

Checks:

```bash
uv run ruff check . && uv run ruff format --check .
uv run mypy
uv run pytest --cov=app --cov-report=term-missing:skip-covered --cov-report=html --cov-fail-under=80
```

After changing a model, generate a migration with `uv run alembic revision --autogenerate -m "what changed"` and read it before committing.

## Frontend

Needs Node 24 and pnpm (run `corepack enable` once to get the pinned pnpm version).

```bash
cd frontend
pnpm install
pnpm dev        # http://localhost:5173, forwards /api to the backend on port 8000
```

Checks:

```bash
pnpm lint && pnpm format:check && pnpm typecheck
pnpm test:cov
```

After changing any backend schema or route, regenerate the API types and commit both files it writes:

```bash
pnpm gen:api    # writes src/api/openapi.json and src/api/schema.d.ts
```

## End-to-end test

The Playwright happy path runs against the running app:

```bash
docker compose up --build --wait     # from the repository root
cd frontend
pnpm exec playwright install chromium   # first time only
pnpm e2e
```

To run it against `pnpm dev` instead, set `E2E_BASE_URL=http://localhost:5173`.

## CI

`.github/workflows/ci.yml` runs on every push and pull request: backend checks, frontend checks, a check that the frontend's API types match the backend, and the end-to-end test against the Docker images. See `DECISIONS.md` D-029.
